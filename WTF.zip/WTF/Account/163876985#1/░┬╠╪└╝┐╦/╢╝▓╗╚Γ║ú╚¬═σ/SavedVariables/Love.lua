
TalentSetManager_Saves = nil
EasyObliterate_IgnoreList = {
}
NomiCakesDatas = {
	["WorkOrders"] = {
	},
	["Version"] = 2,
}
ArtifactPowerUserCharacterDB = {
	["hide"] = false,
	["disable"] = {
	},
}
