
DuowanAddon_BattleInfoDB = nil
