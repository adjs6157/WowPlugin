
Duowan_Character = {
}
DUOWAN_CHARACTER_INFO = ""
