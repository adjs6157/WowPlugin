
DuowanAddon_TradeLog_TradesHistory = {
}
DuowanAddon_TRADE_LOG_BUTTON_POS = 190
DuowanAddon_TradeLog_Announce_Checked = nil
DuowanAddon_TradeLog_AnnounceChannel = "WHISPER"
