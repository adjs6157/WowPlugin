
tCDblackData = {
}
tCDcoolingData = {
}
