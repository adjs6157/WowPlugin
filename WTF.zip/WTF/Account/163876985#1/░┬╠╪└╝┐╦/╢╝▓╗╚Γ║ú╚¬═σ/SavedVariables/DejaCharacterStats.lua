
DejaCharacterStatsDBPC = {
	["dcsdefaults"] = {
	},
}
