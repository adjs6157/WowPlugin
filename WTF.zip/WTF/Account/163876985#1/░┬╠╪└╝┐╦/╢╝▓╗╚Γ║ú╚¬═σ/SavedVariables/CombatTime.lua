
CombatTimeSettings = {
	["locked"] = false,
	["hide"] = false,
	["posY"] = 868.200134277344,
	["posX"] = 1238.17102050781,
}
