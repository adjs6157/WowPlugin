
LearningAid_Character = {
	["unlearned"] = {
		{
			{
				[585] = true,
			}, -- [1]
			[10] = {
				[59752] = true,
			},
		}, -- [1]
	},
	["dataVersion"] = 1,
	["version"] = "1.13a1",
	["actions"] = {
		{
		}, -- [1]
	},
}
