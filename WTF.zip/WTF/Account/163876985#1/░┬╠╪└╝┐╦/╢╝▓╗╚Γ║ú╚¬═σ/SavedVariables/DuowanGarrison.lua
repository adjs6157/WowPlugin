
MasterPlanPC = {
	["version"] = "0.115",
}
SVPC_GarrisonMissionManager = {
	["ignored_followers"] = {
	},
}
