
RelicInspectorCharDB = nil
