
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "都不肉海泉湾 - 奥特兰克",
	},
	["profiles"] = {
		["都不肉海泉湾 - 奥特兰克"] = {
			["version"] = "80000.06",
		},
	},
}
