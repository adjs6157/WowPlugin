
DejaCharacterStatsDB = {
	["gdbdefaults"] = {
		["dejacharacterstatsShowAverageRepairChecked"] = {
			["ShowAverageRepairSetChecked"] = false,
		},
		["dejacharacterstatsItemLevelChecked"] = {
			["ItemLevelTwoDecimalsSetChecked"] = true,
			["ItemLevelEQ_AV_SetChecked"] = true,
			["ItemLevelClassColorSetChecked"] = true,
			["ItemLevelDecimalsSetChecked"] = false,
		},
		["dejacharacterstatsHideAtZeroChecked"] = {
			["SetChecked"] = true,
		},
		["dejacharacterstatsShowItemRepairChecked"] = {
			["ShowItemRepairSetChecked"] = false,
		},
		["dejacharacterstatsShowDecimalsChecked"] = {
			["SetChecked"] = true,
		},
		["dejacharacterstatsExpandButtonChecked"] = {
			["ExpandButtonSetChecked"] = true,
		},
		["dejacharacterstatsShowItemLevelChecked"] = {
			["ShowItemLevelSetChecked"] = true,
		},
		["dejacharacterstatsHideMasteryChecked"] = {
			["SetChecked"] = true,
		},
		["dejacharacterstatsDCSZeroChecked"] = {
			["SetChecked"] = false,
		},
		["dejacharacterstatsClassBackgroundChecked"] = {
			["ClassBackgroundChecked"] = true,
		},
		["dejacharacterstatsShowDuraChecked"] = {
			["ShowDuraSetChecked"] = false,
		},
		["dejacharacterstatsExpandChecked"] = {
			["ExpandSetChecked"] = true,
		},
		["dejacharacterstatsShowDuraTextureChecked"] = {
			["ShowDuraTextureSetChecked"] = true,
		},
		["dejacharacterstatsScrollbarChecked"] = {
			["ScrollbarSetChecked"] = false,
		},
	},
}
DCS_ClassSpecDB = {
	["都不肉海泉湾:奥特兰克:1"] = {
		{
			["statKey"] = "ItemLevelFrame",
		}, -- [1]
		{
			["statKey"] = "GeneralCategory",
		}, -- [2]
		{
			["statKey"] = "HEALTH",
		}, -- [3]
		{
			["statKey"] = "DCS_POWER",
		}, -- [4]
		{
			["statKey"] = "DCS_ALTERNATEMANA",
		}, -- [5]
		{
			["statKey"] = "ITEMLEVEL",
			["hidden"] = true,
		}, -- [6]
		{
			["statKey"] = "MOVESPEED",
		}, -- [7]
		{
			["statKey"] = "DURABILITY_STAT",
		}, -- [8]
		{
			["statKey"] = "REPAIR_COST",
		}, -- [9]
		{
			["statKey"] = "AttributesCategory",
		}, -- [10]
		{
			["statKey"] = "STRENGTH",
			["hidden"] = true,
		}, -- [11]
		{
			["statKey"] = "AGILITY",
			["hidden"] = true,
		}, -- [12]
		{
			["statKey"] = "INTELLECT",
		}, -- [13]
		{
			["statKey"] = "STAMINA",
		}, -- [14]
		{
			["statKey"] = "ARMOR",
		}, -- [15]
		{
			["statKey"] = "OffenseCategory",
		}, -- [16]
		{
			["statKey"] = "ATTACK_DAMAGE",
			["hidden"] = true,
		}, -- [17]
		{
			["statKey"] = "ATTACK_AP",
			["hidden"] = true,
		}, -- [18]
		{
			["statKey"] = "DCS_ATTACK_ATTACKSPEED",
			["hidden"] = true,
		}, -- [19]
		{
			["statKey"] = "WEAPON_DPS",
			["hidden"] = true,
		}, -- [20]
		{
			["statKey"] = "SPELLPOWER",
		}, -- [21]
		{
			["statKey"] = "MANAREGEN",
		}, -- [22]
		{
			["statKey"] = "ENERGY_REGEN",
		}, -- [23]
		{
			["statKey"] = "DCS_RUNEREGEN",
			["hidden"] = true,
		}, -- [24]
		{
			["statKey"] = "FOCUS_REGEN",
		}, -- [25]
		{
			["statKey"] = "GCD",
		}, -- [26]
		{
			["statKey"] = "EnhancementsCategory",
		}, -- [27]
		{
			["statKey"] = "CRITCHANCE",
			["hideAt"] = 0,
		}, -- [28]
		{
			["statKey"] = "HASTE",
			["hideAt"] = 0,
		}, -- [29]
		{
			["statKey"] = "VERSATILITY",
			["hideAt"] = 0,
		}, -- [30]
		{
			["statKey"] = "MASTERY",
			["hideAt"] = 0,
		}, -- [31]
		{
			["statKey"] = "LIFESTEAL",
			["hideAt"] = 0,
		}, -- [32]
		{
			["statKey"] = "AVOIDANCE",
			["hideAt"] = 0,
		}, -- [33]
		{
			["statKey"] = "DefenseCategory",
			["hidden"] = true,
		}, -- [34]
		{
			["statKey"] = "DODGE",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [35]
		{
			["statKey"] = "PARRY",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [36]
		{
			["statKey"] = "BLOCK",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [37]
		{
			["statKey"] = "RatingCategory",
			["hidden"] = true,
		}, -- [38]
		{
			["statKey"] = "CRITCHANCE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [39]
		{
			["statKey"] = "HASTE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [40]
		{
			["statKey"] = "VERSATILITY_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [41]
		{
			["statKey"] = "MASTERY_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [42]
		{
			["statKey"] = "LIFESTEAL_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [43]
		{
			["statKey"] = "AVOIDANCE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [44]
		{
			["statKey"] = "DODGE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [45]
		{
			["statKey"] = "PARRY_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [46]
		{
			["statKey"] = "SPEED_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [47]
		{
			["statKey"] = "SPEED",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [48]
		{
			["statKey"] = "STAGGER",
			["roles"] = {
				"TANK", -- [1]
			},
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [49]
		["uniqueKey"] = "都不肉海泉湾:奥特兰克:1",
	},
	["个噢核心:死亡之翼:1"] = {
		{
			["statKey"] = "ItemLevelFrame",
		}, -- [1]
		{
			["statKey"] = "GeneralCategory",
		}, -- [2]
		{
			["statKey"] = "HEALTH",
		}, -- [3]
		{
			["statKey"] = "DCS_POWER",
		}, -- [4]
		{
			["statKey"] = "DCS_ALTERNATEMANA",
		}, -- [5]
		{
			["statKey"] = "ITEMLEVEL",
			["hidden"] = true,
		}, -- [6]
		{
			["statKey"] = "MOVESPEED",
		}, -- [7]
		{
			["statKey"] = "DURABILITY_STAT",
		}, -- [8]
		{
			["statKey"] = "REPAIR_COST",
		}, -- [9]
		{
			["statKey"] = "AttributesCategory",
		}, -- [10]
		{
			["statKey"] = "STRENGTH",
		}, -- [11]
		{
			["statKey"] = "AGILITY",
			["hidden"] = true,
		}, -- [12]
		{
			["statKey"] = "INTELLECT",
			["hidden"] = true,
		}, -- [13]
		{
			["statKey"] = "STAMINA",
		}, -- [14]
		{
			["statKey"] = "ARMOR",
		}, -- [15]
		{
			["statKey"] = "OffenseCategory",
		}, -- [16]
		{
			["statKey"] = "ATTACK_DAMAGE",
		}, -- [17]
		{
			["statKey"] = "ATTACK_AP",
		}, -- [18]
		{
			["statKey"] = "DCS_ATTACK_ATTACKSPEED",
		}, -- [19]
		{
			["statKey"] = "WEAPON_DPS",
		}, -- [20]
		{
			["statKey"] = "SPELLPOWER",
			["hidden"] = true,
		}, -- [21]
		{
			["statKey"] = "MANAREGEN",
			["hidden"] = true,
		}, -- [22]
		{
			["statKey"] = "ENERGY_REGEN",
		}, -- [23]
		{
			["statKey"] = "DCS_RUNEREGEN",
		}, -- [24]
		{
			["statKey"] = "FOCUS_REGEN",
		}, -- [25]
		{
			["statKey"] = "GCD",
		}, -- [26]
		{
			["statKey"] = "EnhancementsCategory",
		}, -- [27]
		{
			["statKey"] = "CRITCHANCE",
			["hideAt"] = 0,
		}, -- [28]
		{
			["statKey"] = "HASTE",
			["hideAt"] = 0,
		}, -- [29]
		{
			["statKey"] = "VERSATILITY",
			["hideAt"] = 0,
		}, -- [30]
		{
			["statKey"] = "MASTERY",
			["hideAt"] = 0,
		}, -- [31]
		{
			["statKey"] = "LIFESTEAL",
			["hideAt"] = 0,
		}, -- [32]
		{
			["statKey"] = "AVOIDANCE",
			["hideAt"] = 0,
		}, -- [33]
		{
			["statKey"] = "DefenseCategory",
			["hidden"] = true,
		}, -- [34]
		{
			["statKey"] = "DODGE",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [35]
		{
			["statKey"] = "PARRY",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [36]
		{
			["statKey"] = "BLOCK",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [37]
		{
			["statKey"] = "RatingCategory",
			["hidden"] = true,
		}, -- [38]
		{
			["statKey"] = "CRITCHANCE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [39]
		{
			["statKey"] = "HASTE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [40]
		{
			["statKey"] = "VERSATILITY_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [41]
		{
			["statKey"] = "MASTERY_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [42]
		{
			["statKey"] = "LIFESTEAL_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [43]
		{
			["statKey"] = "AVOIDANCE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [44]
		{
			["statKey"] = "DODGE_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [45]
		{
			["statKey"] = "PARRY_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [46]
		{
			["statKey"] = "SPEED_RATING",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [47]
		{
			["statKey"] = "SPEED",
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [48]
		{
			["statKey"] = "STAGGER",
			["roles"] = {
				"TANK", -- [1]
			},
			["hideAt"] = 0,
			["hidden"] = true,
		}, -- [49]
		["uniqueKey"] = "个噢核心:死亡之翼:1",
	},
}
