
DuowanAddon_ChannelCleanDB = {
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "Default",
		["个噢核心 - 死亡之翼"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["firstTime"] = false,
			["filter"] = {
				["trigger"] = {
					"★", -- [1]
					"☆", -- [2]
					"●", -- [3]
					"◆", -- [4]
					"■", -- [5]
					"▲", -- [6]
					"〓", -- [7]
					"※", -- [8]
					"▆", -- [9]
				},
			},
		},
	},
}
