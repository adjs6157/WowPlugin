
WeakAurasSaved = {
	["dynamicIconCache"] = {
	},
	["displays"] = {
	},
	["registered"] = {
	},
	["login_squelch_time"] = 10,
}
