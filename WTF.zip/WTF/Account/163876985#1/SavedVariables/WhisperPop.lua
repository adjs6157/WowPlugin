
WhisperPopDB = {
	["time"] = 1,
	["help"] = 1,
	["2.0"] = 1,
	["sound"] = 1,
	["Minimap Button"] = {
		["angle"] = 188,
	},
}
