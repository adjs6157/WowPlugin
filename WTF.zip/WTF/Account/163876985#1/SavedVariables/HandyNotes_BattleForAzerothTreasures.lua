
HandyNotes_BattleForAzerothTreasuresDB = {
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "都不肉海泉湾 - 奥特兰克",
		["个噢核心 - 死亡之翼"] = "个噢核心 - 死亡之翼",
	},
	["profiles"] = {
		["都不肉海泉湾 - 奥特兰克"] = {
		},
		["个噢核心 - 死亡之翼"] = {
		},
	},
}
