
RangeDisplayDB3 = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "Default",
		["个噢核心 - 死亡之翼"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["locked"] = true,
			["units"] = {
				["pet"] = {
				},
				["arena2"] = {
				},
				["focus"] = {
				},
				["arena5"] = {
				},
				["arena4"] = {
				},
			},
		},
	},
}
