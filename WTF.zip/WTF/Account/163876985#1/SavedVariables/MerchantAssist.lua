
MerchatAssistDB = {
	["死亡之翼_个噢核心"] = {
		["autobuy"] = {
		},
		["autosell"] = {
		},
	},
	["奥特兰克_都不肉海泉湾"] = {
		["autobuy"] = {
		},
		["autosell"] = {
		},
	},
}
MerchatAssistAutoBuy = nil
