
MapsterDB = {
	["namespaces"] = {
		["FogClear"] = {
		},
		["Coords"] = {
		},
	},
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "Default",
		["个噢核心 - 死亡之翼"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
