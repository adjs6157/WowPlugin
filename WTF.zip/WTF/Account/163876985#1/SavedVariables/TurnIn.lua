
TI_status = {
	["state"] = false,
	["debugstate"] = false,
	["version"] = "2.1",
	["usedefault"] = false,
	["autoadd"] = false,
	["options"] = {
		{
			["state"] = true,
			["type"] = "availquest",
			["name"] = "新任务",
		}, -- [1]
		{
			["state"] = false,
			["type"] = "gossip",
			["name"] = "自动对话",
		}, -- [2]
		{
			["state"] = false,
			["type"] = "taxi",
			["name"] = "交通工具",
		}, -- [3]
		{
			["state"] = false,
			["type"] = "vendor",
			["name"] = "商人",
		}, -- [4]
		{
			["state"] = false,
			["type"] = "banker",
			["name"] = "银行",
		}, -- [5]
		{
			["state"] = false,
			["type"] = "healer",
			["name"] = "战场复活NPC",
		}, -- [6]
		{
			["state"] = true,
			["type"] = "activequest",
			["name"] = "完成任务",
		}, -- [7]
		{
			["state"] = false,
			["type"] = "trainer",
			["name"] = "训练师",
		}, -- [8]
		{
			["state"] = false,
			["type"] = "battlemaster",
			["name"] = "战场大师",
		}, -- [9]
		{
			["state"] = false,
			["type"] = "binder",
			["name"] = "炉石绑定者",
		}, -- [10]
	},
}
TI_NPCDB = {
}
TI_NPCIndex = {
}
