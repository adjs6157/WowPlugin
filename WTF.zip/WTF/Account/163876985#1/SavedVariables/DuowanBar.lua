
DuowanBarDB = {
	["死亡之翼_个噢核心"] = {
		["hideTab"] = true,
	},
	["奥特兰克_都不肉海泉湾"] = {
		["hideTab"] = true,
	},
}
