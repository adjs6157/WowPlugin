
JamPlatesAccessoriesDB = nil
