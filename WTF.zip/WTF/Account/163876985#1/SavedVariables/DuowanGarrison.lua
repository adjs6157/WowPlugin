
MasterPlanAG = {
	["死亡之翼"] = {
		["个噢核心"] = {
			["class"] = "WARRIOR",
			["faction"] = "Horde",
		},
	},
	["奥特兰克"] = {
		["都不肉海泉湾"] = {
			["class"] = "PRIEST",
			["faction"] = "Alliance",
		},
	},
}
SV_GarrisonMissionManager = {
}
IPMDB = {
	["enableGarrisonMissions"] = true,
	["ignores"] = {
	},
	["profiles"] = {
	},
}
