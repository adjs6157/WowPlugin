
_NPCScanOverlayOptions = nil
_NPCScanOverlayKeyColors = nil
