
WardrobeSortDB = {
	["sortDropdown"] = 1,
	["db_version"] = 2,
	["reverse"] = false,
}
