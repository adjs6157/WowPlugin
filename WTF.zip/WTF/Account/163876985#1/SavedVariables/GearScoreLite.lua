
GS_Settings = {
	["Show"] = 1,
	["Player"] = 0,
	["Item"] = 0,
	["Compare"] = -1,
	["Special"] = 1,
	["Average"] = -1,
	["Level"] = -1,
}
