
showstuffstatus = nil
showfriends = nil
BHT_position = nil
