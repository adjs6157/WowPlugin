
FenceDB = nil
AuctionLiteDB = {
	["profileKeys"] = {
		["个噢核心 - 死亡之翼"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
