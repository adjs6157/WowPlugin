
Broker_GarrisonDB = {
	["global"] = {
		["data"] = {
			["奥特兰克"] = {
				["都不肉海泉湾"] = {
					["categories"] = {
					},
					["talents"] = {
						[134] = 134,
					},
					["configVersion"] = 3,
					["missions"] = {
					},
					["tooltipEnabled"] = true,
					["currencySealOfTemperedFateAmount"] = 0,
					["invasion"] = {
					},
					["buildingsExpanded"] = true,
					["missionsExpanded"] = true,
					["buildings"] = {
					},
					["shipments"] = {
					},
					["lootedNextReset"] = 1538866799,
					["currencyOrderResourcesAmount"] = 0,
					["trackWeekly"] = {
					},
					["ldbEnabled"] = true,
					["looseShipments"] = {
					},
					["notificationEnabled"] = true,
					["followerShipments"] = {
					},
					["currencyApexisAmount"] = 0,
					["currencyAncientManaAmount"] = 0,
					["currencyOil"] = 0,
					["order"] = 5,
					["orderhallExpanded"] = true,
					["currencySealOfInevitableFateAmount"] = 0,
					["info"] = {
						["playerName"] = "都不肉海泉湾",
						["playerFaction"] = "Alliance",
						["playerClass"] = "PRIEST",
						["realmName"] = "奥特兰克",
					},
					["trackDaily"] = {
					},
					["cacheSize"] = 500,
					["weeklyNextReset"] = 1539212399,
					["currencyAmount"] = 0,
					["lootedToday"] = {
					},
				},
			},
			["死亡之翼"] = {
				["个噢核心"] = {
					["categories"] = {
					},
					["talents"] = {
						[122] = 122,
					},
					["configVersion"] = 3,
					["missions"] = {
					},
					["tooltipEnabled"] = true,
					["currencySealOfTemperedFateAmount"] = 0,
					["invasion"] = {
						["available"] = false,
					},
					["buildingsExpanded"] = true,
					["missionsExpanded"] = true,
					["buildings"] = {
					},
					["shipments"] = {
					},
					["lootedNextReset"] = 1538866799,
					["currencyOrderResourcesAmount"] = 0,
					["trackWeekly"] = {
						["BONUS_ROLL_QUESTS"] = 0,
						["WARMILL_SOTF"] = false,
					},
					["ldbEnabled"] = true,
					["looseShipments"] = {
					},
					["notificationEnabled"] = true,
					["followerShipments"] = {
					},
					["currencyApexisAmount"] = 0,
					["currencyAncientManaAmount"] = 0,
					["currencyOil"] = 0,
					["order"] = 5,
					["orderhallExpanded"] = true,
					["currencySealOfInevitableFateAmount"] = 0,
					["info"] = {
						["playerName"] = "个噢核心",
						["playerFaction"] = "Horde",
						["playerClass"] = "WARRIOR",
						["realmName"] = "死亡之翼",
					},
					["trackDaily"] = {
						["WARMILL_IRONSCRAPS"] = false,
					},
					["cacheSize"] = 500,
					["weeklyNextReset"] = 1539212399,
					["currencyAmount"] = 0,
					["lootedToday"] = {
					},
				},
			},
		},
	},
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "Default",
		["个噢核心 - 死亡之翼"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
