
DBMLegendaryDummyDB = {
	["warning"] = true,
}
