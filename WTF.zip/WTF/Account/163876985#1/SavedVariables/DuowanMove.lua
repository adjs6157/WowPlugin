
BlizzMoveDB = {
	["KeyBindingFrame"] = {
		["default"] = {
			["relativeTo"] = "UIParent",
			["point"] = "CENTER",
			["relativePoint"] = "CENTER",
			["yOfs"] = 0,
			["xOfs"] = 0,
		},
		["relativePoint"] = "CENTER",
		["yOfs"] = 26.0000247955322,
		["xOfs"] = -20.0000782012939,
		["point"] = "CENTER",
	},
	["HelpFrame"] = {
	},
	["AuctionFrame"] = {
		["save"] = true,
	},
	["BankFrame"] = {
	},
	["GameMenuFrame"] = {
	},
	["RaidBrowserFrame"] = {
	},
	["CharacterFrame"] = {
	},
	["MailFrame"] = {
	},
	["VideoOptionsFrame"] = {
	},
	["CollectionsJournal"] = {
	},
	["AchievementFrame"] = {
		["save"] = true,
	},
	["FriendsFrame"] = {
	},
	["GossipFrame"] = {
	},
	["GarrisonLandingPage"] = {
	},
	["ObjectiveTrackerFrame"] = {
	},
	["MerchantFrame"] = {
	},
	["GarrisonCapacitiveDisplayFrame"] = {
	},
	["DressUpFrame"] = {
	},
	["WorldMapFrame"] = {
	},
	["LootFrame"] = {
	},
	["SpellBookFrame"] = {
	},
	["QuestLogPopupDetailFrame"] = {
	},
	["GuildFrame"] = {
	},
	["GuildBankFrame"] = {
		["save"] = true,
	},
	["PVEFrame"] = {
	},
	["ColorPickerFrame"] = {
	},
	["GarrisonMissionFrame"] = {
	},
	["TradeFrame"] = {
	},
	["CalendarFrame"] = {
		["save"] = true,
	},
	["InterfaceOptionsFrame"] = {
	},
}
