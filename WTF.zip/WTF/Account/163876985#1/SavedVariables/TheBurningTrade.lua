
DuowanAddon_TradeLog_Enabled = true
DuowanAddon_TBT_Enabled = true
