
HandyNotesDB = nil
HandyNotes_HandyNotesDB = nil
