
Accountant_SaveData = nil
Accountant_ClassicSaveData = {
	["奥特兰克"] = {
		["都不肉海泉湾"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "06/10/18",
				["class"] = "PRIEST",
				["curryear"] = "2018",
				["prvmonth"] = "09",
				["dateweek"] = "Sun Sep ",
				["version"] = "v2.11.02",
				["month"] = "10",
				["totalcash"] = 50,
				["faction"] = "Alliance",
				["lastsessiondate"] = "02/10/18",
				["prvday"] = "04/10/18",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["BARBER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GUILD"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRANSMO"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LFG"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["VOID"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GARRISON"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 50,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 50,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 50,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 50,
						["Out"] = 0,
					},
				},
			},
		},
	},
	["死亡之翼"] = {
		["个噢核心"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "06/10/18",
				["class"] = "WARRIOR",
				["prvday"] = "04/10/18",
				["dateweek"] = "Sun Sep ",
				["version"] = "v2.11.02",
				["month"] = "10",
				["totalcash"] = 74,
				["curryear"] = "2018",
				["faction"] = "Horde",
				["lastsessiondate"] = "06/10/18",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["BARBER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GUILD"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LFG"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["VOID"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRANSMO"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GARRISON"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 74,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 74,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 74,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 74,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 74,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
	},
}
Accountant_ClassicDB = {
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "Default",
		["个噢核心 - 死亡之翼"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["oprofileCopied"] = true,
		},
	},
}
Accountant_Classic_NewDB = nil
