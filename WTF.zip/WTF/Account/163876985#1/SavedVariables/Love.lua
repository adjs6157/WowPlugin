
CrucibleWeightDB = nil
EasyObliterate_Data = {
	["addonVersion"] = 18,
	["ashStats"] = {
	},
}
LoveDB = {
	["奥特兰克_Alliance_都不肉海泉湾"] = {
		["RaidMark"] = {
			["locked"] = false,
		},
		["FriendsLogDB"] = {
		},
	},
	["死亡之翼_Horde_个噢核心"] = {
		["FriendsLogDB"] = {
		},
	},
}
ezIconsDB = {
	["profileKeys"] = {
		["都不肉海泉湾 - 奥特兰克"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
FlashTaskbarDB = {
	["ready_check"] = true,
	["bg_queue"] = true,
	["arena_queue"] = true,
}
ACHIEVEMENTSEARCH_DB = nil
TalentSetManager_Options = nil
ArtifactPowerUserDB = {
	["ignoredItems"] = {
		[147717] = true,
	},
	["size"] = 40,
	["position"] = {
		["y"] = -150,
		["x"] = 0,
		["point"] = "CENTER",
		["relativePoint"] = "CENTER",
	},
	["lock"] = false,
}
