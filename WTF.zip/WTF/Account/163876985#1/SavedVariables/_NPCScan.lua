
_NPCScanOptions = nil
_NPCScanProfiles = nil
