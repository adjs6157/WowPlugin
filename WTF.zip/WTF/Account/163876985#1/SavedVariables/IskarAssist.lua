
IskarAssistDB = nil
