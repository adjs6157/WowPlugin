
DCT_SAVE = {
}
DCT_FONT_SAVE = {
	{
		["path"] = "Fonts\\ARHei.TTF",
		["name"] = "黑体(中英)",
		["active"] = true,
	}, -- [1]
	{
		["path"] = "Fonts\\ARKai_C.TTF",
		["name"] = "楷体C(中英)",
		["active"] = true,
	}, -- [2]
	{
		["path"] = "Fonts\\ARKai_T.TTF",
		["name"] = "楷体T(中英)",
		["active"] = true,
	}, -- [3]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [4]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [5]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [6]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [7]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [8]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [9]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [10]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [11]
	{
		["path"] = "",
		["name"] = "",
		["active"] = false,
	}, -- [12]
}
