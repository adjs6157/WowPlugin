
NPCMarkDB = {
	["旅店老板"] = true,
	["PVE代币兑换"] = true,
	["飞行管理员"] = false,
	["银行职员"] = true,
	["骑术训练师"] = true,
	["材料商"] = true,
	["训练假人"] = true,
	["军需官"] = true,
	["拍卖师"] = true,
	["装备重铸师"] = true,
	["战士训练师"] = true,
}
MapMarkHide = false
NPCMarkVersion = "0.1.5"
