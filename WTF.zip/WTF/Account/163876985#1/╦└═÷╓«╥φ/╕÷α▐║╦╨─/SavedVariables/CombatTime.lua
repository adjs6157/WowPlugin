
CombatTimeSettings = {
	["locked"] = false,
	["hide"] = false,
	["posY"] = 748.199890136719,
	["posX"] = 1168,
}
