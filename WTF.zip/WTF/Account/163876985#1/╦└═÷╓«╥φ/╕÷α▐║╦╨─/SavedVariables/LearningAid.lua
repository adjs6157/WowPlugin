
LearningAid_Character = {
	["dataVersion"] = 1,
	["version"] = "1.13a1",
	["actions"] = {
		{
		}, -- [1]
	},
}
