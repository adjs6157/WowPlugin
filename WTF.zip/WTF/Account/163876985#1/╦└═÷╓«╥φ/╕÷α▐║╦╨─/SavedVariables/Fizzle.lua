
DuowanAddon_FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["个噢核心 - 死亡之翼"] = "个噢核心 - 死亡之翼",
	},
	["profiles"] = {
		["个噢核心 - 死亡之翼"] = {
		},
	},
}
