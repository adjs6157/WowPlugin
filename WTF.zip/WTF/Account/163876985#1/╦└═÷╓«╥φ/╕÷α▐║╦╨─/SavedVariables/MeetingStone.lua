
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["个噢核心 - 死亡之翼"] = "个噢核心 - 死亡之翼",
	},
	["profiles"] = {
		["个噢核心 - 死亡之翼"] = {
			["version"] = "80000.06",
		},
	},
}
