
HunterMod_Saved = nil
HunterModDB = {
	["profileKeys"] = {
		["乐乐创想 - 金色平原"] = "Default",
	},
	["namespaces"] = {
		["zFeeder"] = {
		},
	},
}
