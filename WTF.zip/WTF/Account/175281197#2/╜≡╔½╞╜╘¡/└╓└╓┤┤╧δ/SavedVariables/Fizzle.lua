
DuowanAddon_FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["乐乐创想 - 金色平原"] = "乐乐创想 - 金色平原",
	},
	["profiles"] = {
		["乐乐创想 - 金色平原"] = {
		},
	},
}
