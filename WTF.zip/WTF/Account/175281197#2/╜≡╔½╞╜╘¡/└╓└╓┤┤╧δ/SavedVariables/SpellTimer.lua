
SpellTimer_Config = {
	["WarningTime"] = 5,
	["SPELLS"] = {
		["毒蝎钉刺"] = {
		},
		["爆炸陷阱"] = {
		},
		["爆炸陷阱效果"] = {
		},
		["震荡射击"] = {
		},
		["照明弹"] = {
		},
		["冰冻陷阱效果"] = {
		},
		["瞄准射击"] = {
		},
		["黑箭"] = {
		},
	},
	["ShowProgressBar"] = 1,
	["Scale"] = 0.8,
	["HideAllWhenLeaveCombat"] = 1,
	["ShowName"] = 1,
	["EnabledTest"] = 1,
	["mergeAoe"] = true,
}
