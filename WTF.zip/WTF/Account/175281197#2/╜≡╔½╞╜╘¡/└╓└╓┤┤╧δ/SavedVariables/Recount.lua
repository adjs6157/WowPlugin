
RecountPerCharDB = {
	["version"] = "1.3",
	["combatants"] = {
		["被征服的戈霍恩的触须 <乐乐创想>"] = {
			["GUID"] = "Creature-0-3045-1897-8880-143520-0000395CB1",
			["TimeLast"] = {
				["Damage"] = 2216.029,
				["OVERALL"] = 2216.029,
				["TimeDamage"] = 2216.029,
				["ActiveTime"] = 2216.029,
			},
			["LastEventType"] = {
				"DAMAGE", -- [1]
			},
			["TimeWindows"] = {
				["Damage"] = {
					1934, -- [1]
				},
				["TimeDamage"] = {
					1.5, -- [1]
				},
				["ActiveTime"] = {
					1.5, -- [1]
				},
			},
			["enClass"] = "PET",
			["level"] = 1,
			["LastFightIn"] = 2,
			["type"] = "Pet",
			["FightsSaved"] = 4,
			["ownerName"] = "乐乐创想",
			["NextEventNum"] = 2,
			["LastDamageTime"] = 2216.477,
			["LastEvents"] = {
				"被征服的戈霍恩的触须 <乐乐创想> 鲜血胆汁 疤爪 Hit -1934 (Nature)", -- [1]
			},
			["Name"] = "被征服的戈霍恩的触须",
			["LastEventTimes"] = {
				2216.477, -- [1]
			},
			["LastEventIncoming"] = {
				false, -- [1]
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["鲜血胆汁"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["ElementDone"] = {
						["Nature"] = 1934,
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["疤爪"] = {
							["Details"] = {
								["鲜血胆汁"] = {
									["count"] = 1934,
								},
							},
							["amount"] = 1934,
						},
					},
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["疤爪"] = {
							["Details"] = {
								["鲜血胆汁"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Attacks"] = {
						["鲜血胆汁"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1934,
									["min"] = 1934,
									["count"] = 1,
									["amount"] = 1934,
								},
							},
							["count"] = 1,
							["amount"] = 1934,
						},
					},
					["ActiveTime"] = 1.5,
					["Damage"] = 1934,
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["鲜血胆汁"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["ElementDone"] = {
						["Nature"] = 1934,
					},
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DamagedWho"] = {
						["疤爪"] = {
							["Details"] = {
								["鲜血胆汁"] = {
									["count"] = 1934,
								},
							},
							["amount"] = 1934,
						},
					},
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["疤爪"] = {
							["Details"] = {
								["鲜血胆汁"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["Attacks"] = {
						["鲜血胆汁"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1934,
									["min"] = 1934,
									["count"] = 1,
									["amount"] = 1934,
								},
							},
							["count"] = 1,
							["amount"] = 1934,
						},
					},
					["ActiveTime"] = 1.5,
					["Damage"] = 1934,
				},
			},
			["UnitLockout"] = 2216.029,
			["LastActive"] = 2216.029,
		},
		["乐乐创想"] = {
			["GUID"] = "Player-962-039065FF",
			["LastEventHealth"] = {
				106900, -- [1]
				106900, -- [2]
				106900, -- [3]
				106900, -- [4]
				106900, -- [5]
				106900, -- [6]
				106900, -- [7]
				106900, -- [8]
				106900, -- [9]
				106900, -- [10]
				106900, -- [11]
				106900, -- [12]
				106900, -- [13]
				106900, -- [14]
				106900, -- [15]
				106900, -- [16]
				106900, -- [17]
				106900, -- [18]
				106900, -- [19]
				106900, -- [20]
				106900, -- [21]
				106900, -- [22]
				106900, -- [23]
				106900, -- [24]
				106900, -- [25]
				106900, -- [26]
				106900, -- [27]
				106900, -- [28]
				104281, -- [29]
				104281, -- [30]
				105538, -- [31]
				105538, -- [32]
				105538, -- [33]
				106851, -- [34]
				106851, -- [35]
				106851, -- [36]
				106851, -- [37]
				106900, -- [38]
				106900, -- [39]
				106900, -- [40]
				106900, -- [41]
				106900, -- [42]
				106900, -- [43]
				106900, -- [44]
				106900, -- [45]
				106900, -- [46]
				106900, -- [47]
				106900, -- [48]
				106900, -- [49]
				106900, -- [50]
			},
			["LastAttackedBy"] = "砾鳞蜥蜴",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"HEAL", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"HEAL", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"HEAL", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"HEAL", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"HEAL", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"HEAL", -- [43]
				"HEAL", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"HEAL", -- [48]
				"DAMAGE", -- [49]
				"HEAL", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					38.75, -- [1]
				},
				["Healing"] = {
					60028, -- [1]
				},
				["DamageTaken"] = {
					90735, -- [1]
				},
				["HOT_Time"] = {
					12, -- [1]
				},
				["Absorbs"] = {
					28541, -- [1]
				},
				["HealingTaken"] = {
					88569, -- [1]
				},
				["Overhealing"] = {
					96587, -- [1]
				},
				["ActiveTime"] = {
					92.52, -- [1]
				},
				["TimeDamage"] = {
					53.77, -- [1]
				},
				["EnergyGain"] = {
					259, -- [1]
				},
				["DOT_Time"] = {
					48, -- [1]
				},
				["Damage"] = {
					175561, -- [1]
				},
			},
			["enClass"] = "HUNTER",
			["unit"] = "乐乐创想",
			["LastDamageTaken"] = 2619,
			["LastEventHealthMax"] = {
				106900, -- [1]
				106900, -- [2]
				106900, -- [3]
				106900, -- [4]
				106900, -- [5]
				106900, -- [6]
				106900, -- [7]
				106900, -- [8]
				106900, -- [9]
				106900, -- [10]
				106900, -- [11]
				106900, -- [12]
				106900, -- [13]
				106900, -- [14]
				106900, -- [15]
				106900, -- [16]
				106900, -- [17]
				106900, -- [18]
				106900, -- [19]
				106900, -- [20]
				106900, -- [21]
				106900, -- [22]
				106900, -- [23]
				106900, -- [24]
				106900, -- [25]
				106900, -- [26]
				106900, -- [27]
				106900, -- [28]
				106900, -- [29]
				106900, -- [30]
				106900, -- [31]
				106900, -- [32]
				106900, -- [33]
				106900, -- [34]
				106900, -- [35]
				106900, -- [36]
				106900, -- [37]
				106900, -- [38]
				106900, -- [39]
				106900, -- [40]
				106900, -- [41]
				106900, -- [42]
				106900, -- [43]
				106900, -- [44]
				106900, -- [45]
				106900, -- [46]
				106900, -- [47]
				106900, -- [48]
				106900, -- [49]
				106900, -- [50]
			},
			["level"] = 120,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 5,
			["LastHealTime"] = 2245.318,
			["type"] = "Self",
			["FightsSaved"] = 5,
			["GuardianReverseGUIDs"] = {
				["裂蹄牛"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "Pet-0-3045-1897-8880-86731-010212F255",
					},
				},
				["被征服的戈霍恩的触须"] = {
					["LatestGuardian"] = 0,
					["GUIDs"] = {
						[0] = "Creature-0-3045-1897-8880-143520-0000395CB1",
					},
				},
			},
			["TimeLast"] = {
				["TimeHeal"] = 2245.026,
				["HOT_Time"] = 2256.019,
				["OVERALL"] = 2261.029,
				["DamageTaken"] = 2241.029,
				["Healing"] = 2245.026,
				["Absorbs"] = 2241.029,
				["HealingTaken"] = 2245.026,
				["Overhealing"] = 2259.023,
				["ActiveTime"] = 2261.029,
				["EnergyGain"] = 2261.029,
				["TimeDamage"] = 2261.029,
				["DOT_Time"] = 2260.032,
				["Damage"] = 2261.029,
			},
			["Owner"] = false,
			["Pet"] = {
				"裂蹄牛 <乐乐创想>", -- [1]
				"灵魂兽 <乐乐创想>", -- [2]
				"被征服的戈霍恩的触须 <乐乐创想>", -- [3]
			},
			["NextEventNum"] = 10,
			["LastDamageTime"] = 2261.533,
			["LastEvents"] = {
				"乐乐创想 自动射击 砾鳞凝视者 Crit -5355 (Physical)", -- [1]
				"乐乐创想 倒刺射击 (伤害/跳) 砾鳞凝视者 Tick -428 (Physical)", -- [2]
				"乐乐创想 夺命黑鸦 砾鳞凝视者 Hit -1580 (Physical)", -- [3]
				"乐乐创想 进食 乐乐创想 Hit +33504 (33504 过量治疗)", -- [4]
				"乐乐创想 夺命黑鸦 砾鳞凝视者 Hit -1581 (Physical)", -- [5]
				"乐乐创想 倒刺射击 (伤害/跳) 砾鳞凝视者 Tick -429 (Physical)", -- [6]
				"乐乐创想 夺命黑鸦 砾鳞凝视者 Crit -3225 (Physical)", -- [7]
				"乐乐创想 裂肠者 砾鳞凝视者 Hit -1067 (Physical)", -- [8]
				"乐乐创想 奇美拉射击 砾鳞凝视者 Hit -5684 (Nature)", -- [9]
				"乐乐创想 奇美拉射击 疤爪 Hit -4102 (Nature)", -- [10]
				"乐乐创想 裂肠者 疤爪 Hit -1067 (Physical)", -- [11]
				"乐乐创想 倒刺射击 (伤害/跳) 疤爪 Tick -387 (Physical)", -- [12]
				"乐乐创想 自动射击 疤爪 Crit -3952 (Physical)", -- [13]
				"乐乐创想 眼镜蛇射击 疤爪 Hit -2003 (Physical)", -- [14]
				"乐乐创想 进食 乐乐创想 Hit +67008 (67008 过量治疗)", -- [15]
				"砾鳞蜥蜴 肉搏 乐乐创想 Absorb -5637 (5637 被吸收) (1)", -- [16]
				"乐乐创想 自动射击 砾鳞蜥蜴 Hit -1937 (Physical)", -- [17]
				"砾鳞蜥蜴 肉搏 乐乐创想 Absorb -2913 (2913 被吸收) (1)", -- [18]
				"乐乐创想 多重射击 砾鳞蜥蜴 Hit -397 (Physical)", -- [19]
				"乐乐创想 多重射击 砾鳞蜥蜴 Hit -398 (Physical)", -- [20]
				"乐乐创想 多重射击 砾鳞蜥蜴 Crit -811 (Physical)", -- [21]
				"乐乐创想 裂肠者 砾鳞蜥蜴 Hit -1067 (Physical)", -- [22]
				"砾鳞蜥蜴 肉搏 乐乐创想 Absorb -235 (1)", -- [23]
				"砾鳞蜥蜴 肉搏 乐乐创想 Hit -2097 (235 被吸收) (Physical)", -- [24]
				"乐乐创想 吸血 乐乐创想 Hit +401", -- [25]
				"乐乐创想 倒刺射击 (伤害/跳) 砾鳞蜥蜴 Tick -386 (Physical)", -- [26]
				"乐乐创想 冷漠面容 乐乐创想 Crit +6275 (4579 过量治疗)", -- [27]
				"砾鳞蜥蜴 肉搏 乐乐创想 Hit -2619 (Physical)", -- [28]
				"乐乐创想 自动射击 砾鳞蜥蜴 Crit -3900 (Physical)", -- [29]
				"乐乐创想 奇美拉射击 砾鳞蜥蜴 Hit -4102 (Frost)", -- [30]
				"乐乐创想 吸血 乐乐创想 Hit +1257", -- [31]
				"乐乐创想 奇美拉射击 砾鳞蜥蜴 Crit -8369 (Nature)", -- [32]
				"乐乐创想 倒刺射击 (伤害/跳) 砾鳞蜥蜴 Tick -386 (Physical)", -- [33]
				"乐乐创想 吸血 乐乐创想 Hit +1313", -- [34]
				"乐乐创想 自动射击 砾鳞蜥蜴 Hit -1962 (Physical)", -- [35]
				"乐乐创想 倒刺射击 (伤害/跳) 砾鳞蜥蜴 Tick -387 (Physical)", -- [36]
				"乐乐创想 裂肠者 砾鳞蜥蜴 Hit -1067 (Physical)", -- [37]
				"乐乐创想 吸血 乐乐创想 Hit +512 (463 过量治疗)", -- [38]
				"乐乐创想 多重射击 砾鳞蜥蜴 Hit -398 (Physical)", -- [39]
				"乐乐创想 多重射击 砾鳞蜥蜴 Crit -811 (Physical)", -- [40]
				"乐乐创想 多重射击 砾鳞蜥蜴 Crit -811 (Physical)", -- [41]
				"乐乐创想 倒刺射击 (伤害/跳) 砾鳞蜥蜴 Tick -386 (Physical)", -- [42]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [43]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5239 (5239 过量治疗)", -- [44]
				"乐乐创想 自动射击 砾鳞凝视者 Hit -1959 (Physical)", -- [45]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [46]
				"乐乐创想 发光的种子 砾鳞凝视者 Hit -8806 (Physical)", -- [47]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [48]
				"乐乐创想 自动射击 砾鳞凝视者 Hit -2651 (Physical)", -- [49]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [50]
			},
			["Name"] = "乐乐创想",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				true, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				true, -- [15]
				true, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				false, -- [26]
				true, -- [27]
				true, -- [28]
				false, -- [29]
				false, -- [30]
				true, -- [31]
				false, -- [32]
				false, -- [33]
				true, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				true, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				2257.875, -- [1]
				2258.734, -- [2]
				2259.478, -- [3]
				2259.613, -- [4]
				2260.486, -- [5]
				2260.735, -- [6]
				2261.49, -- [7]
				2261.533, -- [8]
				2261.533, -- [9]
				2214.753, -- [10]
				2214.767, -- [11]
				2214.78, -- [12]
				2215.244, -- [13]
				2215.99, -- [14]
				2220.176, -- [15]
				2237.594, -- [16]
				2239.139, -- [17]
				2239.819, -- [18]
				2240.978, -- [19]
				2240.978, -- [20]
				2240.978, -- [21]
				2240.993, -- [22]
				2241.237, -- [23]
				2241.237, -- [24]
				2241.248, -- [25]
				2241.248, -- [26]
				2241.267, -- [27]
				2241.831, -- [28]
				2242.064, -- [29]
				2242.421, -- [30]
				2242.471, -- [31]
				2242.471, -- [32]
				2243.25, -- [33]
				2243.692, -- [34]
				2244.972, -- [35]
				2245.246, -- [36]
				2245.263, -- [37]
				2245.318, -- [38]
				2245.506, -- [39]
				2245.506, -- [40]
				2245.506, -- [41]
				2247.246, -- [42]
				2249, -- [43]
				2251.005, -- [44]
				2252.607, -- [45]
				2253.008, -- [46]
				2254.238, -- [47]
				2255.015, -- [48]
				2255.189, -- [49]
				2257.007, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["Absorbed"] = {
						["回声防护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["max"] = 5637,
									["min"] = 235,
									["count"] = 3,
									["amount"] = 8785,
								},
							},
							["count"] = 3,
							["amount"] = 8785,
						},
					},
					["DOTs"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["砾鳞蜥蜴"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 13501,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 8785,
					["DeathCount"] = 0,
					["HOT_Time"] = 3,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 15,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 8785,
					},
					["ElementTaken"] = {
						["Melee"] = 13501,
					},
					["DOT_Time"] = 12,
					["Damage"] = 27575,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 8.37,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 15104,
						["Frost"] = 4102,
						["Nature"] = 8369,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 5637,
									["min"] = 235,
									["count"] = 3,
									["amount"] = 8785,
								},
							},
							["count"] = 5,
							["amount"] = 8785,
						},
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 12471,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1545,
								},
								["自动射击"] = {
									["count"] = 7799,
								},
								["多重射击"] = {
									["count"] = 3626,
								},
								["裂肠者"] = {
									["count"] = 2134,
								},
							},
							["amount"] = 27575,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 13501,
								},
							},
							["amount"] = 13501,
						},
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["倒刺射击"] = {
									["count"] = 15,
								},
								["奇美拉射击"] = {
									["count"] = 19,
								},
							},
							["amount"] = 34,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0.02,
								},
								["吸血"] = {
									["count"] = 3.92,
								},
								["回声防护"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 8.37,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 463,
									["min"] = 463,
									["count"] = 1,
									["amount"] = 463,
								},
							},
							["count"] = 1,
							["amount"] = 463,
						},
						["治疗宠物"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 5238,
									["min"] = 5238,
									["count"] = 1,
									["amount"] = 5238,
								},
							},
							["count"] = 1,
							["amount"] = 5238,
						},
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4579,
									["min"] = 4579,
									["count"] = 1,
									["amount"] = 4579,
								},
							},
							["count"] = 1,
							["amount"] = 4579,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 3020,
								},
								["冷漠面容"] = {
									["count"] = 1696,
								},
								["回声防护"] = {
									["count"] = 8785,
								},
							},
							["amount"] = 13501,
						},
					},
					["EnergyGain"] = 34,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 10280,
					["TimeSpent"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 0.41,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 2.81,
								},
								["自动射击"] = {
									["count"] = 3.82,
								},
								["多重射击"] = {
									["count"] = 1.74,
								},
								["裂肠者"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 8.81,
						},
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0.02,
								},
								["吸血"] = {
									["count"] = 3.92,
								},
								["回声防护"] = {
									["count"] = 4.43,
								},
							},
							["amount"] = 8.37,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1313,
									["min"] = 49,
									["count"] = 4,
									["amount"] = 3020,
								},
							},
							["count"] = 4,
							["amount"] = 3020,
						},
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1696,
									["min"] = 1696,
									["count"] = 1,
									["amount"] = 1696,
								},
							},
							["count"] = 1,
							["amount"] = 1696,
						},
						["回声防护"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 5637,
									["min"] = 235,
									["count"] = 3,
									["amount"] = 8785,
								},
							},
							["count"] = 3,
							["amount"] = 8785,
						},
					},
					["WhoHealed"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 3020,
								},
								["冷漠面容"] = {
									["count"] = 1696,
								},
								["回声防护"] = {
									["count"] = 8785,
								},
							},
							["amount"] = 13501,
						},
					},
					["EnergyGained"] = {
						["倒刺射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 19,
								},
							},
							["amount"] = 19,
						},
					},
					["ActiveTime"] = 17.18,
					["Healing"] = 4716,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["奇美拉射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8369,
									["min"] = 8369,
									["count"] = 1,
									["amount"] = 8369,
								},
								["Hit"] = {
									["max"] = 4102,
									["min"] = 4102,
									["count"] = 1,
									["amount"] = 4102,
								},
							},
							["count"] = 2,
							["amount"] = 12471,
						},
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 387,
									["min"] = 386,
									["count"] = 4,
									["amount"] = 1545,
								},
							},
							["count"] = 4,
							["amount"] = 1545,
						},
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3900,
									["min"] = 3900,
									["count"] = 1,
									["amount"] = 3900,
								},
								["Hit"] = {
									["max"] = 1962,
									["min"] = 1937,
									["count"] = 2,
									["amount"] = 3899,
								},
							},
							["count"] = 3,
							["amount"] = 7799,
						},
						["多重射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 811,
									["min"] = 811,
									["count"] = 3,
									["amount"] = 2433,
								},
								["Hit"] = {
									["max"] = 398,
									["min"] = 397,
									["count"] = 3,
									["amount"] = 1193,
								},
							},
							["count"] = 6,
							["amount"] = 3626,
						},
						["裂肠者"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1067,
									["min"] = 1067,
									["count"] = 2,
									["amount"] = 2134,
								},
							},
							["count"] = 2,
							["amount"] = 2134,
						},
					},
					["HealingTaken"] = 13501,
					["RageGain"] = 0,
					["TimeDamage"] = 8.81,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 0.41,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 2.81,
								},
								["自动射击"] = {
									["count"] = 3.82,
								},
								["多重射击"] = {
									["count"] = 1.74,
								},
								["裂肠者"] = {
									["count"] = 0.03,
								},
							},
							["amount"] = 8.81,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["治疗宠物"] = {
							["Details"] = {
								["裂蹄牛 <乐乐创想>"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["DOTs"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["砾鳞蜥蜴"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 5,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 6,
					["Damage"] = 14890,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 5.73,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Nature"] = 8802,
						["Physical"] = 6088,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["听从我的召唤"] = {
									["count"] = 8802,
								},
								["夺命黑鸦"] = {
									["count"] = 1581,
								},
								["自动射击"] = {
									["count"] = 2625,
								},
								["裂肠者"] = {
									["count"] = 1067,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 815,
								},
							},
							["amount"] = 14890,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["倒刺射击"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 5.69,
								},
								["进食"] = {
									["count"] = 0.04,
								},
							},
							["amount"] = 5.73,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 2234,
								},
								["进食"] = {
									["count"] = 33504,
								},
							},
							["amount"] = 35738,
						},
					},
					["EnergyGain"] = 10,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 5.69,
								},
								["进食"] = {
									["count"] = 0.04,
								},
							},
							["amount"] = 5.73,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["听从我的召唤"] = {
									["count"] = 0.02,
								},
								["夺命黑鸦"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 1.5,
								},
								["裂肠者"] = {
									["count"] = 0.02,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 4.54,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1321,
									["min"] = 224,
									["count"] = 4,
									["amount"] = 2234,
								},
							},
							["count"] = 4,
							["amount"] = 2234,
						},
						["进食"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 33504,
									["min"] = 33504,
									["count"] = 1,
									["amount"] = 33504,
								},
							},
							["count"] = 1,
							["amount"] = 33504,
						},
					},
					["WhoHealed"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 2234,
								},
								["进食"] = {
									["count"] = 33504,
								},
							},
							["amount"] = 35738,
						},
					},
					["EnergyGained"] = {
						["倒刺射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ActiveTime"] = 10.27,
					["Healing"] = 35738,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["听从我的召唤"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6161,
									["min"] = 2641,
									["count"] = 2,
									["amount"] = 8802,
								},
							},
							["count"] = 2,
							["amount"] = 8802,
						},
						["夺命黑鸦"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1581,
									["min"] = 1581,
									["count"] = 1,
									["amount"] = 1581,
								},
							},
							["count"] = 1,
							["amount"] = 1581,
						},
						["自动射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2625,
									["min"] = 2625,
									["count"] = 1,
									["amount"] = 2625,
								},
							},
							["count"] = 1,
							["amount"] = 2625,
						},
						["裂肠者"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1067,
									["min"] = 1067,
									["count"] = 1,
									["amount"] = 1067,
								},
							},
							["count"] = 1,
							["amount"] = 1067,
						},
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 428,
									["min"] = 387,
									["count"] = 2,
									["amount"] = 815,
								},
							},
							["count"] = 2,
							["amount"] = 815,
						},
					},
					["HealingTaken"] = 35738,
					["RageGain"] = 0,
					["TimeDamage"] = 4.54,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["听从我的召唤"] = {
									["count"] = 0.02,
								},
								["夺命黑鸦"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 1.5,
								},
								["裂肠者"] = {
									["count"] = 0.02,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 4.54,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["DOTs"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["砾鳞蜥蜴"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeHealing"] = {
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["吸血"] = {
									["count"] = 0,
								},
								["回声防护"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["吸血"] = {
									["count"] = 0,
								},
								["回声防护"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["夺命黑鸦"] = {
									["count"] = 0,
								},
								["裂肠者"] = {
									["count"] = 0,
								},
								["听从我的召唤"] = {
									["count"] = 0,
								},
								["奇美拉射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
								["多重射击"] = {
									["count"] = 0,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["吸血"] = {
									["count"] = 0,
								},
								["回声防护"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["夺命黑鸦"] = {
									["count"] = 0,
								},
								["裂肠者"] = {
									["count"] = 0,
								},
								["听从我的召唤"] = {
									["count"] = 0,
								},
								["奇美拉射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
								["多重射击"] = {
									["count"] = 0,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["EnergyGain"] = 0,
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 0,
								},
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementDone"] = {
						["Physical"] = 0,
						["Frost"] = 0,
						["Nature"] = 0,
					},
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["回声防护"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeHeal"] = 0,
					["EnergyGained"] = {
						["倒刺射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["Healing"] = 0,
					["Overhealing"] = 0,
					["WhoHealed"] = {
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 0,
								},
								["吸血"] = {
									["count"] = 0,
								},
								["回声防护"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["夺命黑鸦"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["裂肠者"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["听从我的召唤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["自动射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["多重射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["夺命黑鸦"] = {
									["count"] = 0,
								},
								["裂肠者"] = {
									["count"] = 0,
								},
								["听从我的召唤"] = {
									["count"] = 0,
								},
								["奇美拉射击"] = {
									["count"] = 0,
								},
								["自动射击"] = {
									["count"] = 0,
								},
								["多重射击"] = {
									["count"] = 0,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["倒刺射击"] = {
									["count"] = 0,
								},
								["奇美拉射击"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Absorbs"] = 0,
					["Absorbed"] = {
						["回声防护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
				},
				["Fight1"] = {
					["DOTs"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["砾鳞凝视者"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 10,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 6,
					["Damage"] = 32765,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Nature"] = 5684,
						["Physical"] = 27081,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 5684,
								},
								["裂肠者"] = {
									["count"] = 1067,
								},
								["夺命黑鸦"] = {
									["count"] = 6386,
								},
								["发光的种子"] = {
									["count"] = 8806,
								},
								["自动射击"] = {
									["count"] = 9965,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 857,
								},
							},
							["amount"] = 32765,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["倒刺射击"] = {
									["count"] = 15,
								},
								["奇美拉射击"] = {
									["count"] = 10,
								},
							},
							["amount"] = 25,
						},
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["治疗宠物"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 5238,
									["min"] = 5238,
									["count"] = 3,
									["amount"] = 15714,
								},
							},
							["count"] = 3,
							["amount"] = 15714,
						},
						["进食"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 33504,
									["min"] = 33504,
									["count"] = 1,
									["amount"] = 33504,
								},
							},
							["count"] = 1,
							["amount"] = 33504,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 25,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 49218,
					["TimeSpent"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["裂肠者"] = {
									["count"] = 0.04,
								},
								["夺命黑鸦"] = {
									["count"] = 2.51,
								},
								["发光的种子"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 3.95,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.11,
								},
							},
							["amount"] = 9.11,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["倒刺射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ActiveTime"] = 9.11,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["奇美拉射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5684,
									["min"] = 5684,
									["count"] = 1,
									["amount"] = 5684,
								},
							},
							["count"] = 1,
							["amount"] = 5684,
						},
						["裂肠者"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1067,
									["min"] = 1067,
									["count"] = 1,
									["amount"] = 1067,
								},
							},
							["count"] = 1,
							["amount"] = 1067,
						},
						["夺命黑鸦"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3225,
									["min"] = 3225,
									["count"] = 1,
									["amount"] = 3225,
								},
								["Hit"] = {
									["max"] = 1581,
									["min"] = 1580,
									["count"] = 2,
									["amount"] = 3161,
								},
							},
							["count"] = 3,
							["amount"] = 6386,
						},
						["发光的种子"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8806,
									["min"] = 8806,
									["count"] = 1,
									["amount"] = 8806,
								},
							},
							["count"] = 1,
							["amount"] = 8806,
						},
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5355,
									["min"] = 5355,
									["count"] = 1,
									["amount"] = 5355,
								},
								["Hit"] = {
									["max"] = 2651,
									["min"] = 1959,
									["count"] = 2,
									["amount"] = 4610,
								},
							},
							["count"] = 3,
							["amount"] = 9965,
						},
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 429,
									["min"] = 428,
									["count"] = 2,
									["amount"] = 857,
								},
							},
							["count"] = 2,
							["amount"] = 857,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 9.11,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["裂肠者"] = {
									["count"] = 0.04,
								},
								["夺命黑鸦"] = {
									["count"] = 2.51,
								},
								["发光的种子"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 3.95,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.11,
								},
							},
							["amount"] = 9.11,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["治疗宠物"] = {
							["Details"] = {
								["裂蹄牛 <乐乐创想>"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["Absorbed"] = {
						["回声防护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["max"] = 1102,
									["min"] = 1084,
									["count"] = 2,
									["amount"] = 2186,
								},
							},
							["count"] = 2,
							["amount"] = 2186,
						},
					},
					["DOTs"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["疤爪"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 2186,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 2186,
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 5,
								},
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 25,
								},
							},
							["amount"] = 38,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 2186,
					},
					["ElementTaken"] = {
						["Melee"] = 2186,
					},
					["DOT_Time"] = 15,
					["Damage"] = 71976,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 3.84,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 59669,
						["Frost"] = 4103,
						["Nature"] = 8204,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 1102,
									["min"] = 1084,
									["count"] = 2,
									["amount"] = 2186,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 3,
							["amount"] = 2186,
						},
					},
					["DamagedWho"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["多重射击"] = {
									["count"] = 796,
								},
								["奇美拉射击"] = {
									["count"] = 4102,
								},
							},
							["amount"] = 4898,
						},
						["疤爪"] = {
							["Details"] = {
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1999,
								},
								["眼镜蛇射击"] = {
									["count"] = 12452,
								},
								["自动射击"] = {
									["count"] = 16087,
								},
								["裂肠者"] = {
									["count"] = 3244,
								},
								["奇美拉射击"] = {
									["count"] = 8205,
								},
								["多重射击"] = {
									["count"] = 398,
								},
								["夺命黑鸦"] = {
									["count"] = 24693,
								},
							},
							["amount"] = 67078,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2186,
								},
							},
							["amount"] = 2186,
						},
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["倒刺射击"] = {
									["count"] = 35,
								},
								["奇美拉射击"] = {
									["count"] = 30,
								},
								["野性守护"] = {
									["count"] = 75,
								},
							},
							["amount"] = 140,
						},
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 3,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.54,
								},
								["回声防护"] = {
									["count"] = 2.3,
								},
							},
							["amount"] = 3.84,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1223,
									["min"] = 1223,
									["count"] = 1,
									["amount"] = 1223,
								},
							},
							["count"] = 1,
							["amount"] = 1223,
						},
						["进食"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 34859,
									["min"] = 34859,
									["count"] = 1,
									["amount"] = 34859,
								},
							},
							["count"] = 1,
							["amount"] = 34859,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 826,
								},
								["回声防护"] = {
									["count"] = 2186,
								},
							},
							["amount"] = 3012,
						},
					},
					["EnergyGain"] = 140,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 36082,
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 0.73,
								},
								["眼镜蛇射击"] = {
									["count"] = 1.55,
								},
								["自动射击"] = {
									["count"] = 6.13,
								},
								["裂肠者"] = {
									["count"] = 0.03,
								},
								["奇美拉射击"] = {
									["count"] = 1.52,
								},
								["多重射击"] = {
									["count"] = 0.66,
								},
								["夺命黑鸦"] = {
									["count"] = 10.28,
								},
							},
							["amount"] = 20.9,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 0.14,
						},
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.54,
								},
								["回声防护"] = {
									["count"] = 2.3,
								},
							},
							["amount"] = 3.84,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 464,
									["min"] = 362,
									["count"] = 2,
									["amount"] = 826,
								},
							},
							["count"] = 2,
							["amount"] = 826,
						},
						["回声防护"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 1102,
									["min"] = 1084,
									["count"] = 2,
									["amount"] = 2186,
								},
							},
							["count"] = 2,
							["amount"] = 2186,
						},
					},
					["WhoHealed"] = {
						["乐乐创想"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 826,
								},
								["回声防护"] = {
									["count"] = 2186,
								},
							},
							["amount"] = 3012,
						},
					},
					["EnergyGained"] = {
						["倒刺射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 35,
								},
							},
							["amount"] = 35,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 30,
								},
							},
							["amount"] = 30,
						},
						["野性守护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 75,
								},
							},
							["amount"] = 75,
						},
					},
					["ActiveTime"] = 24.88,
					["Healing"] = 826,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 403,
									["min"] = 387,
									["count"] = 5,
									["amount"] = 1999,
								},
							},
							["count"] = 5,
							["amount"] = 1999,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4265,
									["min"] = 4265,
									["count"] = 1,
									["amount"] = 4265,
								},
								["Hit"] = {
									["max"] = 2091,
									["min"] = 2003,
									["count"] = 4,
									["amount"] = 8187,
								},
							},
							["count"] = 5,
							["amount"] = 12452,
						},
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3952,
									["min"] = 3952,
									["count"] = 1,
									["amount"] = 3952,
								},
								["Hit"] = {
									["max"] = 2413,
									["min"] = 1890,
									["count"] = 6,
									["amount"] = 12135,
								},
							},
							["count"] = 7,
							["amount"] = 16087,
						},
						["裂肠者"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2177,
									["min"] = 2177,
									["count"] = 1,
									["amount"] = 2177,
								},
								["Hit"] = {
									["max"] = 1067,
									["min"] = 1067,
									["count"] = 1,
									["amount"] = 1067,
								},
							},
							["count"] = 2,
							["amount"] = 3244,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4103,
									["min"] = 4102,
									["count"] = 3,
									["amount"] = 12307,
								},
							},
							["count"] = 3,
							["amount"] = 12307,
						},
						["多重射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 398,
									["min"] = 398,
									["count"] = 3,
									["amount"] = 1194,
								},
							},
							["count"] = 3,
							["amount"] = 1194,
						},
						["夺命黑鸦"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2430,
									["min"] = 2327,
									["count"] = 5,
									["amount"] = 11942,
								},
								["Hit"] = {
									["max"] = 1191,
									["min"] = 1141,
									["count"] = 11,
									["amount"] = 12751,
								},
							},
							["count"] = 16,
							["amount"] = 24693,
						},
					},
					["HealingTaken"] = 3012,
					["RageGain"] = 0,
					["TimeDamage"] = 21.04,
					["TimeDamaging"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 0.14,
						},
						["疤爪"] = {
							["Details"] = {
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 0.73,
								},
								["眼镜蛇射击"] = {
									["count"] = 1.55,
								},
								["自动射击"] = {
									["count"] = 6.13,
								},
								["裂肠者"] = {
									["count"] = 0.03,
								},
								["奇美拉射击"] = {
									["count"] = 1.52,
								},
								["多重射击"] = {
									["count"] = 0.66,
								},
								["夺命黑鸦"] = {
									["count"] = 10.28,
								},
							},
							["amount"] = 20.9,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["砾鳞凝视者"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 10,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 6,
					["Damage"] = 32765,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Nature"] = 5684,
						["Physical"] = 27081,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 5684,
								},
								["裂肠者"] = {
									["count"] = 1067,
								},
								["夺命黑鸦"] = {
									["count"] = 6386,
								},
								["发光的种子"] = {
									["count"] = 8806,
								},
								["自动射击"] = {
									["count"] = 9965,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 857,
								},
							},
							["amount"] = 32765,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["倒刺射击"] = {
									["count"] = 15,
								},
								["奇美拉射击"] = {
									["count"] = 10,
								},
							},
							["amount"] = 25,
						},
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
						["治疗宠物"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 5238,
									["min"] = 5238,
									["count"] = 3,
									["amount"] = 15714,
								},
							},
							["count"] = 3,
							["amount"] = 15714,
						},
						["进食"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 33504,
									["min"] = 33504,
									["count"] = 1,
									["amount"] = 33504,
								},
							},
							["count"] = 1,
							["amount"] = 33504,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 25,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 49218,
					["TimeSpent"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["裂肠者"] = {
									["count"] = 0.04,
								},
								["夺命黑鸦"] = {
									["count"] = 2.51,
								},
								["发光的种子"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 3.95,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.11,
								},
							},
							["amount"] = 9.11,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["倒刺射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 15,
								},
							},
							["amount"] = 15,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 10,
								},
							},
							["amount"] = 10,
						},
					},
					["ActiveTime"] = 9.11,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["奇美拉射击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5684,
									["min"] = 5684,
									["count"] = 1,
									["amount"] = 5684,
								},
							},
							["count"] = 1,
							["amount"] = 5684,
						},
						["裂肠者"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1067,
									["min"] = 1067,
									["count"] = 1,
									["amount"] = 1067,
								},
							},
							["count"] = 1,
							["amount"] = 1067,
						},
						["夺命黑鸦"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3225,
									["min"] = 3225,
									["count"] = 1,
									["amount"] = 3225,
								},
								["Hit"] = {
									["max"] = 1581,
									["min"] = 1580,
									["count"] = 2,
									["amount"] = 3161,
								},
							},
							["count"] = 3,
							["amount"] = 6386,
						},
						["发光的种子"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8806,
									["min"] = 8806,
									["count"] = 1,
									["amount"] = 8806,
								},
							},
							["count"] = 1,
							["amount"] = 8806,
						},
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5355,
									["min"] = 5355,
									["count"] = 1,
									["amount"] = 5355,
								},
								["Hit"] = {
									["max"] = 2651,
									["min"] = 1959,
									["count"] = 2,
									["amount"] = 4610,
								},
							},
							["count"] = 3,
							["amount"] = 9965,
						},
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 429,
									["min"] = 428,
									["count"] = 2,
									["amount"] = 857,
								},
							},
							["count"] = 2,
							["amount"] = 857,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 9.11,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["裂肠者"] = {
									["count"] = 0.04,
								},
								["夺命黑鸦"] = {
									["count"] = 2.51,
								},
								["发光的种子"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 3.95,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.11,
								},
							},
							["amount"] = 9.11,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["治疗宠物"] = {
							["Details"] = {
								["裂蹄牛 <乐乐创想>"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["疤爪"] = {
									["count"] = 15,
								},
								["砾鳞凝视者"] = {
									["count"] = 6,
								},
								["砾鳞蜥蜴"] = {
									["count"] = 27,
								},
							},
							["amount"] = 48,
						},
					},
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 0.73,
								},
								["眼镜蛇射击"] = {
									["count"] = 1.55,
								},
								["自动射击"] = {
									["count"] = 6.13,
								},
								["裂肠者"] = {
									["count"] = 0.03,
								},
								["奇美拉射击"] = {
									["count"] = 1.52,
								},
								["多重射击"] = {
									["count"] = 0.66,
								},
								["夺命黑鸦"] = {
									["count"] = 10.28,
								},
							},
							["amount"] = 20.9,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["裂肠者"] = {
									["count"] = 0.04,
								},
								["夺命黑鸦"] = {
									["count"] = 2.51,
								},
								["发光的种子"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 3.95,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.11,
								},
							},
							["amount"] = 9.11,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["夺命黑鸦"] = {
									["count"] = 3.37,
								},
								["裂肠者"] = {
									["count"] = 0.08,
								},
								["听从我的召唤"] = {
									["count"] = 0.03,
								},
								["奇美拉射击"] = {
									["count"] = 1.46,
								},
								["自动射击"] = {
									["count"] = 8.68,
								},
								["多重射击"] = {
									["count"] = 4.74,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 5.26,
								},
							},
							["amount"] = 23.62,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 0.14,
						},
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 4.55,
								},
								["回声防护"] = {
									["count"] = 13.2,
								},
								["吸血"] = {
									["count"] = 20.96,
								},
								["进食"] = {
									["count"] = 0.04,
								},
							},
							["amount"] = 38.75,
						},
					},
					["WhoHealed"] = {
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 16191,
								},
								["回声防护"] = {
									["count"] = 28541,
								},
								["吸血"] = {
									["count"] = 10333,
								},
								["进食"] = {
									["count"] = 33504,
								},
							},
							["amount"] = 88569,
						},
					},
					["Absorbs"] = 28541,
					["Overhealing"] = 96587,
					["ElementTaken"] = {
						["Melee"] = 47110,
						["Nature"] = 43625,
					},
					["DOT_Time"] = 48,
					["Damage"] = 175561,
					["TimeHeal"] = 38.75,
					["ElementDone"] = {
						["Physical"] = 123776,
						["Frost"] = 12308,
						["Nature"] = 39477,
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 5684,
								},
								["裂肠者"] = {
									["count"] = 1067,
								},
								["夺命黑鸦"] = {
									["count"] = 6386,
								},
								["发光的种子"] = {
									["count"] = 8806,
								},
								["自动射击"] = {
									["count"] = 9965,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 857,
								},
							},
							["amount"] = 32765,
						},
						["疤爪"] = {
							["Details"] = {
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1999,
								},
								["眼镜蛇射击"] = {
									["count"] = 12452,
								},
								["自动射击"] = {
									["count"] = 16087,
								},
								["裂肠者"] = {
									["count"] = 3244,
								},
								["奇美拉射击"] = {
									["count"] = 8205,
								},
								["多重射击"] = {
									["count"] = 398,
								},
								["夺命黑鸦"] = {
									["count"] = 24693,
								},
							},
							["amount"] = 67078,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["多重射击"] = {
									["count"] = 796,
								},
								["奇美拉射击"] = {
									["count"] = 4102,
								},
							},
							["amount"] = 4898,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["夺命黑鸦"] = {
									["count"] = 3863,
								},
								["裂肠者"] = {
									["count"] = 4268,
								},
								["听从我的召唤"] = {
									["count"] = 13117,
								},
								["奇美拉射击"] = {
									["count"] = 20677,
								},
								["自动射击"] = {
									["count"] = 18097,
								},
								["多重射击"] = {
									["count"] = 7238,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 3560,
								},
							},
							["amount"] = 70820,
						},
					},
					["WhoDamaged"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2186,
								},
							},
							["amount"] = 2186,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 43625,
								},
								["肉搏"] = {
									["count"] = 44924,
								},
							},
							["amount"] = 88549,
						},
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["倒刺射击"] = {
									["count"] = 100,
								},
								["奇美拉射击"] = {
									["count"] = 79,
								},
								["野性守护"] = {
									["count"] = 80,
								},
							},
							["amount"] = 259,
						},
					},
					["Absorbed"] = {
						["回声防护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["max"] = 7092,
									["min"] = 235,
									["count"] = 11,
									["amount"] = 28541,
								},
							},
							["count"] = 11,
							["amount"] = 28541,
						},
					},
					["TimeHealing"] = {
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 4.55,
								},
								["回声防护"] = {
									["count"] = 13.2,
								},
								["吸血"] = {
									["count"] = 20.96,
								},
								["进食"] = {
									["count"] = 0.04,
								},
							},
							["amount"] = 38.75,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1223,
									["min"] = 463,
									["count"] = 2,
									["amount"] = 1686,
								},
							},
							["count"] = 2,
							["amount"] = 1686,
						},
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4579,
									["min"] = 4579,
									["count"] = 1,
									["amount"] = 4579,
								},
								["Hit"] = {
									["max"] = 1007,
									["min"] = 1007,
									["count"] = 1,
									["amount"] = 1007,
								},
							},
							["count"] = 2,
							["amount"] = 5586,
						},
						["治疗宠物"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 5238,
									["min"] = 5238,
									["count"] = 4,
									["amount"] = 20952,
								},
							},
							["count"] = 4,
							["amount"] = 20952,
						},
						["进食"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 34859,
									["min"] = 33504,
									["count"] = 2,
									["amount"] = 68363,
								},
							},
							["count"] = 2,
							["amount"] = 68363,
						},
					},
					["EnergyGain"] = 259,
					["ElementTakenAbsorb"] = {
						["Melee"] = 21449,
						["Nature"] = 7092,
					},
					["ActiveTime"] = 92.52,
					["Heals"] = {
						["冷漠面容"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6275,
									["min"] = 1696,
									["count"] = 2,
									["amount"] = 7971,
								},
								["Hit"] = {
									["max"] = 3076,
									["min"] = 2068,
									["count"] = 3,
									["amount"] = 8220,
								},
							},
							["count"] = 5,
							["amount"] = 16191,
						},
						["回声防护"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 7092,
									["min"] = 235,
									["count"] = 11,
									["amount"] = 28541,
								},
							},
							["count"] = 11,
							["amount"] = 28541,
						},
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1321,
									["min"] = 49,
									["count"] = 18,
									["amount"] = 10333,
								},
							},
							["count"] = 18,
							["amount"] = 10333,
						},
						["进食"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 33504,
									["min"] = 33504,
									["count"] = 1,
									["amount"] = 33504,
								},
							},
							["count"] = 1,
							["amount"] = 33504,
						},
					},
					["HOTs"] = {
						["治疗宠物"] = {
							["Details"] = {
								["裂蹄牛 <乐乐创想>"] = {
									["count"] = 12,
								},
							},
							["amount"] = 12,
						},
					},
					["EnergyGained"] = {
						["倒刺射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 100,
								},
							},
							["amount"] = 100,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 79,
								},
							},
							["amount"] = 79,
						},
						["野性守护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 80,
								},
							},
							["amount"] = 80,
						},
					},
					["HOT_Time"] = 12,
					["Healing"] = 60028,
					["HealedWho"] = {
						["乐乐创想"] = {
							["Details"] = {
								["冷漠面容"] = {
									["count"] = 16191,
								},
								["回声防护"] = {
									["count"] = 28541,
								},
								["吸血"] = {
									["count"] = 10333,
								},
								["进食"] = {
									["count"] = 33504,
								},
							},
							["amount"] = 88569,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 10,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 11,
								},
							},
							["amount"] = 23,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 6,
						},
					},
					["Attacks"] = {
						["听从我的召唤"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6161,
									["min"] = 2641,
									["count"] = 2,
									["amount"] = 8802,
								},
								["Hit"] = {
									["max"] = 3021,
									["min"] = 1294,
									["count"] = 2,
									["amount"] = 4315,
								},
							},
							["count"] = 4,
							["amount"] = 13117,
						},
						["自动射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5355,
									["min"] = 3900,
									["count"] = 3,
									["amount"] = 13207,
								},
								["Hit"] = {
									["max"] = 2651,
									["min"] = 1890,
									["count"] = 15,
									["amount"] = 30942,
								},
							},
							["count"] = 18,
							["amount"] = 44149,
						},
						["倒刺射击 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 429,
									["min"] = 386,
									["count"] = 16,
									["amount"] = 6416,
								},
							},
							["count"] = 16,
							["amount"] = 6416,
						},
						["发光的种子"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8806,
									["min"] = 8806,
									["count"] = 1,
									["amount"] = 8806,
								},
							},
							["count"] = 1,
							["amount"] = 8806,
						},
						["眼镜蛇射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4265,
									["min"] = 4265,
									["count"] = 1,
									["amount"] = 4265,
								},
								["Hit"] = {
									["max"] = 2091,
									["min"] = 2003,
									["count"] = 4,
									["amount"] = 8187,
								},
							},
							["count"] = 5,
							["amount"] = 12452,
						},
						["夺命黑鸦"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3225,
									["min"] = 2327,
									["count"] = 6,
									["amount"] = 15167,
								},
								["Hit"] = {
									["max"] = 1581,
									["min"] = 1141,
									["count"] = 16,
									["amount"] = 19775,
								},
							},
							["count"] = 22,
							["amount"] = 34942,
						},
						["奇美拉射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8369,
									["min"] = 8369,
									["count"] = 1,
									["amount"] = 8369,
								},
								["Hit"] = {
									["max"] = 5684,
									["min"] = 4102,
									["count"] = 7,
									["amount"] = 30299,
								},
							},
							["count"] = 8,
							["amount"] = 38668,
						},
						["多重射击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 811,
									["min"] = 811,
									["count"] = 5,
									["amount"] = 4055,
								},
								["Hit"] = {
									["max"] = 398,
									["min"] = 397,
									["count"] = 11,
									["amount"] = 4377,
								},
							},
							["count"] = 16,
							["amount"] = 8432,
						},
						["裂肠者"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2177,
									["min"] = 2177,
									["count"] = 1,
									["amount"] = 2177,
								},
								["Hit"] = {
									["max"] = 1067,
									["min"] = 1067,
									["count"] = 6,
									["amount"] = 6402,
								},
							},
							["count"] = 7,
							["amount"] = 8579,
						},
					},
					["HealingTaken"] = 88569,
					["DamageTaken"] = 90735,
					["TimeDamage"] = 53.77,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["裂肠者"] = {
									["count"] = 0.04,
								},
								["夺命黑鸦"] = {
									["count"] = 2.51,
								},
								["发光的种子"] = {
									["count"] = 1.5,
								},
								["自动射击"] = {
									["count"] = 3.95,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 1.11,
								},
							},
							["amount"] = 9.11,
						},
						["疤爪"] = {
							["Details"] = {
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 0.73,
								},
								["眼镜蛇射击"] = {
									["count"] = 1.55,
								},
								["自动射击"] = {
									["count"] = 6.13,
								},
								["裂肠者"] = {
									["count"] = 0.03,
								},
								["奇美拉射击"] = {
									["count"] = 1.52,
								},
								["多重射击"] = {
									["count"] = 0.66,
								},
								["夺命黑鸦"] = {
									["count"] = 10.28,
								},
							},
							["amount"] = 20.9,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["奇美拉射击"] = {
									["count"] = 0.14,
								},
							},
							["amount"] = 0.14,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["夺命黑鸦"] = {
									["count"] = 3.37,
								},
								["裂肠者"] = {
									["count"] = 0.08,
								},
								["听从我的召唤"] = {
									["count"] = 0.03,
								},
								["奇美拉射击"] = {
									["count"] = 1.46,
								},
								["自动射击"] = {
									["count"] = 8.68,
								},
								["多重射击"] = {
									["count"] = 4.74,
								},
								["倒刺射击 (伤害/跳)"] = {
									["count"] = 5.26,
								},
							},
							["amount"] = 23.62,
						},
					},
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 6,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 6,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 23,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 23,
						},
					},
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 7092,
									["min"] = 7092,
									["count"] = 1,
									["amount"] = 7092,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 6,
							["amount"] = 7092,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 13,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 5637,
									["min"] = 235,
									["count"] = 10,
									["amount"] = 21449,
								},
							},
							["count"] = 23,
							["amount"] = 21449,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 16,
								},
								["Crit"] = {
									["count"] = 16,
								},
								["Hit"] = {
									["count"] = 53,
								},
							},
							["amount"] = 85,
						},
						["Frost"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["Nature"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
					},
				},
			},
			["UnitLockout"] = 2124.029,
			["LastActive"] = 2261.029,
		},
		["灵魂兽 <乐乐创想>"] = {
			["GUID"] = "Pet-0-3045-1897-8880-103326-010213CB44",
			["TimeLast"] = {
				["HealingTaken"] = 2213.021,
				["TimeHeal"] = 2213.021,
				["Healing"] = 2213.021,
				["ActiveTime"] = 2261.029,
				["TimeDamage"] = 2261.029,
				["OVERALL"] = 2261.029,
				["DamageTaken"] = 2175.019,
				["Damage"] = 2261.029,
			},
			["LastAttackedBy"] = "砾鳞蜥蜴",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"HEAL", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"HEAL", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					10.5, -- [1]
				},
				["HealingTaken"] = {
					8376, -- [1]
				},
				["ActiveTime"] = {
					71.12, -- [1]
				},
				["TimeDamage"] = {
					60.62, -- [1]
				},
				["Healing"] = {
					8376, -- [1]
				},
				["DamageTaken"] = {
					12549, -- [1]
				},
				["Damage"] = {
					100207, -- [1]
				},
			},
			["enClass"] = "PET",
			["LastDamageTaken"] = 6245,
			["level"] = 1,
			["LastDamageAbility"] = "岩石吐息",
			["LastFightIn"] = 5,
			["LastEventHealthMax"] = {
				[40] = 74830,
				[39] = 74830,
				[41] = 328410,
			},
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "乐乐创想",
			["LastEventHealth"] = {
				[40] = 67054,
				[39] = 67054,
				[41] = 328410,
			},
			["LastHealTime"] = 2213.717,
			["NextEventNum"] = 2,
			["LastDamageTime"] = 2261.963,
			["LastEvents"] = {
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Crit -1682 (Physical)", -- [1]
				"灵魂兽 <乐乐创想> 野兽顺劈 断喙雏鸟 Hit -446 (Physical)", -- [2]
				"灵魂兽 <乐乐创想> 吸血 灵魂兽 <乐乐创想> Hit +876", -- [3]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -595 (Physical)", -- [4]
				"灵魂兽 <乐乐创想> 践踏 疤爪 Crit -1822 (Physical)", -- [5]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -595 (Physical)", -- [6]
				"灵魂兽 <乐乐创想> 杀戮命令 疤爪 Hit -2811 (Physical)", -- [7]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -596 (Physical)", -- [8]
				"灵魂兽 <乐乐创想> 吸血 灵魂兽 <乐乐创想> Hit +961", -- [9]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -622 (Physical)", -- [10]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -621 (Physical)", -- [11]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -621 (Physical)", -- [12]
				"灵魂兽 <乐乐创想> 践踏 疤爪 Hit -932 (Physical)", -- [13]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -622 (Physical)", -- [14]
				"灵魂兽 <乐乐创想> 杀戮命令 疤爪 Hit -2850 (Physical)", -- [15]
				"灵魂兽 <乐乐创想> 吸血 灵魂兽 <乐乐创想> Hit +940", -- [16]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -621 (Physical)", -- [17]
				"灵魂兽 <乐乐创想> 肉搏 疤爪 Hit -622 (Physical)", -- [18]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [19]
				"灵魂兽 <乐乐创想> 践踏 砾鳞蜥蜴 Hit -892 (Physical)", -- [20]
				"灵魂兽 <乐乐创想> 践踏 砾鳞蜥蜴 Hit -893 (Physical)", -- [21]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [22]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [23]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -446 (Physical)", -- [24]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [25]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [26]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [27]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [28]
				"灵魂兽 <乐乐创想> 杀戮命令 砾鳞蜥蜴 Hit -2714 (Physical)", -- [29]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [30]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -446 (Physical)", -- [31]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [32]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [33]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -446 (Physical)", -- [34]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -446 (Physical)", -- [35]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -596 (Physical)", -- [36]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [37]
				"灵魂兽 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [38]
				"灵魂兽 <乐乐创想> 践踏 砾鳞蜥蜴 Crit -1822 (Physical)", -- [39]
				"灵魂兽 <乐乐创想> 践踏 砾鳞蜥蜴 Hit -893 (Physical)", -- [40]
				"灵魂兽 <乐乐创想> 杀戮命令 砾鳞凝视者 Hit -2713 (Physical)", -- [41]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Hit -595 (Physical)", -- [42]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Hit -595 (Physical)", -- [43]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [44]
				"灵魂兽 <乐乐创想> 践踏 砾鳞凝视者 Hit -1237 (Physical)", -- [45]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [46]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [47]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [48]
				"灵魂兽 <乐乐创想> 杀戮命令 砾鳞凝视者 Crit -7783 (Physical)", -- [49]
				"灵魂兽 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [50]
			},
			["Name"] = "灵魂兽",
			["LastEventTimes"] = {
				2261.963, -- [1]
				2202.649, -- [2]
				2203.19, -- [3]
				2204.51, -- [4]
				2204.649, -- [5]
				2205.987, -- [6]
				2207.278, -- [7]
				2207.444, -- [8]
				2208.436, -- [9]
				2208.896, -- [10]
				2210.347, -- [11]
				2211.804, -- [12]
				2211.954, -- [13]
				2212.996, -- [14]
				2213.213, -- [15]
				2213.717, -- [16]
				2214.18, -- [17]
				2215.365, -- [18]
				2238.435, -- [19]
				2239.124, -- [20]
				2239.124, -- [21]
				2240.049, -- [22]
				2241.492, -- [23]
				2241.515, -- [24]
				2241.515, -- [25]
				2242.957, -- [26]
				2242.98, -- [27]
				2242.98, -- [28]
				2243.784, -- [29]
				2244.42, -- [30]
				2244.436, -- [31]
				2244.436, -- [32]
				2245.857, -- [33]
				2245.89, -- [34]
				2245.89, -- [35]
				2247.358, -- [36]
				2247.385, -- [37]
				2247.385, -- [38]
				2248.612, -- [39]
				2248.612, -- [40]
				2252.059, -- [41]
				2253.069, -- [42]
				2254.516, -- [43]
				2255.966, -- [44]
				2256.456, -- [45]
				2257.23, -- [46]
				2258.413, -- [47]
				2259.599, -- [48]
				2259.613, -- [49]
				2260.783, -- [50]
			},
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				true, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				true, -- [9]
				false, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 15,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 15846,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 4166,
						["Physical"] = 11680,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 4500,
								},
								["杀戮命令"] = {
									["count"] = 2714,
								},
								["野兽顺劈"] = {
									["count"] = 4466,
								},
								["肉搏"] = {
									["count"] = 4166,
								},
							},
							["amount"] = 15846,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 1.92,
								},
								["杀戮命令"] = {
									["count"] = 0.8,
								},
								["野兽顺劈"] = {
									["count"] = 0.12,
								},
								["肉搏"] = {
									["count"] = 8.83,
								},
							},
							["amount"] = 11.67,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 11.67,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1822,
									["min"] = 1822,
									["count"] = 1,
									["amount"] = 1822,
								},
								["Hit"] = {
									["max"] = 893,
									["min"] = 892,
									["count"] = 3,
									["amount"] = 2678,
								},
							},
							["count"] = 4,
							["amount"] = 4500,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2714,
									["min"] = 2714,
									["count"] = 1,
									["amount"] = 2714,
								},
							},
							["count"] = 1,
							["amount"] = 2714,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 447,
									["min"] = 446,
									["count"] = 10,
									["amount"] = 4466,
								},
							},
							["count"] = 10,
							["amount"] = 4466,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 596,
									["min"] = 595,
									["count"] = 7,
									["amount"] = 4166,
								},
							},
							["count"] = 7,
							["amount"] = 4166,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 11.67,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 1.92,
								},
								["杀戮命令"] = {
									["count"] = 0.8,
								},
								["野兽顺劈"] = {
									["count"] = 0.12,
								},
								["肉搏"] = {
									["count"] = 8.83,
								},
							},
							["amount"] = 11.67,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 4,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 14035,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 5015,
						["Physical"] = 9020,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 1237,
								},
								["杀戮命令"] = {
									["count"] = 7783,
								},
								["肉搏"] = {
									["count"] = 5015,
								},
							},
							["amount"] = 14035,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1729,
								},
							},
							["amount"] = 1729,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 1.5,
								},
								["杀戮命令"] = {
									["count"] = 0.51,
								},
								["肉搏"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 4.55,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1729,
									["min"] = 1729,
									["count"] = 1,
									["amount"] = 1729,
								},
							},
							["count"] = 1,
							["amount"] = 1729,
						},
					},
					["WhoHealed"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1729,
								},
							},
							["amount"] = 1729,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 6.05,
					["Healing"] = 1729,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1237,
									["min"] = 1237,
									["count"] = 1,
									["amount"] = 1237,
								},
							},
							["count"] = 1,
							["amount"] = 1237,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7783,
									["min"] = 7783,
									["count"] = 1,
									["amount"] = 7783,
								},
							},
							["count"] = 1,
							["amount"] = 7783,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1683,
									["min"] = 1682,
									["count"] = 2,
									["amount"] = 3365,
								},
								["Hit"] = {
									["max"] = 825,
									["min"] = 825,
									["count"] = 2,
									["amount"] = 1650,
								},
							},
							["count"] = 4,
							["amount"] = 5015,
						},
					},
					["HealingTaken"] = 1729,
					["RageGain"] = 0,
					["TimeDamage"] = 4.55,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 1.5,
								},
								["杀戮命令"] = {
									["count"] = 0.51,
								},
								["肉搏"] = {
									["count"] = 2.54,
								},
							},
							["amount"] = 4.55,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeHealing"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0,
								},
								["杀戮命令"] = {
									["count"] = 0,
								},
								["野兽顺劈"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["ElementTaken"] = {
						["Nature"] = 0,
					},
					["Damage"] = 0,
					["TimeHeal"] = 0,
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["WhoHealed"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["HealedWho"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0,
								},
								["杀戮命令"] = {
									["count"] = 0,
								},
								["野兽顺劈"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0,
								},
								["杀戮命令"] = {
									["count"] = 0,
								},
								["野兽顺劈"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 18730,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 6997,
						["Physical"] = 11733,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 10496,
								},
								["践踏"] = {
									["count"] = 1237,
								},
								["肉搏"] = {
									["count"] = 6997,
								},
							},
							["amount"] = 18730,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.49,
								},
								["肉搏"] = {
									["count"] = 9.4,
								},
							},
							["amount"] = 11.4,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 11.4,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7783,
									["min"] = 7783,
									["count"] = 1,
									["amount"] = 7783,
								},
								["Hit"] = {
									["max"] = 2713,
									["min"] = 2713,
									["count"] = 1,
									["amount"] = 2713,
								},
							},
							["count"] = 2,
							["amount"] = 10496,
						},
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1237,
									["min"] = 1237,
									["count"] = 1,
									["amount"] = 1237,
								},
							},
							["count"] = 1,
							["amount"] = 1237,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1682,
									["min"] = 1682,
									["count"] = 1,
									["amount"] = 1682,
								},
								["Hit"] = {
									["max"] = 825,
									["min"] = 595,
									["count"] = 7,
									["amount"] = 5315,
								},
							},
							["count"] = 8,
							["amount"] = 6997,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 11.4,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.49,
								},
								["肉搏"] = {
									["count"] = 9.4,
								},
							},
							["amount"] = 11.4,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 13,
								},
							},
							["amount"] = 14,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 8,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 25270,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 6,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 9413,
						["Physical"] = 15857,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 1338,
								},
							},
							["amount"] = 1338,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 11765,
								},
								["践踏"] = {
									["count"] = 2754,
								},
								["肉搏"] = {
									["count"] = 9413,
								},
							},
							["amount"] = 23932,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 3603,
								},
							},
							["amount"] = 3603,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 16.18,
								},
							},
							["amount"] = 20.7,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.06,
								},
							},
							["amount"] = 0.06,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 961,
									["min"] = 826,
									["count"] = 4,
									["amount"] = 3603,
								},
							},
							["count"] = 4,
							["amount"] = 3603,
						},
					},
					["WhoHealed"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 3603,
								},
							},
							["amount"] = 3603,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 26.76,
					["Healing"] = 3603,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["杀戮命令"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3391,
									["min"] = 2713,
									["count"] = 4,
									["amount"] = 11765,
								},
							},
							["count"] = 4,
							["amount"] = 11765,
						},
						["践踏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1822,
									["min"] = 1822,
									["count"] = 1,
									["amount"] = 1822,
								},
								["Hit"] = {
									["max"] = 932,
									["min"] = 932,
									["count"] = 1,
									["amount"] = 932,
								},
							},
							["count"] = 2,
							["amount"] = 2754,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 446,
									["min"] = 446,
									["count"] = 3,
									["amount"] = 1338,
								},
							},
							["count"] = 3,
							["amount"] = 1338,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1518,
									["min"] = 1518,
									["count"] = 1,
									["amount"] = 1518,
								},
								["Hit"] = {
									["max"] = 622,
									["min"] = 595,
									["count"] = 13,
									["amount"] = 7895,
								},
							},
							["count"] = 14,
							["amount"] = 9413,
						},
					},
					["HealingTaken"] = 3603,
					["RageGain"] = 0,
					["TimeDamage"] = 20.76,
					["TimeDamaging"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.06,
								},
							},
							["amount"] = 0.06,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 16.18,
								},
							},
							["amount"] = 20.7,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 8,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 18730,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 6997,
						["Physical"] = 11733,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 10496,
								},
								["践踏"] = {
									["count"] = 1237,
								},
								["肉搏"] = {
									["count"] = 6997,
								},
							},
							["amount"] = 18730,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.49,
								},
								["肉搏"] = {
									["count"] = 9.4,
								},
							},
							["amount"] = 11.4,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 11.4,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7783,
									["min"] = 7783,
									["count"] = 1,
									["amount"] = 7783,
								},
								["Hit"] = {
									["max"] = 2713,
									["min"] = 2713,
									["count"] = 1,
									["amount"] = 2713,
								},
							},
							["count"] = 2,
							["amount"] = 10496,
						},
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1237,
									["min"] = 1237,
									["count"] = 1,
									["amount"] = 1237,
								},
							},
							["count"] = 1,
							["amount"] = 1237,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1682,
									["min"] = 1682,
									["count"] = 1,
									["amount"] = 1682,
								},
								["Hit"] = {
									["max"] = 825,
									["min"] = 595,
									["count"] = 7,
									["amount"] = 5315,
								},
							},
							["count"] = 8,
							["amount"] = 6997,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 11.4,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.49,
								},
								["肉搏"] = {
									["count"] = 9.4,
								},
							},
							["amount"] = 11.4,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 10.5,
								},
							},
							["amount"] = 10.5,
						},
					},
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 16.18,
								},
							},
							["amount"] = 20.7,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.49,
								},
								["肉搏"] = {
									["count"] = 9.4,
								},
							},
							["amount"] = 11.4,
						},
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 10.5,
								},
							},
							["amount"] = 10.5,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.06,
								},
							},
							["amount"] = 0.06,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 4.68,
								},
								["杀戮命令"] = {
									["count"] = 2.27,
								},
								["野兽顺劈"] = {
									["count"] = 0.24,
								},
								["肉搏"] = {
									["count"] = 21.27,
								},
							},
							["amount"] = 28.46,
						},
					},
					["DamageTaken"] = 12549,
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 71.12,
					["ElementTaken"] = {
						["Nature"] = 12549,
					},
					["Damage"] = 100207,
					["TimeHeal"] = 10.5,
					["ElementHitsTaken"] = {
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["WhoHealed"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 8376,
								},
							},
							["amount"] = 8376,
						},
					},
					["Healing"] = 8376,
					["HealedWho"] = {
						["灵魂兽 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 8376,
								},
							},
							["amount"] = 8376,
						},
					},
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1966,
									["min"] = 826,
									["count"] = 7,
									["amount"] = 8376,
								},
							},
							["count"] = 7,
							["amount"] = 8376,
						},
					},
					["ElementDone"] = {
						["Melee"] = 32955,
						["Physical"] = 67252,
					},
					["HealingTaken"] = 8376,
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 10496,
								},
								["践踏"] = {
									["count"] = 1237,
								},
								["肉搏"] = {
									["count"] = 6997,
								},
							},
							["amount"] = 18730,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 11765,
								},
								["践踏"] = {
									["count"] = 2754,
								},
								["肉搏"] = {
									["count"] = 9413,
								},
							},
							["amount"] = 23932,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 1338,
								},
							},
							["amount"] = 1338,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 13844,
								},
								["杀戮命令"] = {
									["count"] = 13210,
								},
								["野兽顺劈"] = {
									["count"] = 12608,
								},
								["肉搏"] = {
									["count"] = 16545,
								},
							},
							["amount"] = 56207,
						},
					},
					["TimeDamage"] = 60.62,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.49,
								},
								["肉搏"] = {
									["count"] = 9.4,
								},
							},
							["amount"] = 11.4,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 16.18,
								},
							},
							["amount"] = 20.7,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.06,
								},
							},
							["amount"] = 0.06,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 4.68,
								},
								["杀戮命令"] = {
									["count"] = 2.27,
								},
								["野兽顺劈"] = {
									["count"] = 0.24,
								},
								["肉搏"] = {
									["count"] = 21.27,
								},
							},
							["amount"] = 28.46,
						},
					},
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1822,
									["min"] = 1821,
									["count"] = 4,
									["amount"] = 7286,
								},
								["Hit"] = {
									["max"] = 1237,
									["min"] = 892,
									["count"] = 11,
									["amount"] = 10549,
								},
							},
							["count"] = 15,
							["amount"] = 17835,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7783,
									["min"] = 7783,
									["count"] = 2,
									["amount"] = 15566,
								},
								["Hit"] = {
									["max"] = 3391,
									["min"] = 2713,
									["count"] = 7,
									["amount"] = 19905,
								},
							},
							["count"] = 9,
							["amount"] = 35471,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 911,
									["min"] = 446,
									["count"] = 25,
									["amount"] = 13946,
								},
							},
							["count"] = 25,
							["amount"] = 13946,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1683,
									["min"] = 1214,
									["count"] = 7,
									["amount"] = 10208,
								},
								["Hit"] = {
									["max"] = 825,
									["min"] = 595,
									["count"] = 35,
									["amount"] = 22747,
								},
							},
							["count"] = 42,
							["amount"] = 32955,
						},
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 12549,
								},
							},
							["amount"] = 12549,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 7,
								},
								["Hit"] = {
									["count"] = 35,
								},
							},
							["amount"] = 42,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 43,
								},
							},
							["amount"] = 49,
						},
					},
				},
			},
			["UnitLockout"] = 2261.029,
			["LastActive"] = 2261.029,
		},
		["裂蹄牛 <乐乐创想>"] = {
			["GUID"] = "Pet-0-3045-1897-8880-86731-010212F255",
			["LastEventHealth"] = {
				74830, -- [1]
				74830, -- [2]
				74830, -- [3]
				74830, -- [4]
				66747, -- [5]
				66747, -- [6]
				66747, -- [7]
				66747, -- [8]
				66747, -- [9]
				60394, -- [10]
				60394, -- [11]
				60394, -- [12]
				60394, -- [13]
				60394, -- [14]
				74830, -- [15]
				74830, -- [16]
				74830, -- [17]
				74830, -- [18]
				74830, -- [19]
				74830, -- [20]
				74830, -- [21]
				74830, -- [22]
				74830, -- [23]
				74830, -- [24]
				74830, -- [25]
				74830, -- [26]
				74830, -- [27]
				74830, -- [28]
				74830, -- [29]
				74830, -- [30]
				74830, -- [31]
				74830, -- [32]
				74830, -- [33]
				74830, -- [34]
				74830, -- [35]
				74830, -- [36]
				74830, -- [37]
				74830, -- [38]
				74830, -- [39]
				74830, -- [40]
				74830, -- [41]
				74830, -- [42]
				74830, -- [43]
				74830, -- [44]
				74830, -- [45]
				74830, -- [46]
				74830, -- [47]
				74830, -- [48]
				74830, -- [49]
				74830, -- [50]
			},
			["LastAttackedBy"] = "砾鳞蜥蜴",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"HEAL", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"HEAL", -- [24]
				"HEAL", -- [25]
				"DAMAGE", -- [26]
				"HEAL", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"HEAL", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"HEAL", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					7.5, -- [1]
				},
				["Healing"] = {
					32857, -- [1]
				},
				["DamageTaken"] = {
					42301, -- [1]
				},
				["EnergyGain"] = {
					77, -- [1]
				},
				["HealingTaken"] = {
					32857, -- [1]
				},
				["Overhealing"] = {
					31637, -- [1]
				},
				["TimeDamage"] = {
					61.29, -- [1]
				},
				["ActiveTime"] = {
					68.79, -- [1]
				},
				["Damage"] = {
					304634, -- [1]
				},
			},
			["enClass"] = "PET",
			["unit"] = "裂蹄牛",
			["level"] = 1,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 5,
			["LastHealTime"] = 2246.934,
			["type"] = "Pet",
			["FightsSaved"] = 5,
			["ownerName"] = "乐乐创想",
			["LastDamageTaken"] = 1950,
			["TimeLast"] = {
				["TimeHeal"] = 2246.025,
				["OVERALL"] = 2261.029,
				["DamageTaken"] = 2246.025,
				["EnergyGain"] = 2218.027,
				["HealingTaken"] = 2246.025,
				["Overhealing"] = 2246.025,
				["TimeDamage"] = 2261.029,
				["Healing"] = 2246.025,
				["ActiveTime"] = 2261.029,
				["Damage"] = 2261.029,
			},
			["LastEventHealthMax"] = {
				74830, -- [1]
				74830, -- [2]
				74830, -- [3]
				74830, -- [4]
				74830, -- [5]
				74830, -- [6]
				74830, -- [7]
				74830, -- [8]
				74830, -- [9]
				74830, -- [10]
				74830, -- [11]
				74830, -- [12]
				74830, -- [13]
				74830, -- [14]
				74830, -- [15]
				74830, -- [16]
				74830, -- [17]
				74830, -- [18]
				74830, -- [19]
				74830, -- [20]
				74830, -- [21]
				74830, -- [22]
				74830, -- [23]
				74830, -- [24]
				74830, -- [25]
				74830, -- [26]
				74830, -- [27]
				74830, -- [28]
				74830, -- [29]
				74830, -- [30]
				74830, -- [31]
				74830, -- [32]
				74830, -- [33]
				74830, -- [34]
				74830, -- [35]
				74830, -- [36]
				74830, -- [37]
				74830, -- [38]
				74830, -- [39]
				74830, -- [40]
				74830, -- [41]
				74830, -- [42]
				74830, -- [43]
				74830, -- [44]
				74830, -- [45]
				74830, -- [46]
				74830, -- [47]
				74830, -- [48]
				74830, -- [49]
				74830, -- [50]
			},
			["NextEventNum"] = 44,
			["LastDamageTime"] = 2261.963,
			["LastEvents"] = {
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [1]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -446 (Physical)", -- [2]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -446 (Physical)", -- [3]
				"裂蹄牛 <乐乐创想> 杀戮命令 砾鳞蜥蜴 Hit -2713 (Physical)", -- [4]
				"砾鳞蜥蜴 岩石吐息 裂蹄牛 <乐乐创想> Hit -8083 (Nature)", -- [5]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [6]
				"裂蹄牛 <乐乐创想> 拍击 砾鳞蜥蜴 Hit -4182 (Physical)", -- [7]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -3136 (Physical)", -- [8]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -3136 (Physical)", -- [9]
				"砾鳞蜥蜴 岩石吐息 裂蹄牛 <乐乐创想> Hit -6353 (Nature)", -- [10]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -595 (Physical)", -- [11]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -446 (Physical)", -- [12]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [13]
				"砾鳞蜥蜴 肉搏 裂蹄牛 <乐乐创想> Hit -1950 (Physical)", -- [14]
				"裂蹄牛 <乐乐创想> 吸血 裂蹄牛 <乐乐创想> Hit +17799 (1413 过量治疗)", -- [15]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞蜥蜴 Crit -1214 (Physical)", -- [16]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -911 (Physical)", -- [17]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -911 (Physical)", -- [18]
				"裂蹄牛 <乐乐创想> 拍击 砾鳞蜥蜴 Hit -4182 (Physical)", -- [19]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -3137 (Physical)", -- [20]
				"裂蹄牛 <乐乐创想> 践踏 砾鳞蜥蜴 Hit -893 (Physical)", -- [21]
				"裂蹄牛 <乐乐创想> 践踏 砾鳞蜥蜴 Hit -893 (Physical)", -- [22]
				"砾鳞蜥蜴 肉搏 裂蹄牛 <乐乐创想> Dodge (1)", -- [23]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [24]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5239 (5239 过量治疗)", -- [25]
				"裂蹄牛 <乐乐创想> 杀戮命令 砾鳞凝视者 Hit -2713 (Physical)", -- [26]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [27]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Hit -596 (Physical)", -- [28]
				"砾鳞凝视者 肉搏 裂蹄牛 <乐乐创想> Dodge (1)", -- [29]
				"裂蹄牛 <乐乐创想> 拍击 砾鳞凝视者 Crit -8531 (Physical)", -- [30]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Crit -1214 (Physical)", -- [31]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [32]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Hit -824 (Physical)", -- [33]
				"裂蹄牛 <乐乐创想> 拍击 砾鳞凝视者 Hit -5577 (Physical)", -- [34]
				"乐乐创想 治疗宠物 裂蹄牛 <乐乐创想> Tick +5238 (5238 过量治疗)", -- [35]
				"裂蹄牛 <乐乐创想> 践踏 砾鳞凝视者 Hit -1237 (Physical)", -- [36]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [37]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [38]
				"裂蹄牛 <乐乐创想> 拍击 砾鳞凝视者 Crit -11376 (Physical)", -- [39]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Crit -1683 (Physical)", -- [40]
				"裂蹄牛 <乐乐创想> 杀戮命令 砾鳞凝视者 Hit -3815 (Physical)", -- [41]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [42]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞凝视者 Hit -825 (Physical)", -- [43]
				"裂蹄牛 <乐乐创想> 吸血 裂蹄牛 <乐乐创想> Hit +4777 (728 过量治疗)", -- [44]
				"裂蹄牛 <乐乐创想> 肉搏 砾鳞蜥蜴 Hit -596 (Physical)", -- [45]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [46]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -447 (Physical)", -- [47]
				"裂蹄牛 <乐乐创想> 拍击 砾鳞蜥蜴 Crit -8531 (Physical)", -- [48]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -6398 (Physical)", -- [49]
				"裂蹄牛 <乐乐创想> 野兽顺劈 砾鳞蜥蜴 Hit -6398 (Physical)", -- [50]
			},
			["Name"] = "裂蹄牛",
			["LastEventIncoming"] = {
				false, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				true, -- [5]
				false, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				true, -- [10]
				false, -- [11]
				false, -- [12]
				false, -- [13]
				true, -- [14]
				true, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				false, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				false, -- [26]
				true, -- [27]
				false, -- [28]
				true, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				false, -- [33]
				false, -- [34]
				true, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				true, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				false, -- [50]
			},
			["LastEventTimes"] = {
				2243.308, -- [1]
				2243.322, -- [2]
				2243.322, -- [3]
				2243.784, -- [4]
				2244.463, -- [5]
				2244.743, -- [6]
				2245.348, -- [7]
				2245.348, -- [8]
				2245.348, -- [9]
				2245.682, -- [10]
				2246.199, -- [11]
				2246.214, -- [12]
				2246.214, -- [13]
				2246.462, -- [14]
				2246.934, -- [15]
				2247.807, -- [16]
				2247.833, -- [17]
				2247.833, -- [18]
				2248.551, -- [19]
				2248.568, -- [20]
				2248.612, -- [21]
				2248.612, -- [22]
				2248.97, -- [23]
				2249, -- [24]
				2251.005, -- [25]
				2252.059, -- [26]
				2253.008, -- [27]
				2253.069, -- [28]
				2253.373, -- [29]
				2253.4, -- [30]
				2254.516, -- [31]
				2255.015, -- [32]
				2255.966, -- [33]
				2256.43, -- [34]
				2257.007, -- [35]
				2257.048, -- [36]
				2257.23, -- [37]
				2258.413, -- [38]
				2259.478, -- [39]
				2259.599, -- [40]
				2259.613, -- [41]
				2260.783, -- [42]
				2261.963, -- [43]
				2241.658, -- [44]
				2241.854, -- [45]
				2241.877, -- [46]
				2241.877, -- [47]
				2242.295, -- [48]
				2242.317, -- [49]
				2242.317, -- [50]
			},
			["Fights"] = {
				["Fight2"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 20435,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 3,
								},
							},
							["amount"] = 4,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 19,
								},
							},
							["amount"] = 21,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 5999,
						["Nature"] = 14436,
					},
					["DOT_Time"] = 0,
					["Damage"] = 62311,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 3,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 4787,
						["Physical"] = 57524,
					},
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 2679,
								},
								["拍击"] = {
									["count"] = 25426,
								},
								["野兽顺劈"] = {
									["count"] = 26706,
								},
								["杀戮命令"] = {
									["count"] = 2713,
								},
								["肉搏"] = {
									["count"] = 4787,
								},
							},
							["amount"] = 62311,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 14436,
								},
								["肉搏"] = {
									["count"] = 5999,
								},
							},
							["amount"] = 20435,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1413,
									["min"] = 728,
									["count"] = 2,
									["amount"] = 2141,
								},
							},
							["count"] = 2,
							["amount"] = 2141,
						},
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 20435,
								},
							},
							["amount"] = 20435,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 2141,
					["TimeSpent"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 3,
								},
							},
							["amount"] = 3,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0.25,
								},
								["拍击"] = {
									["count"] = 3.25,
								},
								["野兽顺劈"] = {
									["count"] = 0.11,
								},
								["杀戮命令"] = {
									["count"] = 0.46,
								},
								["肉搏"] = {
									["count"] = 7.1,
								},
							},
							["amount"] = 11.17,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16386,
									["min"] = 4049,
									["count"] = 2,
									["amount"] = 20435,
								},
							},
							["count"] = 2,
							["amount"] = 20435,
						},
					},
					["WhoHealed"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 20435,
								},
							},
							["amount"] = 20435,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 14.17,
					["Healing"] = 20435,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 893,
									["min"] = 893,
									["count"] = 3,
									["amount"] = 2679,
								},
							},
							["count"] = 3,
							["amount"] = 2679,
						},
						["拍击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8531,
									["min"] = 8531,
									["count"] = 2,
									["amount"] = 17062,
								},
								["Hit"] = {
									["max"] = 4182,
									["min"] = 4182,
									["count"] = 2,
									["amount"] = 8364,
								},
							},
							["count"] = 4,
							["amount"] = 25426,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6398,
									["min"] = 446,
									["count"] = 13,
									["amount"] = 26706,
								},
							},
							["count"] = 13,
							["amount"] = 26706,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2713,
									["min"] = 2713,
									["count"] = 1,
									["amount"] = 2713,
								},
							},
							["count"] = 1,
							["amount"] = 2713,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1214,
									["min"] = 1214,
									["count"] = 1,
									["amount"] = 1214,
								},
								["Hit"] = {
									["max"] = 596,
									["min"] = 595,
									["count"] = 6,
									["amount"] = 3573,
								},
							},
							["count"] = 7,
							["amount"] = 4787,
						},
					},
					["HealingTaken"] = 20435,
					["RageGain"] = 0,
					["TimeDamage"] = 11.17,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0.25,
								},
								["拍击"] = {
									["count"] = 3.25,
								},
								["野兽顺劈"] = {
									["count"] = 0.11,
								},
								["杀戮命令"] = {
									["count"] = 0.46,
								},
								["肉搏"] = {
									["count"] = 7.1,
								},
							},
							["amount"] = 11.17,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 7849,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 3,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Nature"] = 7849,
					},
					["DOT_Time"] = 0,
					["Damage"] = 19182,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 1.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 3299,
						["Physical"] = 15883,
					},
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 2524,
								},
								["杀戮命令"] = {
									["count"] = 7783,
								},
								["拍击"] = {
									["count"] = 5576,
								},
								["肉搏"] = {
									["count"] = 3299,
								},
							},
							["amount"] = 19182,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 7849,
								},
							},
							["amount"] = 7849,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 8259,
								},
							},
							["amount"] = 8259,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 1.5,
								},
								["杀戮命令"] = {
									["count"] = 0.17,
								},
								["拍击"] = {
									["count"] = 0.34,
								},
								["肉搏"] = {
									["count"] = 2.67,
								},
							},
							["amount"] = 4.68,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8259,
									["min"] = 8259,
									["count"] = 1,
									["amount"] = 8259,
								},
							},
							["count"] = 1,
							["amount"] = 8259,
						},
					},
					["WhoHealed"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 8259,
								},
							},
							["amount"] = 8259,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 6.18,
					["Healing"] = 8259,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2524,
									["min"] = 2524,
									["count"] = 1,
									["amount"] = 2524,
								},
							},
							["count"] = 1,
							["amount"] = 2524,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7783,
									["min"] = 7783,
									["count"] = 1,
									["amount"] = 7783,
								},
							},
							["count"] = 1,
							["amount"] = 7783,
						},
						["拍击"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5576,
									["min"] = 5576,
									["count"] = 1,
									["amount"] = 5576,
								},
							},
							["count"] = 1,
							["amount"] = 5576,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 825,
									["min"] = 824,
									["count"] = 4,
									["amount"] = 3299,
								},
							},
							["count"] = 4,
							["amount"] = 3299,
						},
					},
					["HealingTaken"] = 8259,
					["RageGain"] = 0,
					["TimeDamage"] = 4.68,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 1.5,
								},
								["杀戮命令"] = {
									["count"] = 0.17,
								},
								["拍击"] = {
									["count"] = 0.34,
								},
								["肉搏"] = {
									["count"] = 2.67,
								},
							},
							["amount"] = 4.68,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["TimeHealing"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0,
								},
								["拍击"] = {
									["count"] = 0,
								},
								["野兽顺劈"] = {
									["count"] = 0,
								},
								["杀戮命令"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["Damage"] = 0,
					["TimeHeal"] = 0,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Miss"] = {
									["count"] = 0,
								},
								["Parry"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Overhealing"] = 0,
					["WhoHealed"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["HealedWho"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0,
								},
								["拍击"] = {
									["count"] = 0,
								},
								["野兽顺劈"] = {
									["count"] = 0,
								},
								["杀戮命令"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 0,
								},
								["拍击"] = {
									["count"] = 0,
								},
								["野兽顺劈"] = {
									["count"] = 0,
								},
								["杀戮命令"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["拍击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 8,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 40866,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 7617,
						["Physical"] = 33249,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 6528,
								},
								["践踏"] = {
									["count"] = 1237,
								},
								["拍击"] = {
									["count"] = 25484,
								},
								["肉搏"] = {
									["count"] = 7617,
								},
							},
							["amount"] = 40866,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.62,
								},
								["拍击"] = {
									["count"] = 1.86,
								},
								["肉搏"] = {
									["count"] = 7.41,
								},
							},
							["amount"] = 11.4,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 11.4,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["杀戮命令"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3815,
									["min"] = 2713,
									["count"] = 2,
									["amount"] = 6528,
								},
							},
							["count"] = 2,
							["amount"] = 6528,
						},
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1237,
									["min"] = 1237,
									["count"] = 1,
									["amount"] = 1237,
								},
							},
							["count"] = 1,
							["amount"] = 1237,
						},
						["拍击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11376,
									["min"] = 8531,
									["count"] = 2,
									["amount"] = 19907,
								},
								["Hit"] = {
									["max"] = 5577,
									["min"] = 5577,
									["count"] = 1,
									["amount"] = 5577,
								},
							},
							["count"] = 3,
							["amount"] = 25484,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1683,
									["min"] = 1214,
									["count"] = 2,
									["amount"] = 2897,
								},
								["Hit"] = {
									["max"] = 825,
									["min"] = 596,
									["count"] = 6,
									["amount"] = 4720,
								},
							},
							["count"] = 8,
							["amount"] = 7617,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 11.4,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.62,
								},
								["拍击"] = {
									["count"] = 1.86,
								},
								["肉搏"] = {
									["count"] = 7.41,
								},
							},
							["amount"] = 11.4,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 10,
								},
							},
							["amount"] = 14,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 12,
								},
							},
							["amount"] = 18,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 93710,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 11143,
						["Physical"] = 82567,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 15064,
								},
							},
							["amount"] = 15064,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 17509,
								},
								["践踏"] = {
									["count"] = 1825,
								},
								["肉搏"] = {
									["count"] = 11143,
								},
								["拍击"] = {
									["count"] = 48169,
								},
							},
							["amount"] = 78646,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["野性守护"] = {
									["count"] = 71,
								},
							},
							["amount"] = 71,
						},
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 71,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.08,
								},
							},
							["amount"] = 0.08,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 12.68,
								},
								["拍击"] = {
									["count"] = 3.97,
								},
							},
							["amount"] = 21.17,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
						["野性守护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 71,
								},
							},
							["amount"] = 71,
						},
					},
					["ActiveTime"] = 21.25,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 5734,
									["min"] = 5534,
									["count"] = 2,
									["amount"] = 11268,
								},
								["Hit"] = {
									["max"] = 3391,
									["min"] = 2850,
									["count"] = 2,
									["amount"] = 6241,
								},
							},
							["count"] = 4,
							["amount"] = 17509,
						},
						["拍击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 8761,
									["min"] = 8531,
									["count"] = 4,
									["amount"] = 34354,
								},
								["Hit"] = {
									["max"] = 5227,
									["min"] = 4294,
									["count"] = 3,
									["amount"] = 13815,
								},
							},
							["count"] = 7,
							["amount"] = 48169,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6398,
									["min"] = 446,
									["count"] = 5,
									["amount"] = 15064,
								},
							},
							["count"] = 5,
							["amount"] = 15064,
						},
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 932,
									["min"] = 893,
									["count"] = 2,
									["amount"] = 1825,
								},
							},
							["count"] = 2,
							["amount"] = 1825,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1268,
									["min"] = 1214,
									["count"] = 4,
									["amount"] = 4910,
								},
								["Hit"] = {
									["max"] = 744,
									["min"] = 595,
									["count"] = 10,
									["amount"] = 6233,
								},
							},
							["count"] = 14,
							["amount"] = 11143,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 21.25,
					["TimeDamaging"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.08,
								},
							},
							["amount"] = 0.08,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 12.68,
								},
								["拍击"] = {
									["count"] = 3.97,
								},
							},
							["amount"] = 21.17,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 8,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 40866,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 7617,
						["Physical"] = 33249,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 6528,
								},
								["践踏"] = {
									["count"] = 1237,
								},
								["拍击"] = {
									["count"] = 25484,
								},
								["肉搏"] = {
									["count"] = 7617,
								},
							},
							["amount"] = 40866,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.62,
								},
								["拍击"] = {
									["count"] = 1.86,
								},
								["肉搏"] = {
									["count"] = 7.41,
								},
							},
							["amount"] = 11.4,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 11.4,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["杀戮命令"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 3815,
									["min"] = 2713,
									["count"] = 2,
									["amount"] = 6528,
								},
							},
							["count"] = 2,
							["amount"] = 6528,
						},
						["践踏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 1237,
									["min"] = 1237,
									["count"] = 1,
									["amount"] = 1237,
								},
							},
							["count"] = 1,
							["amount"] = 1237,
						},
						["拍击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11376,
									["min"] = 8531,
									["count"] = 2,
									["amount"] = 19907,
								},
								["Hit"] = {
									["max"] = 5577,
									["min"] = 5577,
									["count"] = 1,
									["amount"] = 5577,
								},
							},
							["count"] = 3,
							["amount"] = 25484,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1683,
									["min"] = 1214,
									["count"] = 2,
									["amount"] = 2897,
								},
								["Hit"] = {
									["max"] = 825,
									["min"] = 596,
									["count"] = 6,
									["amount"] = 4720,
								},
							},
							["count"] = 8,
							["amount"] = 7617,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 11.4,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.62,
								},
								["拍击"] = {
									["count"] = 1.86,
								},
								["肉搏"] = {
									["count"] = 7.41,
								},
							},
							["amount"] = 11.4,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["TimeHealing"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
					},
					["OverHeals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 27454,
									["min"] = 728,
									["count"] = 4,
									["amount"] = 31637,
								},
							},
							["count"] = 4,
							["amount"] = 31637,
						},
					},
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 12.68,
								},
								["拍击"] = {
									["count"] = 3.97,
								},
							},
							["amount"] = 21.17,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.62,
								},
								["拍击"] = {
									["count"] = 1.86,
								},
								["肉搏"] = {
									["count"] = 7.41,
								},
							},
							["amount"] = 11.4,
						},
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 7.5,
								},
							},
							["amount"] = 7.5,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.08,
								},
							},
							["amount"] = 0.08,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 2.4,
								},
								["拍击"] = {
									["count"] = 7.32,
								},
								["野兽顺劈"] = {
									["count"] = 0.3,
								},
								["杀戮命令"] = {
									["count"] = 1.02,
								},
								["肉搏"] = {
									["count"] = 17.6,
								},
							},
							["amount"] = 28.64,
						},
					},
					["DamageTaken"] = 42301,
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 11,
						},
					},
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 11,
									["amount"] = 0,
								},
							},
							["count"] = 11,
							["amount"] = 0,
						},
					},
					["ActiveTime"] = 68.79,
					["Attacks"] = {
						["践踏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2524,
									["min"] = 2524,
									["count"] = 1,
									["amount"] = 2524,
								},
								["Hit"] = {
									["max"] = 1237,
									["min"] = 892,
									["count"] = 11,
									["amount"] = 10204,
								},
							},
							["count"] = 12,
							["amount"] = 12728,
						},
						["拍击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 11377,
									["min"] = 8531,
									["count"] = 11,
									["amount"] = 99762,
								},
								["Hit"] = {
									["max"] = 5577,
									["min"] = 4181,
									["count"] = 8,
									["amount"] = 37513,
								},
							},
							["count"] = 19,
							["amount"] = 137275,
						},
						["野兽顺劈"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 6399,
									["min"] = 446,
									["count"] = 35,
									["amount"] = 80974,
								},
							},
							["count"] = 35,
							["amount"] = 80974,
						},
						["杀戮命令"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 7783,
									["min"] = 5534,
									["count"] = 4,
									["amount"] = 24586,
								},
								["Hit"] = {
									["max"] = 3815,
									["min"] = 2713,
									["count"] = 5,
									["amount"] = 15482,
								},
							},
							["count"] = 9,
							["amount"] = 40068,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1683,
									["min"] = 1214,
									["count"] = 9,
									["amount"] = 11449,
								},
								["Hit"] = {
									["max"] = 825,
									["min"] = 595,
									["count"] = 33,
									["amount"] = 22140,
								},
							},
							["count"] = 42,
							["amount"] = 33589,
						},
					},
					["ElementTaken"] = {
						["Melee"] = 11871,
						["Nature"] = 30430,
					},
					["Overhealing"] = 31637,
					["Damage"] = 304634,
					["EnergyGain"] = 77,
					["TimeHeal"] = 7.5,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Dodge"] = {
									["count"] = 2,
								},
								["Miss"] = {
									["count"] = 1,
								},
								["Parry"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 11,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 4,
						},
					},
					["EnergyGained"] = {
						["野性守护"] = {
							["Details"] = {
								["乐乐创想"] = {
									["count"] = 77,
								},
							},
							["amount"] = 77,
						},
					},
					["WhoHealed"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 32857,
								},
							},
							["amount"] = 32857,
						},
					},
					["Healing"] = 32857,
					["HealedWho"] = {
						["裂蹄牛 <乐乐创想>"] = {
							["Details"] = {
								["吸血"] = {
									["count"] = 32857,
								},
							},
							["amount"] = 32857,
						},
					},
					["Heals"] = {
						["吸血"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 16386,
									["min"] = 1983,
									["count"] = 5,
									["amount"] = 32857,
								},
							},
							["count"] = 5,
							["amount"] = 32857,
						},
					},
					["ElementDone"] = {
						["Melee"] = 33589,
						["Physical"] = 271045,
					},
					["HealingTaken"] = 32857,
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 6528,
								},
								["践踏"] = {
									["count"] = 1237,
								},
								["拍击"] = {
									["count"] = 25484,
								},
								["肉搏"] = {
									["count"] = 7617,
								},
							},
							["amount"] = 40866,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 17509,
								},
								["践踏"] = {
									["count"] = 1825,
								},
								["肉搏"] = {
									["count"] = 11143,
								},
								["拍击"] = {
									["count"] = 48169,
								},
							},
							["amount"] = 78646,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 15064,
								},
							},
							["amount"] = 15064,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 9666,
								},
								["拍击"] = {
									["count"] = 63622,
								},
								["野兽顺劈"] = {
									["count"] = 65910,
								},
								["杀戮命令"] = {
									["count"] = 16031,
								},
								["肉搏"] = {
									["count"] = 14829,
								},
							},
							["amount"] = 170058,
						},
					},
					["TimeDamage"] = 61.29,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 1.51,
								},
								["践踏"] = {
									["count"] = 0.62,
								},
								["拍击"] = {
									["count"] = 1.86,
								},
								["肉搏"] = {
									["count"] = 7.41,
								},
							},
							["amount"] = 11.4,
						},
						["疤爪"] = {
							["Details"] = {
								["杀戮命令"] = {
									["count"] = 4.23,
								},
								["践踏"] = {
									["count"] = 0.29,
								},
								["肉搏"] = {
									["count"] = 12.68,
								},
								["拍击"] = {
									["count"] = 3.97,
								},
							},
							["amount"] = 21.17,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["野兽顺劈"] = {
									["count"] = 0.08,
								},
							},
							["amount"] = 0.08,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["践踏"] = {
									["count"] = 2.4,
								},
								["拍击"] = {
									["count"] = 7.32,
								},
								["野兽顺劈"] = {
									["count"] = 0.3,
								},
								["杀戮命令"] = {
									["count"] = 1.02,
								},
								["肉搏"] = {
									["count"] = 17.6,
								},
							},
							["amount"] = 28.64,
						},
					},
					["EnergyGainedFrom"] = {
						["乐乐创想"] = {
							["Details"] = {
								["野性守护"] = {
									["count"] = 77,
								},
							},
							["amount"] = 77,
						},
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 30430,
								},
								["肉搏"] = {
									["count"] = 11871,
								},
							},
							["amount"] = 42301,
						},
					},
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 9,
								},
								["Hit"] = {
									["count"] = 33,
								},
							},
							["amount"] = 42,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 16,
								},
								["Hit"] = {
									["count"] = 59,
								},
							},
							["amount"] = 75,
						},
					},
				},
			},
			["UnitLockout"] = 2170.028,
			["LastActive"] = 2261.029,
		},
		["Jerrya-亚雷戈斯"] = {
			["GUID"] = "Player-1696-0247B6CB",
			["LastEventHealth"] = {
				80493, -- [1]
				80725, -- [2]
				80725, -- [3]
				80725, -- [4]
				80725, -- [5]
				80725, -- [6]
				80958, -- [7]
				80958, -- [8]
				80958, -- [9]
				81191, -- [10]
				81191, -- [11]
				81424, -- [12]
				82804, -- [13]
				84171, -- [14]
				85314, -- [15]
				85547, -- [16]
				85547, -- [17]
				85779, -- [18]
				85779, -- [19]
				85779, -- [20]
				85779, -- [21]
				86011, -- [22]
				86244, -- [23]
				86477, -- [24]
				87853, -- [25]
				89228, -- [26]
				90603, -- [27]
				91982, -- [28]
				78426, -- [29]
				78426, -- [30]
				78426, -- [31]
				78659, -- [32]
				78659, -- [33]
				78659, -- [34]
				77755, -- [35]
				77988, -- [36]
				78221, -- [37]
				79592, -- [38]
				80973, -- [39]
				82351, -- [40]
				83726, -- [41]
				84868, -- [42]
				84868, -- [43]
				84868, -- [44]
				84868, -- [45]
				85101, -- [46]
				85101, -- [47]
				85101, -- [48]
				85101, -- [49]
				80493, -- [50]
			},
			["LastAttackedBy"] = "砾鳞蜥蜴",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"HEAL", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"HEAL", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"HEAL", -- [10]
				"DAMAGE", -- [11]
				"HEAL", -- [12]
				"HEAL", -- [13]
				"HEAL", -- [14]
				"DAMAGE", -- [15]
				"HEAL", -- [16]
				"DAMAGE", -- [17]
				"HEAL", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"HEAL", -- [22]
				"HEAL", -- [23]
				"HEAL", -- [24]
				"HEAL", -- [25]
				"HEAL", -- [26]
				"HEAL", -- [27]
				"HEAL", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"HEAL", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"HEAL", -- [36]
				"HEAL", -- [37]
				"HEAL", -- [38]
				"HEAL", -- [39]
				"HEAL", -- [40]
				"HEAL", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"HEAL", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
				"DAMAGE", -- [49]
				"DAMAGE", -- [50]
			},
			["TimeWindows"] = {
				["TimeHeal"] = {
					93.5, -- [1]
				},
				["Healing"] = {
					27814, -- [1]
				},
				["DamageTaken"] = {
					157101, -- [1]
				},
				["Absorbs"] = {
					73807, -- [1]
				},
				["HealingTaken"] = {
					101621, -- [1]
				},
				["HOT_Time"] = {
					165, -- [1]
				},
				["TimeDamage"] = {
					88.89, -- [1]
				},
				["Overhealing"] = {
					9884, -- [1]
				},
				["ManaGain"] = {
					80, -- [1]
				},
				["ActiveTime"] = {
					182.39, -- [1]
				},
				["Damage"] = {
					692235, -- [1]
				},
			},
			["enClass"] = "PALADIN",
			["unit"] = "Jerrya-亚雷戈斯",
			["level"] = 120,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 5,
			["LastHealTime"] = 2262.62,
			["type"] = "Grouped",
			["FightsSaved"] = 5,
			["LastDamageTaken"] = 2428,
			["TimeLast"] = {
				["TimeHeal"] = 2262.031,
				["OVERALL"] = 2262.031,
				["DamageTaken"] = 2247.058,
				["Overhealing"] = 2151.046,
				["Absorbs"] = 2247.058,
				["HealingTaken"] = 2262.031,
				["HOT_Time"] = 2262.031,
				["TimeDamage"] = 2260.032,
				["Healing"] = 2262.031,
				["ManaGain"] = 2210.02,
				["ActiveTime"] = 2262.031,
				["Damage"] = 2260.032,
			},
			["Owner"] = false,
			["LastEventHealthMax"] = {
				112960, -- [1]
				112960, -- [2]
				112960, -- [3]
				112960, -- [4]
				112960, -- [5]
				112960, -- [6]
				112960, -- [7]
				112960, -- [8]
				112960, -- [9]
				112960, -- [10]
				112960, -- [11]
				112960, -- [12]
				112960, -- [13]
				112960, -- [14]
				112960, -- [15]
				112960, -- [16]
				112960, -- [17]
				112960, -- [18]
				112960, -- [19]
				112960, -- [20]
				112960, -- [21]
				112960, -- [22]
				112960, -- [23]
				112960, -- [24]
				112960, -- [25]
				112960, -- [26]
				112960, -- [27]
				112960, -- [28]
				112960, -- [29]
				112960, -- [30]
				112960, -- [31]
				112960, -- [32]
				112960, -- [33]
				112960, -- [34]
				112960, -- [35]
				112960, -- [36]
				112960, -- [37]
				112960, -- [38]
				112960, -- [39]
				112960, -- [40]
				112960, -- [41]
				112960, -- [42]
				112960, -- [43]
				112960, -- [44]
				112960, -- [45]
				112960, -- [46]
				112960, -- [47]
				112960, -- [48]
				112960, -- [49]
				112960, -- [50]
			},
			["NextEventNum"] = 29,
			["LastDamageTime"] = 2260.486,
			["LastEvents"] = {
				"砾鳞蜥蜴 岩石吐息 Jerrya-亚雷戈斯 Hit -4608 (3617 被吸收) (Nature)", -- [1]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +232", -- [2]
				"Jerrya-亚雷戈斯 神圣风暴 砾鳞蜥蜴 Hit -5078 (Holy)", -- [3]
				"Jerrya-亚雷戈斯 神圣风暴 砾鳞蜥蜴 Hit -5078 (Holy)", -- [4]
				"Jerrya-亚雷戈斯 神圣风暴 砾鳞蜥蜴 Hit -5078 (Holy)", -- [5]
				"Jerrya-亚雷戈斯 肉搏 砾鳞蜥蜴 Hit -2424 (Physical)", -- [6]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [7]
				"Jerrya-亚雷戈斯 愤怒之锤 砾鳞蜥蜴 Hit -5034 (Holy)", -- [8]
				"砾鳞蜥蜴 肉搏 Jerrya-亚雷戈斯 Absorb -2428 (2428 被吸收) (1)", -- [9]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [10]
				"Jerrya-亚雷戈斯 公正之剑 砾鳞蜥蜴 Hit -4263 (Physical)", -- [11]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [12]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [13]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [14]
				"Jerrya-亚雷戈斯 肉搏 砾鳞凝视者 Hit -2379 (Physical)", -- [15]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [16]
				"Jerrya-亚雷戈斯 审判 砾鳞凝视者 Hit -5340 (Holy)", -- [17]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +232", -- [18]
				"Jerrya-亚雷戈斯 处决宣判 砾鳞凝视者 Hit -14637 (Holy)", -- [19]
				"Jerrya-亚雷戈斯 肉搏 砾鳞凝视者 Hit -2467 (Physical)", -- [20]
				"Jerrya-亚雷戈斯 公正之剑 砾鳞凝视者 Hit -4562 (Physical)", -- [21]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +232", -- [22]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [23]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [24]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [25]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [26]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [27]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [28]
				"Jerrya-亚雷戈斯 肉搏 刚被石化的敌人 Hit -4738 (Physical)", -- [29]
				"Jerrya-亚雷戈斯 处决宣判 刚被石化的敌人 Hit -21887 (Holy)", -- [30]
				"Jerrya-亚雷戈斯 公正之剑 刚被石化的敌人 Crit -17051 (Physical)", -- [31]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [32]
				"刚被石化的敌人 肉搏 Jerrya-亚雷戈斯 Absorb -1270 (1)", -- [33]
				"刚被石化的敌人 肉搏 Jerrya-亚雷戈斯 Hit -904 (1270 被吸收) (Physical)", -- [34]
				"Jerrya-亚雷戈斯 愤怒之锤 刚被石化的敌人 Hit -12082 (Holy)", -- [35]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [36]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [37]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +232", -- [38]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +232", -- [39]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [40]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [41]
				"Jerrya-亚雷戈斯 肉搏 砾鳞蜥蜴 Hit -2453 (Physical)", -- [42]
				"Jerrya-亚雷戈斯 神圣风暴 砾鳞蜥蜴 Hit -5078 (Holy)", -- [43]
				"Jerrya-亚雷戈斯 神圣风暴 砾鳞蜥蜴 Hit -5078 (Holy)", -- [44]
				"Jerrya-亚雷戈斯 神圣风暴 砾鳞蜥蜴 Hit -5077 (Holy)", -- [45]
				"Jerrya-亚雷戈斯 强效智慧祝福 Jerrya-亚雷戈斯 Tick +233", -- [46]
				"Jerrya-亚雷戈斯 灰烬觉醒 砾鳞蜥蜴 Hit -11491", -- [47]
				"Jerrya-亚雷戈斯 灰烬觉醒 砾鳞蜥蜴 Hit -11491", -- [48]
				"Jerrya-亚雷戈斯 灰烬觉醒 砾鳞蜥蜴 Hit -11491", -- [49]
				"砾鳞蜥蜴 岩石吐息 Jerrya-亚雷戈斯 Absorb -3617 (Nature)", -- [50]
			},
			["Name"] = "Jerrya-亚雷戈斯",
			["LastEventIncoming"] = {
				true, -- [1]
				true, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				false, -- [6]
				true, -- [7]
				false, -- [8]
				true, -- [9]
				true, -- [10]
				false, -- [11]
				true, -- [12]
				true, -- [13]
				true, -- [14]
				false, -- [15]
				true, -- [16]
				false, -- [17]
				true, -- [18]
				false, -- [19]
				false, -- [20]
				false, -- [21]
				true, -- [22]
				true, -- [23]
				true, -- [24]
				true, -- [25]
				true, -- [26]
				true, -- [27]
				true, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				true, -- [32]
				true, -- [33]
				true, -- [34]
				false, -- [35]
				true, -- [36]
				true, -- [37]
				true, -- [38]
				true, -- [39]
				true, -- [40]
				true, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				true, -- [46]
				false, -- [47]
				false, -- [48]
				false, -- [49]
				true, -- [50]
			},
			["LastEventTimes"] = {
				2244.308, -- [1]
				2244.623, -- [2]
				2245.318, -- [3]
				2245.318, -- [4]
				2245.318, -- [5]
				2245.653, -- [6]
				2246.619, -- [7]
				2246.867, -- [8]
				2247.67, -- [9]
				2248.612, -- [10]
				2249.105, -- [11]
				2250.598, -- [12]
				2252.607, -- [13]
				2254.616, -- [14]
				2256.121, -- [15]
				2256.601, -- [16]
				2257.903, -- [17]
				2258.61, -- [18]
				2259.172, -- [19]
				2259.248, -- [20]
				2260.486, -- [21]
				2260.621, -- [22]
				2262.62, -- [23]
				2264.619, -- [24]
				2266.618, -- [25]
				2268.614, -- [26]
				2270.608, -- [27]
				2272.609, -- [28]
				2226.799, -- [29]
				2227.179, -- [30]
				2228.576, -- [31]
				2228.602, -- [32]
				2228.626, -- [33]
				2228.626, -- [34]
				2230.03, -- [35]
				2230.619, -- [36]
				2232.607, -- [37]
				2234.607, -- [38]
				2236.61, -- [39]
				2238.608, -- [40]
				2240.607, -- [41]
				2242.317, -- [42]
				2242.317, -- [43]
				2242.317, -- [44]
				2242.317, -- [45]
				2242.617, -- [46]
				2244.007, -- [47]
				2244.007, -- [48]
				2244.007, -- [49]
				2244.308, -- [50]
			},
			["Fights"] = {
				["Fight5"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 13029,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 4.5,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Melee"] = 2413,
						["Holy"] = 10616,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["圣殿骑士的裁决"] = {
									["count"] = 10616,
								},
								["肉搏"] = {
									["count"] = 2413,
								},
							},
							["amount"] = 13029,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 698,
								},
							},
							["amount"] = 698,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 4.5,
								},
							},
							["amount"] = 4.5,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 233,
									["min"] = 232,
									["count"] = 3,
									["amount"] = 698,
								},
							},
							["count"] = 3,
							["amount"] = 698,
						},
					},
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 698,
								},
							},
							["amount"] = 698,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 6,
					["Healing"] = 698,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["圣殿骑士的裁决"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 10616,
									["min"] = 10616,
									["count"] = 1,
									["amount"] = 10616,
								},
							},
							["count"] = 1,
							["amount"] = 10616,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2413,
									["min"] = 2413,
									["count"] = 1,
									["amount"] = 2413,
								},
							},
							["count"] = 1,
							["amount"] = 2413,
						},
					},
					["HealingTaken"] = 698,
					["RageGain"] = 0,
					["TimeDamage"] = 1.5,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 1.5,
								},
							},
							["amount"] = 1.5,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight2"] = {
					["Absorbed"] = {
						["强效王者祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["max"] = 3617,
									["min"] = 2428,
									["count"] = 2,
									["amount"] = 6045,
								},
							},
							["count"] = 2,
							["amount"] = 6045,
						},
					},
					["DOTs"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Absorb"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 10653,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 6045,
					["DeathCount"] = 0,
					["HOT_Time"] = 18,
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 7,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 2428,
						["Nature"] = 3617,
					},
					["ElementTaken"] = {
						["Melee"] = 2428,
						["Nature"] = 8225,
					},
					["DOT_Time"] = 0,
					["Damage"] = 79114,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 9.82,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Holy"] = 35501,
						["Melee"] = 4877,
						["Physical"] = 4263,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 2428,
									["min"] = 2428,
									["count"] = 1,
									["amount"] = 2428,
								},
							},
							["count"] = 1,
							["amount"] = 2428,
						},
						["岩石吐息"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 3617,
									["min"] = 3617,
									["count"] = 1,
									["amount"] = 3617,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 3617,
						},
					},
					["DamagedWho"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["灰烬觉醒"] = {
									["count"] = 34473,
								},
								["愤怒之锤"] = {
									["count"] = 5034,
								},
								["神圣风暴"] = {
									["count"] = 30467,
								},
								["公正之剑"] = {
									["count"] = 4263,
								},
								["肉搏"] = {
									["count"] = 4877,
								},
							},
							["amount"] = 79114,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 2428,
								},
								["岩石吐息"] = {
									["count"] = 8225,
								},
							},
							["amount"] = 10653,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 7.25,
								},
								["强效王者祝福"] = {
									["count"] = 2.57,
								},
							},
							["amount"] = 9.82,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 1397,
								},
								["强效王者祝福"] = {
									["count"] = 6045,
								},
							},
							["amount"] = 7442,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 7.25,
								},
								["强效王者祝福"] = {
									["count"] = 2.57,
								},
							},
							["amount"] = 9.82,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["灰烬觉醒"] = {
									["count"] = 1.5,
								},
								["愤怒之锤"] = {
									["count"] = 1.21,
								},
								["神圣风暴"] = {
									["count"] = 1.31,
								},
								["公正之剑"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.84,
								},
							},
							["amount"] = 7.36,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 233,
									["min"] = 232,
									["count"] = 6,
									["amount"] = 1397,
								},
							},
							["count"] = 6,
							["amount"] = 1397,
						},
						["强效王者祝福"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 3617,
									["min"] = 2428,
									["count"] = 2,
									["amount"] = 6045,
								},
							},
							["count"] = 2,
							["amount"] = 6045,
						},
					},
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 1397,
								},
								["强效王者祝福"] = {
									["count"] = 6045,
								},
							},
							["amount"] = 7442,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 17.18,
					["Healing"] = 1397,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["灰烬觉醒"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 11491,
									["min"] = 11491,
									["count"] = 3,
									["amount"] = 34473,
								},
							},
							["count"] = 3,
							["amount"] = 34473,
						},
						["愤怒之锤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5034,
									["min"] = 5034,
									["count"] = 1,
									["amount"] = 5034,
								},
							},
							["count"] = 1,
							["amount"] = 5034,
						},
						["神圣风暴"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5078,
									["min"] = 5077,
									["count"] = 6,
									["amount"] = 30467,
								},
							},
							["count"] = 6,
							["amount"] = 30467,
						},
						["公正之剑"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4263,
									["min"] = 4263,
									["count"] = 1,
									["amount"] = 4263,
								},
							},
							["count"] = 1,
							["amount"] = 4263,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2453,
									["min"] = 2424,
									["count"] = 2,
									["amount"] = 4877,
								},
							},
							["count"] = 2,
							["amount"] = 4877,
						},
					},
					["HealingTaken"] = 7442,
					["RageGain"] = 0,
					["TimeDamage"] = 7.36,
					["TimeDamaging"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["灰烬觉醒"] = {
									["count"] = 1.5,
								},
								["愤怒之锤"] = {
									["count"] = 1.21,
								},
								["神圣风暴"] = {
									["count"] = 1.31,
								},
								["公正之剑"] = {
									["count"] = 1.5,
								},
								["肉搏"] = {
									["count"] = 1.84,
								},
							},
							["amount"] = 7.36,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["DispelledWho"] = {
					},
				},
				["CurrentFightData"] = {
					["Overhealing"] = 0,
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 0,
								},
								["复仇之盾"] = {
									["count"] = 0,
								},
								["强效智慧祝福"] = {
									["count"] = 0,
								},
								["强效王者祝福"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["OverHeals"] = {
						["审判官复仇"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGainedFrom"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeSpent"] = {
						["热带蟾蜍"] = {
							["Details"] = {
								["复仇之盾"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 0,
								},
								["复仇之盾"] = {
									["count"] = 0,
								},
								["强效智慧祝福"] = {
									["count"] = 0,
								},
								["强效王者祝福"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 0,
								},
								["审判官复仇"] = {
									["count"] = 0,
								},
								["圣殿骑士的裁决"] = {
									["count"] = 0,
								},
								["十字军打击"] = {
									["count"] = 0,
								},
								["愤怒之锤"] = {
									["count"] = 0,
								},
								["灰烬觉醒"] = {
									["count"] = 0,
								},
								["处决宣判"] = {
									["count"] = 0,
								},
								["审判"] = {
									["count"] = 0,
								},
								["公正之剑"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DamageTaken"] = 0,
					["Attacks"] = {
						["神圣风暴"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["审判官复仇"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["复仇之盾"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["圣殿骑士的裁决"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["十字军打击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["愤怒之锤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["灰烬觉醒"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["处决宣判"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["审判"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["公正之剑"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["PartialResist"] = {
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["ManaGained"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["ActiveTime"] = 0,
					["HOT_Time"] = 0,
					["ElementTaken"] = {
						["Melee"] = 0,
						["Nature"] = 0,
					},
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Damage"] = 0,
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 0,
								},
								["复仇之盾"] = {
									["count"] = 0,
								},
								["强效智慧祝福"] = {
									["count"] = 0,
								},
								["强效王者祝福"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeHeal"] = 0,
					["PartialAbsorb"] = {
						["岩石吐息"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 0,
								},
								["复仇之盾"] = {
									["count"] = 0,
								},
								["强效智慧祝福"] = {
									["count"] = 0,
								},
								["强效王者祝福"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Heals"] = {
						["审判官复仇"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["复仇之盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["强效王者祝福"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["Healing"] = 0,
					["Absorbs"] = 0,
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 0,
								},
								["Absorb"] = {
									["count"] = 0,
								},
								["Miss"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 0,
								},
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ElementDone"] = {
						["Holy"] = 0,
						["Melee"] = 0,
						["Physical"] = 0,
					},
					["HealingTaken"] = 0,
					["DamagedWho"] = {
						["热带蟾蜍"] = {
							["Details"] = {
								["复仇之盾"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 0,
								},
								["审判官复仇"] = {
									["count"] = 0,
								},
								["复仇之盾"] = {
									["count"] = 0,
								},
								["圣殿骑士的裁决"] = {
									["count"] = 0,
								},
								["十字军打击"] = {
									["count"] = 0,
								},
								["愤怒之锤"] = {
									["count"] = 0,
								},
								["灰烬觉醒"] = {
									["count"] = 0,
								},
								["处决宣判"] = {
									["count"] = 0,
								},
								["审判"] = {
									["count"] = 0,
								},
								["公正之剑"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
						["热带蟾蜍"] = {
							["Details"] = {
								["复仇之盾"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 0,
								},
								["审判官复仇"] = {
									["count"] = 0,
								},
								["圣殿骑士的裁决"] = {
									["count"] = 0,
								},
								["十字军打击"] = {
									["count"] = 0,
								},
								["愤怒之锤"] = {
									["count"] = 0,
								},
								["灰烬觉醒"] = {
									["count"] = 0,
								},
								["处决宣判"] = {
									["count"] = 0,
								},
								["审判"] = {
									["count"] = 0,
								},
								["公正之剑"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["ManaGain"] = 0,
					["WhoDamaged"] = {
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 0,
								},
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["Absorbed"] = {
						["复仇之盾"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["强效王者祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
				},
				["Fight3"] = {
					["Absorbed"] = {
						["强效王者祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["max"] = 2347,
									["min"] = 1270,
									["count"] = 2,
									["amount"] = 3617,
								},
							},
							["count"] = 2,
							["amount"] = 3617,
						},
					},
					["DOTs"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Miss"] = {
									["count"] = 1,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 4521,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 3617,
					["DeathCount"] = 0,
					["HOT_Time"] = 9,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 3617,
					},
					["ElementTaken"] = {
						["Melee"] = 4521,
					},
					["DOT_Time"] = 0,
					["Damage"] = 64284,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 4.52,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 25577,
						["Melee"] = 4738,
						["Holy"] = 33969,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 2347,
									["min"] = 1270,
									["count"] = 2,
									["amount"] = 3617,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 3617,
						},
					},
					["DamagedWho"] = {
						["刚被石化的敌人"] = {
							["Details"] = {
								["愤怒之锤"] = {
									["count"] = 12082,
								},
								["处决宣判"] = {
									["count"] = 21887,
								},
								["公正之剑"] = {
									["count"] = 25577,
								},
								["肉搏"] = {
									["count"] = 4738,
								},
							},
							["amount"] = 64284,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["刚被石化的敌人"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4521,
								},
							},
							["amount"] = 4521,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 4.5,
								},
								["强效王者祝福"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 4.52,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 699,
								},
								["强效王者祝福"] = {
									["count"] = 3617,
								},
							},
							["amount"] = 4316,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 4.5,
								},
								["强效王者祝福"] = {
									["count"] = 0.02,
								},
							},
							["amount"] = 4.52,
						},
						["刚被石化的敌人"] = {
							["Details"] = {
								["愤怒之锤"] = {
									["count"] = 1.45,
								},
								["处决宣判"] = {
									["count"] = 0.38,
								},
								["公正之剑"] = {
									["count"] = 2.9,
								},
								["肉搏"] = {
									["count"] = 1.01,
								},
							},
							["amount"] = 5.74,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 233,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 699,
								},
							},
							["count"] = 3,
							["amount"] = 699,
						},
						["强效王者祝福"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 2347,
									["min"] = 1270,
									["count"] = 2,
									["amount"] = 3617,
								},
							},
							["count"] = 2,
							["amount"] = 3617,
						},
					},
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 699,
								},
								["强效王者祝福"] = {
									["count"] = 3617,
								},
							},
							["amount"] = 4316,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 10.26,
					["Healing"] = 699,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["愤怒之锤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12082,
									["min"] = 12082,
									["count"] = 1,
									["amount"] = 12082,
								},
							},
							["count"] = 1,
							["amount"] = 12082,
						},
						["处决宣判"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 21887,
									["min"] = 21887,
									["count"] = 1,
									["amount"] = 21887,
								},
							},
							["count"] = 1,
							["amount"] = 21887,
						},
						["公正之剑"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 17051,
									["min"] = 17051,
									["count"] = 1,
									["amount"] = 17051,
								},
								["Hit"] = {
									["max"] = 8526,
									["min"] = 8526,
									["count"] = 1,
									["amount"] = 8526,
								},
							},
							["count"] = 2,
							["amount"] = 25577,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4738,
									["min"] = 4738,
									["count"] = 1,
									["amount"] = 4738,
								},
							},
							["count"] = 1,
							["amount"] = 4738,
						},
					},
					["HealingTaken"] = 4316,
					["RageGain"] = 0,
					["TimeDamage"] = 5.74,
					["TimeDamaging"] = {
						["刚被石化的敌人"] = {
							["Details"] = {
								["愤怒之锤"] = {
									["count"] = 1.45,
								},
								["处决宣判"] = {
									["count"] = 0.38,
								},
								["公正之剑"] = {
									["count"] = 2.9,
								},
								["肉搏"] = {
									["count"] = 1.01,
								},
							},
							["amount"] = 5.74,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["Absorbed"] = {
						["强效王者祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["max"] = 4674,
									["min"] = 262,
									["count"] = 7,
									["amount"] = 20573,
								},
							},
							["count"] = 7,
							["amount"] = 20573,
						},
					},
					["DOTs"] = {
					},
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 7,
						},
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 6,
								},
								["Parry"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 7,
								},
							},
							["amount"] = 14,
						},
						["Nature"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 56406,
					["RageGainedFrom"] = {
					},
					["Absorbs"] = 20573,
					["DeathCount"] = 0,
					["HOT_Time"] = 36,
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 3,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 9,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 7,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementTakenAbsorb"] = {
						["Melee"] = 21352,
						["Physical"] = 262,
					},
					["ElementTaken"] = {
						["Physical"] = 12601,
						["Melee"] = 34627,
						["Nature"] = 9178,
					},
					["DOT_Time"] = 0,
					["Damage"] = 203390,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 21.03,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Holy"] = 101882,
						["Melee"] = 23677,
						["Physical"] = 31867,
					},
					["PartialAbsorb"] = {
						["腐化之爪"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["啄击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["吸血鬼之咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 262,
									["min"] = 262,
									["count"] = 1,
									["amount"] = 262,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 262,
						},
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 4674,
									["min"] = 1041,
									["count"] = 6,
									["amount"] = 21352,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 14,
							["amount"] = 21352,
						},
					},
					["DamagedWho"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["灰烬觉醒"] = {
									["count"] = 22982,
								},
								["神圣风暴"] = {
									["count"] = 12274,
								},
							},
							["amount"] = 35256,
						},
						["疤爪"] = {
							["Details"] = {
								["圣殿骑士的裁决"] = {
									["count"] = 54260,
								},
								["十字军打击"] = {
									["count"] = 21787,
								},
								["灰烬觉醒"] = {
									["count"] = 22982,
								},
								["愤怒之锤"] = {
									["count"] = 5610,
								},
								["神圣风暴"] = {
									["count"] = 6138,
								},
								["审判"] = {
									["count"] = 23600,
								},
								["公正之剑"] = {
									["count"] = 10080,
								},
								["肉搏"] = {
									["count"] = 23677,
								},
							},
							["amount"] = 168134,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["啄击"] = {
									["count"] = 2229,
								},
								["肉搏"] = {
									["count"] = 1989,
								},
							},
							["amount"] = 4218,
						},
						["疤爪"] = {
							["Details"] = {
								["腐化之爪"] = {
									["count"] = 9178,
								},
								["吸血鬼之咬 (伤害/跳)"] = {
									["count"] = 10372,
								},
								["肉搏"] = {
									["count"] = 32638,
								},
							},
							["amount"] = 52188,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["腐化之爪"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["啄击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["吸血鬼之咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 14,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 14,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 15.14,
								},
								["强效王者祝福"] = {
									["count"] = 5.89,
								},
							},
							["amount"] = 21.03,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 40,
								},
							},
							["amount"] = 40,
						},
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 2839,
								},
								["强效王者祝福"] = {
									["count"] = 20573,
								},
							},
							["amount"] = 23412,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 40,
								},
							},
							["amount"] = 40,
						},
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["圣殿骑士的裁决"] = {
									["count"] = 4.63,
								},
								["十字军打击"] = {
									["count"] = 4.63,
								},
								["灰烬觉醒"] = {
									["count"] = 0.36,
								},
								["愤怒之锤"] = {
									["count"] = 1.5,
								},
								["审判"] = {
									["count"] = 2.97,
								},
								["公正之剑"] = {
									["count"] = 0.75,
								},
								["肉搏"] = {
									["count"] = 6.05,
								},
							},
							["amount"] = 20.89,
						},
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 15.14,
								},
								["强效王者祝福"] = {
									["count"] = 5.89,
								},
							},
							["amount"] = 21.03,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 1.22,
								},
							},
							["amount"] = 1.22,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 242,
									["min"] = 232,
									["count"] = 12,
									["amount"] = 2839,
								},
							},
							["count"] = 12,
							["amount"] = 2839,
						},
						["强效王者祝福"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 4674,
									["min"] = 262,
									["count"] = 7,
									["amount"] = 20573,
								},
							},
							["count"] = 7,
							["amount"] = 20573,
						},
					},
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 2839,
								},
								["强效王者祝福"] = {
									["count"] = 20573,
								},
							},
							["amount"] = 23412,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 43.14,
					["Healing"] = 2839,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["圣殿骑士的裁决"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18106,
									["min"] = 10615,
									["count"] = 4,
									["amount"] = 54260,
								},
							},
							["count"] = 4,
							["amount"] = 54260,
						},
						["十字军打击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6138,
									["min"] = 4498,
									["count"] = 4,
									["amount"] = 21787,
								},
							},
							["count"] = 4,
							["amount"] = 21787,
						},
						["灰烬觉醒"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 22982,
									["min"] = 22982,
									["count"] = 1,
									["amount"] = 22982,
								},
								["Hit"] = {
									["max"] = 11491,
									["min"] = 11491,
									["count"] = 2,
									["amount"] = 22982,
								},
							},
							["count"] = 3,
							["amount"] = 45964,
						},
						["愤怒之锤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5610,
									["min"] = 5610,
									["count"] = 1,
									["amount"] = 5610,
								},
							},
							["count"] = 1,
							["amount"] = 5610,
						},
						["神圣风暴"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 12274,
									["min"] = 12274,
									["count"] = 1,
									["amount"] = 12274,
								},
								["Hit"] = {
									["max"] = 6138,
									["min"] = 6138,
									["count"] = 1,
									["amount"] = 6138,
								},
							},
							["count"] = 2,
							["amount"] = 18412,
						},
						["审判"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 13619,
									["min"] = 9981,
									["count"] = 2,
									["amount"] = 23600,
								},
							},
							["count"] = 2,
							["amount"] = 23600,
						},
						["公正之剑"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5817,
									["min"] = 4263,
									["count"] = 2,
									["amount"] = 10080,
								},
							},
							["count"] = 2,
							["amount"] = 10080,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6621,
									["min"] = 6621,
									["count"] = 1,
									["amount"] = 6621,
								},
								["Hit"] = {
									["max"] = 3329,
									["min"] = 2398,
									["count"] = 6,
									["amount"] = 17056,
								},
							},
							["count"] = 7,
							["amount"] = 23677,
						},
					},
					["HealingTaken"] = 23412,
					["RageGain"] = 0,
					["TimeDamage"] = 22.11,
					["TimeDamaging"] = {
						["断喙雏鸟"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 1.22,
								},
							},
							["amount"] = 1.22,
						},
						["疤爪"] = {
							["Details"] = {
								["圣殿骑士的裁决"] = {
									["count"] = 4.63,
								},
								["十字军打击"] = {
									["count"] = 4.63,
								},
								["灰烬觉醒"] = {
									["count"] = 0.36,
								},
								["愤怒之锤"] = {
									["count"] = 1.5,
								},
								["审判"] = {
									["count"] = 2.97,
								},
								["公正之剑"] = {
									["count"] = 0.75,
								},
								["肉搏"] = {
									["count"] = 6.05,
								},
							},
							["amount"] = 20.89,
						},
					},
					["ManaGain"] = 40,
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 36,
								},
							},
							["amount"] = 36,
						},
					},
					["DispelledWho"] = {
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 18,
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 29385,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 9,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Holy"] = 19977,
						["Melee"] = 4846,
						["Physical"] = 4562,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 14637,
								},
								["审判"] = {
									["count"] = 5340,
								},
								["公正之剑"] = {
									["count"] = 4562,
								},
								["肉搏"] = {
									["count"] = 4846,
								},
							},
							["amount"] = 29385,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1396,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 1.27,
								},
								["审判"] = {
									["count"] = 1.5,
								},
								["公正之剑"] = {
									["count"] = 1.24,
								},
								["肉搏"] = {
									["count"] = 1.58,
								},
							},
							["amount"] = 5.59,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 233,
									["min"] = 232,
									["count"] = 6,
									["amount"] = 1396,
								},
							},
							["count"] = 6,
							["amount"] = 1396,
						},
					},
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1396,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 14.59,
					["Healing"] = 1396,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["处决宣判"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 14637,
									["min"] = 14637,
									["count"] = 1,
									["amount"] = 14637,
								},
							},
							["count"] = 1,
							["amount"] = 14637,
						},
						["审判"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5340,
									["min"] = 5340,
									["count"] = 1,
									["amount"] = 5340,
								},
							},
							["count"] = 1,
							["amount"] = 5340,
						},
						["公正之剑"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4562,
									["min"] = 4562,
									["count"] = 1,
									["amount"] = 4562,
								},
							},
							["count"] = 1,
							["amount"] = 4562,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2467,
									["min"] = 2379,
									["count"] = 2,
									["amount"] = 4846,
								},
							},
							["count"] = 2,
							["amount"] = 4846,
						},
					},
					["HealingTaken"] = 1396,
					["RageGain"] = 0,
					["TimeDamage"] = 5.59,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 1.27,
								},
								["审判"] = {
									["count"] = 1.5,
								},
								["公正之剑"] = {
									["count"] = 1.24,
								},
								["肉搏"] = {
									["count"] = 1.58,
								},
							},
							["amount"] = 5.59,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["DispelledWho"] = {
					},
				},
				["Fight1"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 18,
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 2,
						},
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 1,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 29385,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 9,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Holy"] = 19977,
						["Melee"] = 4846,
						["Physical"] = 4562,
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 14637,
								},
								["审判"] = {
									["count"] = 5340,
								},
								["公正之剑"] = {
									["count"] = 4562,
								},
								["肉搏"] = {
									["count"] = 4846,
								},
							},
							["amount"] = 29385,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1396,
						},
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 1.27,
								},
								["审判"] = {
									["count"] = 1.5,
								},
								["公正之剑"] = {
									["count"] = 1.24,
								},
								["肉搏"] = {
									["count"] = 1.58,
								},
							},
							["amount"] = 5.59,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 233,
									["min"] = 232,
									["count"] = 6,
									["amount"] = 1396,
								},
							},
							["count"] = 6,
							["amount"] = 1396,
						},
					},
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 1396,
								},
							},
							["amount"] = 1396,
						},
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 14.59,
					["Healing"] = 1396,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["处决宣判"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 14637,
									["min"] = 14637,
									["count"] = 1,
									["amount"] = 14637,
								},
							},
							["count"] = 1,
							["amount"] = 14637,
						},
						["审判"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 5340,
									["min"] = 5340,
									["count"] = 1,
									["amount"] = 5340,
								},
							},
							["count"] = 1,
							["amount"] = 5340,
						},
						["公正之剑"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 4562,
									["min"] = 4562,
									["count"] = 1,
									["amount"] = 4562,
								},
							},
							["count"] = 1,
							["amount"] = 4562,
						},
						["肉搏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 2467,
									["min"] = 2379,
									["count"] = 2,
									["amount"] = 4846,
								},
							},
							["count"] = 2,
							["amount"] = 4846,
						},
					},
					["HealingTaken"] = 1396,
					["RageGain"] = 0,
					["TimeDamage"] = 5.59,
					["TimeDamaging"] = {
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 1.27,
								},
								["审判"] = {
									["count"] = 1.5,
								},
								["公正之剑"] = {
									["count"] = 1.24,
								},
								["肉搏"] = {
									["count"] = 1.58,
								},
							},
							["amount"] = 5.59,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["Overhealing"] = 9884,
					["TimeHealing"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 0.6,
								},
								["复仇之盾"] = {
									["count"] = 1.09,
								},
								["强效智慧祝福"] = {
									["count"] = 73.31,
								},
								["强效王者祝福"] = {
									["count"] = 18.5,
								},
							},
							["amount"] = 93.5,
						},
					},
					["OverHeals"] = {
						["审判官复仇"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 9884,
									["min"] = 9884,
									["count"] = 1,
									["amount"] = 9884,
								},
							},
							["count"] = 1,
							["amount"] = 9884,
						},
					},
					["ManaGainedFrom"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["强效智慧祝福"] = {
									["count"] = 80,
								},
							},
							["amount"] = 80,
						},
					},
					["ElementHitsDone"] = {
						["Holy"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 6,
								},
								["Hit"] = {
									["count"] = 33,
								},
							},
							["amount"] = 39,
						},
						["Melee"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 23,
								},
							},
							["amount"] = 28,
						},
						["Physical"] = {
							["Details"] = {
								["Crit"] = {
									["count"] = 8,
								},
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 22,
						},
					},
					["TimeSpent"] = {
						["疤爪"] = {
							["Details"] = {
								["圣殿骑士的裁决"] = {
									["count"] = 4.63,
								},
								["十字军打击"] = {
									["count"] = 4.63,
								},
								["灰烬觉醒"] = {
									["count"] = 0.36,
								},
								["愤怒之锤"] = {
									["count"] = 1.5,
								},
								["审判"] = {
									["count"] = 2.97,
								},
								["公正之剑"] = {
									["count"] = 0.75,
								},
								["肉搏"] = {
									["count"] = 6.05,
								},
							},
							["amount"] = 20.89,
						},
						["刚被石化的敌人"] = {
							["Details"] = {
								["愤怒之锤"] = {
									["count"] = 1.45,
								},
								["处决宣判"] = {
									["count"] = 0.38,
								},
								["公正之剑"] = {
									["count"] = 2.9,
								},
								["肉搏"] = {
									["count"] = 1.01,
								},
							},
							["amount"] = 5.74,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 1.27,
								},
								["审判"] = {
									["count"] = 1.5,
								},
								["公正之剑"] = {
									["count"] = 1.24,
								},
								["肉搏"] = {
									["count"] = 1.58,
								},
							},
							["amount"] = 5.59,
						},
						["热带蟾蜍"] = {
							["Details"] = {
								["复仇之盾"] = {
									["count"] = 1.41,
								},
							},
							["amount"] = 1.41,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 1.22,
								},
							},
							["amount"] = 1.22,
						},
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 0.6,
								},
								["复仇之盾"] = {
									["count"] = 1.09,
								},
								["强效智慧祝福"] = {
									["count"] = 73.31,
								},
								["强效王者祝福"] = {
									["count"] = 18.5,
								},
							},
							["amount"] = 93.5,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 2.21,
								},
								["审判官复仇"] = {
									["count"] = 1.37,
								},
								["圣殿骑士的裁决"] = {
									["count"] = 3.89,
								},
								["十字军打击"] = {
									["count"] = 6.47,
								},
								["愤怒之锤"] = {
									["count"] = 6.32,
								},
								["灰烬觉醒"] = {
									["count"] = 3,
								},
								["处决宣判"] = {
									["count"] = 1.7,
								},
								["审判"] = {
									["count"] = 4.61,
								},
								["公正之剑"] = {
									["count"] = 9.42,
								},
								["肉搏"] = {
									["count"] = 15.05,
								},
							},
							["amount"] = 54.04,
						},
					},
					["DamageTaken"] = 157101,
					["Attacks"] = {
						["神圣风暴"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 12274,
									["min"] = 12274,
									["count"] = 1,
									["amount"] = 12274,
								},
								["Hit"] = {
									["max"] = 6138,
									["min"] = 5077,
									["count"] = 9,
									["amount"] = 46761,
								},
							},
							["count"] = 10,
							["amount"] = 59035,
						},
						["审判官复仇"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 24802,
									["min"] = 24802,
									["count"] = 1,
									["amount"] = 24802,
								},
							},
							["count"] = 1,
							["amount"] = 24802,
						},
						["复仇之盾"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8977,
									["min"] = 8976,
									["count"] = 2,
									["amount"] = 17953,
								},
							},
							["count"] = 2,
							["amount"] = 17953,
						},
						["圣殿骑士的裁决"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 18106,
									["min"] = 10615,
									["count"] = 8,
									["amount"] = 103018,
								},
							},
							["count"] = 8,
							["amount"] = 103018,
						},
						["十字军打击"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6138,
									["min"] = 4498,
									["count"] = 7,
									["amount"] = 37081,
								},
								["Hit"] = {
									["max"] = 2343,
									["min"] = 2249,
									["count"] = 2,
									["amount"] = 4592,
								},
							},
							["count"] = 9,
							["amount"] = 41673,
						},
						["愤怒之锤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12082,
									["min"] = 5034,
									["count"] = 7,
									["amount"] = 47182,
								},
							},
							["count"] = 7,
							["amount"] = 47182,
						},
						["灰烬觉醒"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 22982,
									["min"] = 22982,
									["count"] = 1,
									["amount"] = 22982,
								},
								["Hit"] = {
									["max"] = 11491,
									["min"] = 11490,
									["count"] = 7,
									["amount"] = 80436,
								},
							},
							["count"] = 8,
							["amount"] = 103418,
						},
						["处决宣判"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 26264,
									["min"] = 26264,
									["count"] = 1,
									["amount"] = 26264,
								},
								["Hit"] = {
									["max"] = 21887,
									["min"] = 10943,
									["count"] = 3,
									["amount"] = 47467,
								},
							},
							["count"] = 4,
							["amount"] = 73731,
						},
						["审判"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 13619,
									["min"] = 9981,
									["count"] = 3,
									["amount"] = 33994,
								},
								["Hit"] = {
									["max"] = 5340,
									["min"] = 4990,
									["count"] = 4,
									["amount"] = 20311,
								},
							},
							["count"] = 7,
							["amount"] = 54305,
						},
						["公正之剑"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 17051,
									["min"] = 17051,
									["count"] = 1,
									["amount"] = 17051,
								},
								["Hit"] = {
									["max"] = 8526,
									["min"] = 4263,
									["count"] = 12,
									["amount"] = 60005,
								},
							},
							["count"] = 13,
							["amount"] = 77056,
						},
						["肉搏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6621,
									["min"] = 4812,
									["count"] = 5,
									["amount"] = 27789,
								},
								["Hit"] = {
									["max"] = 4738,
									["min"] = 2362,
									["count"] = 23,
									["amount"] = 62273,
								},
							},
							["count"] = 28,
							["amount"] = 90062,
						},
					},
					["PartialResist"] = {
						["吸血鬼之咬 (伤害/跳)"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
						["岩石吐息"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 8,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 8,
						},
						["腐化之爪"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 1,
						},
						["啄击"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 2,
						},
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 45,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 45,
						},
					},
					["ManaGained"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 80,
								},
							},
							["amount"] = 80,
						},
					},
					["ElementTakenAbsorb"] = {
						["Physical"] = 262,
						["Melee"] = 54835,
						["Nature"] = 22608,
					},
					["ActiveTime"] = 182.39,
					["HOT_Time"] = 165,
					["ElementTaken"] = {
						["Physical"] = 12601,
						["Melee"] = 90300,
						["Nature"] = 54200,
					},
					["HOTs"] = {
						["强效智慧祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["count"] = 165,
								},
							},
							["amount"] = 165,
						},
					},
					["Damage"] = 692235,
					["WhoHealed"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 14918,
								},
								["复仇之盾"] = {
									["count"] = 17953,
								},
								["强效智慧祝福"] = {
									["count"] = 12896,
								},
								["强效王者祝福"] = {
									["count"] = 55854,
								},
							},
							["amount"] = 101621,
						},
					},
					["TimeHeal"] = 93.5,
					["PartialAbsorb"] = {
						["吸血鬼之咬 (伤害/跳)"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 262,
									["min"] = 262,
									["count"] = 1,
									["amount"] = 262,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 262,
						},
						["岩石吐息"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 8049,
									["min"] = 3617,
									["count"] = 4,
									["amount"] = 22608,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 8,
							["amount"] = 22608,
						},
						["腐化之爪"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 0,
								},
							},
							["count"] = 1,
							["amount"] = 0,
						},
						["啄击"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 2,
							["amount"] = 0,
						},
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 24,
									["amount"] = 0,
								},
								["被吸收"] = {
									["max"] = 5099,
									["min"] = 1041,
									["count"] = 21,
									["amount"] = 54835,
								},
							},
							["count"] = 45,
							["amount"] = 54835,
						},
					},
					["HealedWho"] = {
						["Jerrya-亚雷戈斯"] = {
							["Details"] = {
								["审判官复仇"] = {
									["count"] = 14918,
								},
								["复仇之盾"] = {
									["count"] = 17953,
								},
								["强效智慧祝福"] = {
									["count"] = 12896,
								},
								["强效王者祝福"] = {
									["count"] = 55854,
								},
							},
							["amount"] = 101621,
						},
					},
					["Heals"] = {
						["审判官复仇"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 14918,
									["min"] = 14918,
									["count"] = 1,
									["amount"] = 14918,
								},
							},
							["count"] = 1,
							["amount"] = 14918,
						},
						["复仇之盾"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 5099,
									["min"] = 2421,
									["count"] = 5,
									["amount"] = 17953,
								},
							},
							["count"] = 5,
							["amount"] = 17953,
						},
						["强效智慧祝福"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 242,
									["min"] = 232,
									["count"] = 55,
									["amount"] = 12896,
								},
							},
							["count"] = 55,
							["amount"] = 12896,
						},
						["强效王者祝福"] = {
							["Details"] = {
								["Absorb"] = {
									["max"] = 4674,
									["min"] = 262,
									["count"] = 22,
									["amount"] = 55854,
								},
							},
							["count"] = 22,
							["amount"] = 55854,
						},
					},
					["Healing"] = 27814,
					["Absorbs"] = 73807,
					["ElementHitsTaken"] = {
						["Physical"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 2,
								},
							},
							["amount"] = 7,
						},
						["Melee"] = {
							["Details"] = {
								["Parry"] = {
									["count"] = 2,
								},
								["Absorb"] = {
									["count"] = 21,
								},
								["Miss"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 20,
								},
							},
							["amount"] = 45,
						},
						["Nature"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 9,
						},
					},
					["ElementDone"] = {
						["Holy"] = 380026,
						["Melee"] = 90062,
						["Physical"] = 118729,
					},
					["HealingTaken"] = 101621,
					["DamagedWho"] = {
						["疤爪"] = {
							["Details"] = {
								["圣殿骑士的裁决"] = {
									["count"] = 54260,
								},
								["十字军打击"] = {
									["count"] = 21787,
								},
								["灰烬觉醒"] = {
									["count"] = 22982,
								},
								["愤怒之锤"] = {
									["count"] = 5610,
								},
								["神圣风暴"] = {
									["count"] = 6138,
								},
								["审判"] = {
									["count"] = 23600,
								},
								["公正之剑"] = {
									["count"] = 10080,
								},
								["肉搏"] = {
									["count"] = 23677,
								},
							},
							["amount"] = 168134,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 14637,
								},
								["审判"] = {
									["count"] = 5340,
								},
								["公正之剑"] = {
									["count"] = 4562,
								},
								["肉搏"] = {
									["count"] = 4846,
								},
							},
							["amount"] = 29385,
						},
						["热带蟾蜍"] = {
							["Details"] = {
								["复仇之盾"] = {
									["count"] = 8977,
								},
							},
							["amount"] = 8977,
						},
						["刚被石化的敌人"] = {
							["Details"] = {
								["愤怒之锤"] = {
									["count"] = 12082,
								},
								["处决宣判"] = {
									["count"] = 21887,
								},
								["公正之剑"] = {
									["count"] = 25577,
								},
								["肉搏"] = {
									["count"] = 4738,
								},
							},
							["amount"] = 64284,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["灰烬觉醒"] = {
									["count"] = 22982,
								},
								["神圣风暴"] = {
									["count"] = 12274,
								},
							},
							["amount"] = 35256,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 40623,
								},
								["审判官复仇"] = {
									["count"] = 24802,
								},
								["复仇之盾"] = {
									["count"] = 8976,
								},
								["圣殿骑士的裁决"] = {
									["count"] = 48758,
								},
								["十字军打击"] = {
									["count"] = 19886,
								},
								["愤怒之锤"] = {
									["count"] = 29490,
								},
								["灰烬觉醒"] = {
									["count"] = 57454,
								},
								["处决宣判"] = {
									["count"] = 37207,
								},
								["审判"] = {
									["count"] = 25365,
								},
								["公正之剑"] = {
									["count"] = 36837,
								},
								["肉搏"] = {
									["count"] = 56801,
								},
							},
							["amount"] = 386199,
						},
					},
					["TimeDamage"] = 88.89,
					["TimeDamaging"] = {
						["疤爪"] = {
							["Details"] = {
								["圣殿骑士的裁决"] = {
									["count"] = 4.63,
								},
								["十字军打击"] = {
									["count"] = 4.63,
								},
								["灰烬觉醒"] = {
									["count"] = 0.36,
								},
								["愤怒之锤"] = {
									["count"] = 1.5,
								},
								["审判"] = {
									["count"] = 2.97,
								},
								["公正之剑"] = {
									["count"] = 0.75,
								},
								["肉搏"] = {
									["count"] = 6.05,
								},
							},
							["amount"] = 20.89,
						},
						["砾鳞凝视者"] = {
							["Details"] = {
								["处决宣判"] = {
									["count"] = 1.27,
								},
								["审判"] = {
									["count"] = 1.5,
								},
								["公正之剑"] = {
									["count"] = 1.24,
								},
								["肉搏"] = {
									["count"] = 1.58,
								},
							},
							["amount"] = 5.59,
						},
						["热带蟾蜍"] = {
							["Details"] = {
								["复仇之盾"] = {
									["count"] = 1.41,
								},
							},
							["amount"] = 1.41,
						},
						["刚被石化的敌人"] = {
							["Details"] = {
								["愤怒之锤"] = {
									["count"] = 1.45,
								},
								["处决宣判"] = {
									["count"] = 0.38,
								},
								["公正之剑"] = {
									["count"] = 2.9,
								},
								["肉搏"] = {
									["count"] = 1.01,
								},
							},
							["amount"] = 5.74,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 1.22,
								},
							},
							["amount"] = 1.22,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["神圣风暴"] = {
									["count"] = 2.21,
								},
								["审判官复仇"] = {
									["count"] = 1.37,
								},
								["圣殿骑士的裁决"] = {
									["count"] = 3.89,
								},
								["十字军打击"] = {
									["count"] = 6.47,
								},
								["愤怒之锤"] = {
									["count"] = 6.32,
								},
								["灰烬觉醒"] = {
									["count"] = 3,
								},
								["处决宣判"] = {
									["count"] = 1.7,
								},
								["审判"] = {
									["count"] = 4.61,
								},
								["公正之剑"] = {
									["count"] = 9.42,
								},
								["肉搏"] = {
									["count"] = 15.05,
								},
							},
							["amount"] = 54.04,
						},
					},
					["ManaGain"] = 80,
					["WhoDamaged"] = {
						["刚被石化的敌人"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 4521,
								},
							},
							["amount"] = 4521,
						},
						["疤爪"] = {
							["Details"] = {
								["腐化之爪"] = {
									["count"] = 9178,
								},
								["吸血鬼之咬 (伤害/跳)"] = {
									["count"] = 10372,
								},
								["肉搏"] = {
									["count"] = 32638,
								},
							},
							["amount"] = 52188,
						},
						["断喙雏鸟"] = {
							["Details"] = {
								["啄击"] = {
									["count"] = 2229,
								},
								["肉搏"] = {
									["count"] = 1989,
								},
							},
							["amount"] = 4218,
						},
						["砾鳞蜥蜴"] = {
							["Details"] = {
								["岩石吐息"] = {
									["count"] = 45022,
								},
								["肉搏"] = {
									["count"] = 51152,
								},
							},
							["amount"] = 96174,
						},
					},
					["Absorbed"] = {
						["复仇之盾"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["max"] = 5099,
									["min"] = 2421,
									["count"] = 5,
									["amount"] = 17953,
								},
							},
							["count"] = 5,
							["amount"] = 17953,
						},
						["强效王者祝福"] = {
							["Details"] = {
								["Jerrya-亚雷戈斯"] = {
									["max"] = 4674,
									["min"] = 262,
									["count"] = 22,
									["amount"] = 55854,
								},
							},
							["count"] = 22,
							["amount"] = 55854,
						},
					},
				},
			},
			["UnitLockout"] = 2124.029,
			["LastActive"] = 2272.027,
		},
		["捅捅痛-末日行者"] = {
			["GUID"] = "Player-1939-05BE8EBF",
			["LastEventHealth"] = {
				140580, -- [1]
				140580, -- [2]
				140580, -- [3]
				140580, -- [4]
				140580, -- [5]
				140580, -- [6]
				140580, -- [7]
				140580, -- [8]
				140580, -- [9]
				140580, -- [10]
				140580, -- [11]
				140580, -- [12]
				140580, -- [13]
				140580, -- [14]
				140580, -- [15]
				140580, -- [16]
				140580, -- [17]
				140580, -- [18]
				140580, -- [19]
				140580, -- [20]
				140580, -- [21]
				140580, -- [22]
				140580, -- [23]
				140580, -- [24]
				140580, -- [25]
				140580, -- [26]
				140580, -- [27]
				140580, -- [28]
				140580, -- [29]
				140580, -- [30]
				140580, -- [31]
				140580, -- [32]
				140580, -- [33]
				140580, -- [34]
				140580, -- [35]
				128389, -- [36]
				128389, -- [37]
				128389, -- [38]
				128389, -- [39]
				128389, -- [40]
				128389, -- [41]
				128389, -- [42]
				128389, -- [43]
				128389, -- [44]
				128389, -- [45]
				128389, -- [46]
				128389, -- [47]
				128389, -- [48]
			},
			["LastAttackedBy"] = "宝石碎片巨像",
			["LastEventType"] = {
				"DAMAGE", -- [1]
				"DAMAGE", -- [2]
				"DAMAGE", -- [3]
				"DAMAGE", -- [4]
				"DAMAGE", -- [5]
				"DAMAGE", -- [6]
				"DAMAGE", -- [7]
				"DAMAGE", -- [8]
				"DAMAGE", -- [9]
				"DAMAGE", -- [10]
				"DAMAGE", -- [11]
				"DAMAGE", -- [12]
				"DAMAGE", -- [13]
				"DAMAGE", -- [14]
				"DAMAGE", -- [15]
				"DAMAGE", -- [16]
				"DAMAGE", -- [17]
				"DAMAGE", -- [18]
				"DAMAGE", -- [19]
				"DAMAGE", -- [20]
				"DAMAGE", -- [21]
				"DAMAGE", -- [22]
				"DAMAGE", -- [23]
				"DAMAGE", -- [24]
				"DAMAGE", -- [25]
				"DAMAGE", -- [26]
				"DAMAGE", -- [27]
				"DAMAGE", -- [28]
				"DAMAGE", -- [29]
				"DAMAGE", -- [30]
				"DAMAGE", -- [31]
				"DAMAGE", -- [32]
				"DAMAGE", -- [33]
				"DAMAGE", -- [34]
				"DAMAGE", -- [35]
				"DAMAGE", -- [36]
				"DAMAGE", -- [37]
				"DAMAGE", -- [38]
				"DAMAGE", -- [39]
				"DAMAGE", -- [40]
				"DAMAGE", -- [41]
				"DAMAGE", -- [42]
				"DAMAGE", -- [43]
				"DAMAGE", -- [44]
				"DAMAGE", -- [45]
				"DAMAGE", -- [46]
				"DAMAGE", -- [47]
				"DAMAGE", -- [48]
			},
			["TimeWindows"] = {
				["ActiveTime"] = {
					12.61, -- [1]
				},
				["DamageTaken"] = {
					23430, -- [1]
				},
				["TimeDamage"] = {
					12.61, -- [1]
				},
				["DOT_Time"] = {
					54, -- [1]
				},
				["Damage"] = {
					129455, -- [1]
				},
			},
			["enClass"] = "ROGUE",
			["unit"] = "捅捅痛-末日行者",
			["level"] = 120,
			["LastDamageAbility"] = "肉搏",
			["LastFightIn"] = 3,
			["type"] = "Grouped",
			["FightsSaved"] = 4,
			["LastDamageTaken"] = 6737,
			["TimeLast"] = {
				["DamageTaken"] = 2217.023,
				["ActiveTime"] = 2228.026,
				["TimeDamage"] = 2228.026,
				["OVERALL"] = 2228.026,
				["DOT_Time"] = 2228.026,
				["Damage"] = 2228.026,
			},
			["Owner"] = false,
			["LastEventHealthMax"] = {
				140580, -- [1]
				140580, -- [2]
				140580, -- [3]
				140580, -- [4]
				140580, -- [5]
				140580, -- [6]
				140580, -- [7]
				140580, -- [8]
				140580, -- [9]
				140580, -- [10]
				140580, -- [11]
				140580, -- [12]
				140580, -- [13]
				140580, -- [14]
				140580, -- [15]
				140580, -- [16]
				140580, -- [17]
				140580, -- [18]
				140580, -- [19]
				140580, -- [20]
				140580, -- [21]
				140580, -- [22]
				140580, -- [23]
				140580, -- [24]
				140580, -- [25]
				140580, -- [26]
				140580, -- [27]
				140580, -- [28]
				140580, -- [29]
				140580, -- [30]
				140580, -- [31]
				140580, -- [32]
				140580, -- [33]
				140580, -- [34]
				140580, -- [35]
				140580, -- [36]
				140580, -- [37]
				140580, -- [38]
				140580, -- [39]
				140580, -- [40]
				140580, -- [41]
				140580, -- [42]
				140580, -- [43]
				140580, -- [44]
				140580, -- [45]
				140580, -- [46]
				140580, -- [47]
				140580, -- [48]
			},
			["NextEventNum"] = 49,
			["LastDamageTime"] = 2228.18,
			["LastEvents"] = {
				"宝石碎片巨像 肉搏 捅捅痛-末日行者 Dodge (1)", -- [1]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -508 (Nature)", -- [2]
				"捅捅痛-末日行者 深度坠落 宝石碎片巨像 Hit -569 (Physical)", -- [3]
				"捅捅痛-末日行者 锁喉 (伤害/跳) 宝石碎片巨像 Tick -5270 (Physical)", -- [4]
				"捅捅痛-末日行者 致命药膏 (伤害/跳) 宝石碎片巨像 Crit -1567 (Nature)", -- [5]
				"宝石碎片巨像 肉搏 捅捅痛-末日行者 Absorb -6916 (6916 被吸收) (1)", -- [6]
				"捅捅痛-末日行者 割裂 (伤害/跳) 宝石碎片巨像 Crit -3116 (Physical)", -- [7]
				"捅捅痛-末日行者 锁喉 (伤害/跳) 宝石碎片巨像 Crit -13702 (Physical)", -- [8]
				"捅捅痛-末日行者 致命药膏 (伤害/跳) 宝石碎片巨像 Tick -1019 (Nature)", -- [9]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -728 (Nature)", -- [10]
				"宝石碎片巨像 肉搏 捅捅痛-末日行者 Absorb -4323 (1)", -- [11]
				"宝石碎片巨像 肉搏 捅捅痛-末日行者 Hit -5454 (4323 被吸收) (Physical)", -- [12]
				"捅捅痛-末日行者 淬毒之刃 宝石碎片巨像 Hit -8568 (Nature)", -- [13]
				"捅捅痛-末日行者 割裂 (伤害/跳) 宝石碎片巨像 Tick -2026 (Physical)", -- [14]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -946 (Nature)", -- [15]
				"捅捅痛-末日行者 锁喉 (伤害/跳) 宝石碎片巨像 Tick -6851 (Physical)", -- [16]
				"捅捅痛-末日行者 致命药膏 (伤害/跳) 宝石碎片巨像 Tick -1324 (Nature)", -- [17]
				"捅捅痛-末日行者 毒伤 宝石碎片巨像 Hit -12227 (Nature)", -- [18]
				"捅捅痛-末日行者 毒液炸弹 宝石碎片巨像 Hit -2311 (Nature)", -- [19]
				"宝石碎片巨像 肉搏 捅捅痛-末日行者 Hit -6737 (Physical)", -- [20]
				"捅捅痛-末日行者 割裂 (伤害/跳) 宝石碎片巨像 Tick -2026 (Physical)", -- [21]
				"捅捅痛-末日行者 毁伤 宝石碎片巨像 Crit -6041 (Physical)", -- [22]
				"捅捅痛-末日行者 毁伤 宝石碎片巨像 Hit -1500 (Physical)", -- [23]
				"捅捅痛-末日行者 毒液炸弹 宝石碎片巨像 Hit -2312 (Nature)", -- [24]
				"捅捅痛-末日行者 毒液炸弹 宝石碎片巨像 Hit -2311 (Nature)", -- [25]
				"捅捅痛-末日行者 锁喉 (伤害/跳) 宝石碎片巨像 Tick -6851 (Physical)", -- [26]
				"捅捅痛-末日行者 致命药膏 (伤害/跳) 宝石碎片巨像 Crit -2648 (Nature)", -- [27]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -946 (Nature)", -- [28]
				"捅捅痛-末日行者 深度坠落 宝石碎片巨像 Hit -569 (Physical)", -- [29]
				"捅捅痛-末日行者 毁伤 宝石碎片巨像 Hit -3020 (Physical)", -- [30]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -945 (Nature)", -- [31]
				"捅捅痛-末日行者 毁伤 宝石碎片巨像 Crit -2999 (Physical)", -- [32]
				"捅捅痛-末日行者 毒液炸弹 宝石碎片巨像 Crit -4623 (Nature)", -- [33]
				"捅捅痛-末日行者 割裂 (伤害/跳) 宝石碎片巨像 Tick -2026 (Physical)", -- [34]
				"捅捅痛-末日行者 深度坠落 宝石碎片巨像 Hit -569 (Physical)", -- [35]
				"捅捅痛-末日行者 割裂 (伤害/跳) 宝石碎片巨像 Tick -2026 (Physical)", -- [36]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -727 (Nature)", -- [37]
				"捅捅痛-末日行者 毁伤 宝石碎片巨像 Crit -6040 (Physical)", -- [38]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -728 (Nature)", -- [39]
				"捅捅痛-末日行者 毁伤 宝石碎片巨像 Hit -1500 (Physical)", -- [40]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -728 (Nature)", -- [41]
				"捅捅痛-末日行者 锁喉 (伤害/跳) 宝石碎片巨像 Tick -6851 (Physical)", -- [42]
				"捅捅痛-末日行者 致命药膏 (伤害/跳) 宝石碎片巨像 Tick -1019 (Nature)", -- [43]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Hit -728 (Nature)", -- [44]
				"捅捅痛-末日行者 割裂 (伤害/跳) 宝石碎片巨像 Tick -2026 (Physical)", -- [45]
				"捅捅痛-末日行者 致命药膏 宝石碎片巨像 Crit -1455 (Nature)", -- [46]
				"捅捅痛-末日行者 锁喉 (伤害/跳) 宝石碎片巨像 Tick -4796 (Physical)", -- [47]
				"捅捅痛-末日行者 致命药膏 (伤害/跳) 宝石碎片巨像 Tick -713 (Nature)", -- [48]
			},
			["Name"] = "捅捅痛-末日行者",
			["LastEventIncoming"] = {
				true, -- [1]
				false, -- [2]
				false, -- [3]
				false, -- [4]
				false, -- [5]
				true, -- [6]
				false, -- [7]
				false, -- [8]
				false, -- [9]
				false, -- [10]
				true, -- [11]
				true, -- [12]
				false, -- [13]
				false, -- [14]
				false, -- [15]
				false, -- [16]
				false, -- [17]
				false, -- [18]
				false, -- [19]
				true, -- [20]
				false, -- [21]
				false, -- [22]
				false, -- [23]
				false, -- [24]
				false, -- [25]
				false, -- [26]
				false, -- [27]
				false, -- [28]
				false, -- [29]
				false, -- [30]
				false, -- [31]
				false, -- [32]
				false, -- [33]
				false, -- [34]
				false, -- [35]
				false, -- [36]
				false, -- [37]
				false, -- [38]
				false, -- [39]
				false, -- [40]
				false, -- [41]
				false, -- [42]
				false, -- [43]
				false, -- [44]
				false, -- [45]
				false, -- [46]
				false, -- [47]
				false, -- [48]
			},
			["LastEventTimes"] = {
				2211.566, -- [1]
				2212.349, -- [2]
				2212.621, -- [3]
				2213.253, -- [4]
				2213.266, -- [5]
				2213.563, -- [6]
				2214.283, -- [7]
				2214.905, -- [8]
				2214.931, -- [9]
				2215.365, -- [10]
				2215.566, -- [11]
				2215.566, -- [12]
				2215.663, -- [13]
				2215.948, -- [14]
				2216.152, -- [15]
				2216.579, -- [16]
				2216.634, -- [17]
				2216.669, -- [18]
				2217.194, -- [19]
				2217.567, -- [20]
				2217.6, -- [21]
				2217.666, -- [22]
				2217.666, -- [23]
				2217.69, -- [24]
				2218.197, -- [25]
				2218.228, -- [26]
				2218.251, -- [27]
				2218.352, -- [28]
				2218.655, -- [29]
				2218.68, -- [30]
				2218.68, -- [31]
				2218.68, -- [32]
				2218.692, -- [33]
				2219.254, -- [34]
				2219.707, -- [35]
				2225.892, -- [36]
				2226.106, -- [37]
				2226.272, -- [38]
				2226.272, -- [39]
				2226.272, -- [40]
				2226.272, -- [41]
				2226.513, -- [42]
				2226.524, -- [43]
				2227.307, -- [44]
				2227.544, -- [45]
				2227.598, -- [46]
				2228.169, -- [47]
				2228.18, -- [48]
			},
			["Fights"] = {
				["CurrentFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight3"] = {
					["DOTs"] = {
						["锁喉 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
						["致命药膏 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Hit"] = {
									["count"] = 1,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Tick"] = {
									["count"] = 4,
								},
							},
							["amount"] = 6,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 4,
								},
							},
							["amount"] = 7,
						},
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
						["Melee"] = 0,
					},
					["DOT_Time"] = 18,
					["Damage"] = 29337,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
						["Physical"] = 23239,
						["Nature"] = 6098,
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["DamagedWho"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毒液炸弹"] = {
									["count"] = 0,
								},
								["致命药膏"] = {
									["count"] = 4366,
								},
								["毁伤"] = {
									["count"] = 7540,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 1732,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 11647,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 4052,
								},
								["深度坠落"] = {
									["count"] = 0,
								},
							},
							["amount"] = 29337,
						},
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 0,
								},
							},
							["amount"] = 0,
						},
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毒液炸弹"] = {
									["count"] = 0,
								},
								["致命药膏"] = {
									["count"] = 1.04,
								},
								["毁伤"] = {
									["count"] = 0.17,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 0.02,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 0.81,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 1.74,
								},
								["深度坠落"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.78,
						},
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 3.78,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
						["毒液炸弹"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
						["致命药膏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1455,
									["min"] = 1455,
									["count"] = 1,
									["amount"] = 1455,
								},
								["Hit"] = {
									["max"] = 728,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 2911,
								},
							},
							["count"] = 5,
							["amount"] = 4366,
						},
						["毁伤"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6040,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 6040,
								},
								["Hit"] = {
									["max"] = 1500,
									["min"] = 0,
									["count"] = 1,
									["amount"] = 1500,
								},
							},
							["count"] = 2,
							["amount"] = 7540,
						},
						["致命药膏 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
								["Tick"] = {
									["max"] = 1019,
									["min"] = 713,
									["count"] = 2,
									["amount"] = 1732,
								},
							},
							["count"] = 2,
							["amount"] = 1732,
						},
						["锁喉 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 6851,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 11647,
								},
							},
							["count"] = 2,
							["amount"] = 11647,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["Tick"] = {
									["max"] = 2026,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 4052,
								},
							},
							["count"] = 2,
							["amount"] = 4052,
						},
						["深度坠落"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 0,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 0,
						},
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 3.78,
					["TimeDamaging"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毒液炸弹"] = {
									["count"] = 0,
								},
								["致命药膏"] = {
									["count"] = 1.04,
								},
								["毁伤"] = {
									["count"] = 0.17,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 0.02,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 0.81,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 1.74,
								},
								["深度坠落"] = {
									["count"] = 0,
								},
							},
							["amount"] = 3.78,
						},
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["Fight4"] = {
					["DOTs"] = {
						["锁喉 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["致命药膏 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 9,
								},
							},
							["amount"] = 9,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 6,
								},
							},
							["amount"] = 6,
						},
					},
					["TimeSpent"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毒伤"] = {
									["count"] = 0.03,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 1.3,
								},
								["淬毒之刃"] = {
									["count"] = 0.3,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 0.09,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 1.68,
								},
								["致命药膏"] = {
									["count"] = 2.13,
								},
								["深度坠落"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 5.8,
						},
					},
					["DamageTaken"] = 16693,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 4,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 4,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 6916,
									["min"] = 4323,
									["count"] = 2,
									["amount"] = 11239,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 2,
									["amount"] = 0,
								},
							},
							["count"] = 4,
							["amount"] = 11239,
						},
					},
					["ActiveTime"] = 5.8,
					["ElementTaken"] = {
						["Melee"] = 16693,
					},
					["DOT_Time"] = 24,
					["Damage"] = 58421,
					["ElementTakenAbsorb"] = {
						["Melee"] = 11239,
					},
					["Attacks"] = {
						["毒伤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12227,
									["min"] = 12227,
									["count"] = 1,
									["amount"] = 12227,
								},
							},
							["count"] = 1,
							["amount"] = 12227,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3116,
									["min"] = 3116,
									["count"] = 1,
									["amount"] = 3116,
								},
								["Tick"] = {
									["max"] = 2026,
									["min"] = 2026,
									["count"] = 1,
									["amount"] = 2026,
								},
							},
							["count"] = 2,
							["amount"] = 5142,
						},
						["淬毒之刃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8568,
									["min"] = 8568,
									["count"] = 1,
									["amount"] = 8568,
								},
							},
							["count"] = 1,
							["amount"] = 8568,
						},
						["致命药膏 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1567,
									["min"] = 1567,
									["count"] = 1,
									["amount"] = 1567,
								},
								["Tick"] = {
									["max"] = 1324,
									["min"] = 1019,
									["count"] = 2,
									["amount"] = 2343,
								},
							},
							["count"] = 3,
							["amount"] = 3910,
						},
						["锁喉 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 13702,
									["min"] = 13702,
									["count"] = 1,
									["amount"] = 13702,
								},
								["Tick"] = {
									["max"] = 6851,
									["min"] = 5270,
									["count"] = 2,
									["amount"] = 12121,
								},
							},
							["count"] = 3,
							["amount"] = 25823,
						},
						["致命药膏"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 946,
									["min"] = 508,
									["count"] = 3,
									["amount"] = 2182,
								},
							},
							["count"] = 3,
							["amount"] = 2182,
						},
						["深度坠落"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 569,
									["min"] = 569,
									["count"] = 1,
									["amount"] = 569,
								},
							},
							["count"] = 1,
							["amount"] = 569,
						},
					},
					["WhoDamaged"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 16693,
								},
							},
							["amount"] = 16693,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 3,
								},
								["Crit"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
							},
							["amount"] = 6,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 2,
								},
								["Crit"] = {
									["count"] = 1,
								},
								["Hit"] = {
									["count"] = 5,
								},
							},
							["amount"] = 8,
						},
					},
					["TimeDamage"] = 5.8,
					["TimeDamaging"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毒伤"] = {
									["count"] = 0.03,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 1.3,
								},
								["淬毒之刃"] = {
									["count"] = 0.3,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 0.09,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 1.68,
								},
								["致命药膏"] = {
									["count"] = 2.13,
								},
								["深度坠落"] = {
									["count"] = 0.27,
								},
							},
							["amount"] = 5.8,
						},
					},
					["DamagedWho"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毒伤"] = {
									["count"] = 12227,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 5142,
								},
								["淬毒之刃"] = {
									["count"] = 8568,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 3910,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 25823,
								},
								["致命药膏"] = {
									["count"] = 2182,
								},
								["深度坠落"] = {
									["count"] = 569,
								},
							},
							["amount"] = 58421,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 1,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 4,
						},
					},
					["ElementDone"] = {
						["Physical"] = 31534,
						["Nature"] = 26887,
					},
				},
				["LastFightData"] = {
					["DOTs"] = {
					},
					["ElementDoneResist"] = {
					},
					["Ressed"] = 0,
					["DamageTaken"] = 0,
					["RageGainedFrom"] = {
					},
					["ElementHitsTaken"] = {
					},
					["DeathCount"] = 0,
					["HOT_Time"] = 0,
					["ElementHitsDone"] = {
					},
					["ElementTakenAbsorb"] = {
					},
					["ElementTaken"] = {
					},
					["DOT_Time"] = 0,
					["Damage"] = 0,
					["ElementTakenBlock"] = {
					},
					["TimeHeal"] = 0,
					["RessedWho"] = {
					},
					["Dispels"] = 0,
					["ElementTakenResist"] = {
					},
					["ElementDoneAbsorb"] = {
					},
					["FAttacks"] = {
					},
					["RunicPowerGainedFrom"] = {
					},
					["ElementDone"] = {
					},
					["PartialAbsorb"] = {
					},
					["DamagedWho"] = {
					},
					["PartialBlock"] = {
					},
					["WhoDamaged"] = {
					},
					["EnergyGainedFrom"] = {
					},
					["PartialResist"] = {
					},
					["CCBroken"] = {
					},
					["ElementDoneBlock"] = {
					},
					["TimeHealing"] = {
					},
					["OverHeals"] = {
					},
					["ManaGainedFrom"] = {
					},
					["RunicPowerGained"] = {
					},
					["CCBreak"] = 0,
					["RageGained"] = {
					},
					["HealedWho"] = {
					},
					["EnergyGain"] = 0,
					["ManaGained"] = {
					},
					["FDamage"] = 0,
					["Interrupts"] = 0,
					["Overhealing"] = 0,
					["TimeSpent"] = {
					},
					["WhoDispelled"] = {
					},
					["InterruptData"] = {
					},
					["RunicPowerGain"] = 0,
					["Heals"] = {
					},
					["WhoHealed"] = {
					},
					["EnergyGained"] = {
					},
					["ActiveTime"] = 0,
					["Healing"] = 0,
					["FDamagedWho"] = {
					},
					["Dispelled"] = 0,
					["Attacks"] = {
					},
					["HealingTaken"] = 0,
					["RageGain"] = 0,
					["TimeDamage"] = 0,
					["TimeDamaging"] = {
					},
					["ManaGain"] = 0,
					["HOTs"] = {
					},
					["DispelledWho"] = {
					},
				},
				["OverallData"] = {
					["DOTs"] = {
						["锁喉 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["致命药膏 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["宝石碎片巨像"] = {
									["count"] = 18,
								},
							},
							["amount"] = 18,
						},
					},
					["TimeSpent"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毁伤"] = {
									["count"] = 0.26,
								},
								["致命药膏"] = {
									["count"] = 3.27,
								},
								["毒伤"] = {
									["count"] = 0.03,
								},
								["毒液炸弹"] = {
									["count"] = 1.07,
								},
								["淬毒之刃"] = {
									["count"] = 0.3,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 4.01,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 2.52,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 0.13,
								},
								["深度坠落"] = {
									["count"] = 1.02,
								},
							},
							["amount"] = 12.61,
						},
					},
					["DamageTaken"] = 23430,
					["PartialResist"] = {
						["肉搏"] = {
							["Details"] = {
								["未被抵抗"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 5,
									["amount"] = 0,
								},
							},
							["count"] = 0,
							["amount"] = 5,
						},
					},
					["PartialAbsorb"] = {
						["肉搏"] = {
							["Details"] = {
								["被吸收"] = {
									["max"] = 6916,
									["min"] = 4323,
									["count"] = 2,
									["amount"] = 11239,
								},
								["未被吸收"] = {
									["max"] = 0,
									["min"] = 0,
									["count"] = 3,
									["amount"] = 0,
								},
							},
							["count"] = 5,
							["amount"] = 11239,
						},
					},
					["ActiveTime"] = 12.61,
					["ElementTaken"] = {
						["Melee"] = 23430,
					},
					["DOT_Time"] = 54,
					["Damage"] = 129455,
					["ElementTakenAbsorb"] = {
						["Melee"] = 11239,
					},
					["Attacks"] = {
						["毁伤"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 6041,
									["min"] = 2999,
									["count"] = 3,
									["amount"] = 15080,
								},
								["Hit"] = {
									["max"] = 3020,
									["min"] = 1500,
									["count"] = 3,
									["amount"] = 6020,
								},
							},
							["count"] = 6,
							["amount"] = 21100,
						},
						["致命药膏"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 1455,
									["min"] = 1455,
									["count"] = 1,
									["amount"] = 1455,
								},
								["Hit"] = {
									["max"] = 946,
									["min"] = 508,
									["count"] = 9,
									["amount"] = 6984,
								},
							},
							["count"] = 10,
							["amount"] = 8439,
						},
						["毒伤"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 12227,
									["min"] = 12227,
									["count"] = 1,
									["amount"] = 12227,
								},
							},
							["count"] = 1,
							["amount"] = 12227,
						},
						["毒液炸弹"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 4623,
									["min"] = 4623,
									["count"] = 1,
									["amount"] = 4623,
								},
								["Hit"] = {
									["max"] = 2312,
									["min"] = 2311,
									["count"] = 3,
									["amount"] = 6934,
								},
							},
							["count"] = 4,
							["amount"] = 11557,
						},
						["淬毒之刃"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 8568,
									["min"] = 8568,
									["count"] = 1,
									["amount"] = 8568,
								},
							},
							["count"] = 1,
							["amount"] = 8568,
						},
						["割裂 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 3116,
									["min"] = 3116,
									["count"] = 1,
									["amount"] = 3116,
								},
								["Tick"] = {
									["max"] = 2026,
									["min"] = 2026,
									["count"] = 5,
									["amount"] = 10130,
								},
							},
							["count"] = 6,
							["amount"] = 13246,
						},
						["锁喉 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 13702,
									["min"] = 13702,
									["count"] = 1,
									["amount"] = 13702,
								},
								["Tick"] = {
									["max"] = 6851,
									["min"] = 4796,
									["count"] = 5,
									["amount"] = 30619,
								},
							},
							["count"] = 6,
							["amount"] = 44321,
						},
						["致命药膏 (伤害/跳)"] = {
							["Details"] = {
								["Crit"] = {
									["max"] = 2648,
									["min"] = 1567,
									["count"] = 2,
									["amount"] = 4215,
								},
								["Tick"] = {
									["max"] = 1324,
									["min"] = 713,
									["count"] = 4,
									["amount"] = 4075,
								},
							},
							["count"] = 6,
							["amount"] = 8290,
						},
						["深度坠落"] = {
							["Details"] = {
								["Hit"] = {
									["max"] = 569,
									["min"] = 569,
									["count"] = 3,
									["amount"] = 1707,
								},
							},
							["count"] = 3,
							["amount"] = 1707,
						},
					},
					["WhoDamaged"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["肉搏"] = {
									["count"] = 23430,
								},
							},
							["amount"] = 23430,
						},
					},
					["ElementHitsDone"] = {
						["Physical"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 10,
								},
								["Crit"] = {
									["count"] = 5,
								},
								["Hit"] = {
									["count"] = 6,
								},
							},
							["amount"] = 21,
						},
						["Nature"] = {
							["Details"] = {
								["Tick"] = {
									["count"] = 4,
								},
								["Crit"] = {
									["count"] = 4,
								},
								["Hit"] = {
									["count"] = 14,
								},
							},
							["amount"] = 22,
						},
					},
					["TimeDamage"] = 12.61,
					["TimeDamaging"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毁伤"] = {
									["count"] = 0.26,
								},
								["致命药膏"] = {
									["count"] = 3.27,
								},
								["毒伤"] = {
									["count"] = 0.03,
								},
								["毒液炸弹"] = {
									["count"] = 1.07,
								},
								["淬毒之刃"] = {
									["count"] = 0.3,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 4.01,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 2.52,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 0.13,
								},
								["深度坠落"] = {
									["count"] = 1.02,
								},
							},
							["amount"] = 12.61,
						},
					},
					["DamagedWho"] = {
						["宝石碎片巨像"] = {
							["Details"] = {
								["毁伤"] = {
									["count"] = 21100,
								},
								["致命药膏"] = {
									["count"] = 8439,
								},
								["毒伤"] = {
									["count"] = 12227,
								},
								["毒液炸弹"] = {
									["count"] = 11557,
								},
								["淬毒之刃"] = {
									["count"] = 8568,
								},
								["割裂 (伤害/跳)"] = {
									["count"] = 13246,
								},
								["锁喉 (伤害/跳)"] = {
									["count"] = 44321,
								},
								["致命药膏 (伤害/跳)"] = {
									["count"] = 8290,
								},
								["深度坠落"] = {
									["count"] = 1707,
								},
							},
							["amount"] = 129455,
						},
					},
					["ElementHitsTaken"] = {
						["Melee"] = {
							["Details"] = {
								["Absorb"] = {
									["count"] = 2,
								},
								["Hit"] = {
									["count"] = 2,
								},
								["Dodge"] = {
									["count"] = 1,
								},
							},
							["amount"] = 5,
						},
					},
					["ElementDone"] = {
						["Physical"] = 80374,
						["Nature"] = 49081,
					},
				},
			},
			["UnitLockout"] = 2211.024,
			["LastActive"] = 2228.026,
		},
	},
	["FightNum"] = 6,
	["CombatTimes"] = {
		{
			2124.029, -- [1]
			2183.024, -- [2]
			"09:07:34", -- [3]
			"09:08:33", -- [4]
			"砾鳞蜥蜴", -- [5]
		}, -- [1]
		{
			2185.029, -- [1]
			2191.031, -- [2]
			"09:08:36", -- [3]
			"09:08:41", -- [4]
			"砾鳞蜥蜴", -- [5]
		}, -- [2]
		{
			2194.022, -- [1]
			2217.023, -- [2]
			"09:08:45", -- [3]
			"09:09:07", -- [4]
			"疤爪", -- [5]
		}, -- [3]
		{
			2224.023, -- [1]
			2231.022, -- [2]
			"09:09:15", -- [3]
			"09:09:21", -- [4]
			"刚被石化的敌人", -- [5]
		}, -- [4]
		{
			2237.024, -- [1]
			2250.025, -- [2]
			"09:09:28", -- [3]
			"09:09:40", -- [4]
			"砾鳞蜥蜴", -- [5]
		}, -- [5]
		{
			2252.03, -- [1]
			2264.022, -- [2]
			"09:09:42", -- [3]
			"09:09:54", -- [4]
			"砾鳞凝视者", -- [5]
		}, -- [6]
	},
	["FoughtWho"] = {
		"砾鳞凝视者 09:09:42-09:09:54", -- [1]
		"砾鳞蜥蜴 09:09:28-09:09:40", -- [2]
		"刚被石化的敌人 09:09:15-09:09:21", -- [3]
		"疤爪 09:08:45-09:09:07", -- [4]
		"砾鳞蜥蜴 09:08:36-09:08:41", -- [5]
	},
}
