
CombatTimeSettings = {
	["locked"] = false,
	["hide"] = false,
	["posY"] = 868.200012207031,
	["posX"] = 1807.99975585938,
}
