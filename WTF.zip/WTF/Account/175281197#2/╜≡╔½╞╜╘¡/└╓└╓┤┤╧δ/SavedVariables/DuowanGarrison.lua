
MasterPlanPC = {
	["version"] = "0.115",
	["goldCollectedS"] = 0,
	["moE"] = 4.79,
	["moC"] = 5,
	["moN"] = 6,
	["moV"] = 0.9189,
	["goldCollected"] = 3550000,
}
SVPC_GarrisonMissionManager = {
	["ignored_followers"] = {
	},
}
