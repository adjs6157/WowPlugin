
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Qweradf - 金色平原",
	},
	["profiles"] = {
		["Qweradf - 金色平原"] = {
			["version"] = "80000.06",
		},
	},
}
