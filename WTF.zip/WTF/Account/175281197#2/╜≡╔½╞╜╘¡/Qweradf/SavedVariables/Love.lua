
TalentSetManager_Saves = nil
EasyObliterate_IgnoreList = {
}
NomiCakesDatas = {
	["WorkOrders"] = {
	},
	["Version"] = 2,
}
ArtifactPowerUserCharacterDB = {
	["disable"] = {
	},
	["hide"] = false,
}
