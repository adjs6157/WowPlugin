
HunterMod_Saved = nil
HunterModDB = {
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Default",
	},
	["namespaces"] = {
		["zFeeder"] = {
		},
	},
}
