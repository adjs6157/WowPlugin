
CombatTimeSettings = {
	["locked"] = false,
	["posX"] = 1807.99987792969,
	["posY"] = 868.200012207031,
	["hide"] = false,
}
