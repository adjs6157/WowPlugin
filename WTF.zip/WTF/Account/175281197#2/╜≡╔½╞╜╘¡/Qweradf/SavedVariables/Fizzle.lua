
DuowanAddon_FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Qweradf - 金色平原",
	},
	["profiles"] = {
		["Qweradf - 金色平原"] = {
		},
	},
}
