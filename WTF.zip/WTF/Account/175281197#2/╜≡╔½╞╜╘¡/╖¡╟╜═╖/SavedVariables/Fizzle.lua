
DuowanAddon_FizzleDB = {
	["namespaces"] = {
		["Inspect"] = {
		},
	},
	["profileKeys"] = {
		["翻墙头 - 金色平原"] = "翻墙头 - 金色平原",
	},
	["profiles"] = {
		["翻墙头 - 金色平原"] = {
		},
	},
}
