
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["翻墙头 - 金色平原"] = "翻墙头 - 金色平原",
	},
	["profiles"] = {
		["翻墙头 - 金色平原"] = {
			["version"] = "80000.04",
		},
	},
}
