
DuowanAddon_BattleInfoDB = {
	["showstat"] = true,
	["leavetime"] = 10,
	["autoleave"] = true,
	["showhelp"] = true,
	["igleft"] = true,
	["selfsay"] = true,
	["sayto"] = "自己",
	["autorelease"] = false,
}
