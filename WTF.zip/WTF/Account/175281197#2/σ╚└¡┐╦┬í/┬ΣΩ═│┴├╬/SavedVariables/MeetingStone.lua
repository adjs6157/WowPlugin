
MEETINGSTONE_CHARACTER_DB = {
	["profileKeys"] = {
		["落晖沉梦 - 迦拉克隆"] = "落晖沉梦 - 迦拉克隆",
	},
	["profiles"] = {
		["落晖沉梦 - 迦拉克隆"] = {
			["searchHistoryList"] = {
				"6-0-0-0", -- [1]
			},
			["version"] = "80000.04",
			["lastSearchCode"] = "6-0-0-0",
			["worldQuestHelp"] = true,
			["chatGroupListening"] = {
				["APP_WHISPER"] = {
					nil, -- [1]
					nil, -- [2]
					false, -- [3]
					false, -- [4]
					false, -- [5]
					false, -- [6]
					false, -- [7]
					false, -- [8]
					false, -- [9]
					false, -- [10]
				},
			},
		},
	},
}
