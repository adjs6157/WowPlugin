
RelicInspectorCharDB = {
	["profileKeys"] = {
		["落晖沉梦 - 迦拉克隆"] = "落晖沉梦 - 迦拉克隆",
	},
	["char"] = {
		["落晖沉梦 - 迦拉克隆"] = {
			["crucibleUsed"] = true,
			["artifactCache"] = {
				[128289] = {
					{
						["traits"] = {
							{
								["requiredArtifactLevel"] = 0,
								["canChoose"] = false,
								["tier"] = 1,
								["powerID"] = 1739,
								["isChosen"] = true,
								["icon"] = 1033184,
								["spellID"] = 250879,
							}, -- [1]
							{
								["requiredArtifactLevel"] = 60,
								["canChoose"] = false,
								["tier"] = 2,
								["powerID"] = 1781,
								["isChosen"] = false,
								["icon"] = 839910,
								["spellID"] = 252922,
							}, -- [2]
							{
								["requiredArtifactLevel"] = 60,
								["canChoose"] = false,
								["tier"] = 2,
								["powerID"] = 1775,
								["isChosen"] = true,
								["icon"] = 458412,
								["spellID"] = 252207,
							}, -- [3]
							{
								["requiredArtifactLevel"] = 69,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 105,
								["isChosen"] = false,
								["icon"] = 132351,
								["spellID"] = 188632,
							}, -- [4]
							{
								["requiredArtifactLevel"] = 69,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 95,
								["isChosen"] = true,
								["icon"] = 134309,
								["spellID"] = 188635,
							}, -- [5]
							{
								["requiredArtifactLevel"] = 69,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 98,
								["isChosen"] = false,
								["icon"] = 135871,
								["spellID"] = 188683,
							}, -- [6]
						},
						["relic"] = {
							"无尽军团束棒", -- [1]
							454053, -- [2]
							"Iron", -- [3]
							"|cffa335ee|Hitem:152293:::::::::::4:3:3613:1462:3336:::|h[无尽军团束棒]|h|r", -- [4]
						},
					}, -- [1]
					{
						["traits"] = {
							{
								["requiredArtifactLevel"] = 0,
								["canChoose"] = false,
								["tier"] = 1,
								["powerID"] = 1739,
								["isChosen"] = true,
								["icon"] = 1033184,
								["spellID"] = 250879,
							}, -- [1]
							{
								["requiredArtifactLevel"] = 63,
								["canChoose"] = false,
								["tier"] = 2,
								["powerID"] = 1780,
								["isChosen"] = true,
								["icon"] = 615101,
								["spellID"] = 252906,
							}, -- [2]
							{
								["requiredArtifactLevel"] = 63,
								["canChoose"] = false,
								["tier"] = 2,
								["powerID"] = 1783,
								["isChosen"] = false,
								["icon"] = 876916,
								["spellID"] = 253093,
							}, -- [3]
							{
								["requiredArtifactLevel"] = 72,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 95,
								["isChosen"] = true,
								["icon"] = 134309,
								["spellID"] = 188635,
							}, -- [4]
							{
								["requiredArtifactLevel"] = 72,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 101,
								["isChosen"] = false,
								["icon"] = 458971,
								["spellID"] = 203227,
							}, -- [5]
							{
								["requiredArtifactLevel"] = 72,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 96,
								["isChosen"] = false,
								["icon"] = 132353,
								["spellID"] = 216272,
							}, -- [6]
						},
						["relic"] = {
							"不息者之骨", -- [1]
							1518081, -- [2]
							"Blood", -- [3]
							"|cffa335ee|Hitem:143524:::::::::::43:3:3573:1512:3336:::|h[不息者之骨]|h|r", -- [4]
						},
					}, -- [2]
					{
						["traits"] = {
							{
								["requiredArtifactLevel"] = 0,
								["canChoose"] = false,
								["tier"] = 1,
								["powerID"] = 1739,
								["isChosen"] = true,
								["icon"] = 1033184,
								["spellID"] = 250879,
							}, -- [1]
							{
								["requiredArtifactLevel"] = 66,
								["canChoose"] = false,
								["tier"] = 2,
								["powerID"] = 1779,
								["isChosen"] = true,
								["icon"] = 1394892,
								["spellID"] = 252888,
							}, -- [2]
							{
								["requiredArtifactLevel"] = 66,
								["canChoose"] = false,
								["tier"] = 2,
								["powerID"] = 1770,
								["isChosen"] = false,
								["icon"] = 132307,
								["spellID"] = 252088,
							}, -- [3]
							{
								["requiredArtifactLevel"] = 75,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 106,
								["isChosen"] = false,
								["icon"] = 136105,
								["spellID"] = 188644,
							}, -- [4]
							{
								["requiredArtifactLevel"] = 75,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 100,
								["isChosen"] = true,
								["icon"] = 236310,
								["spellID"] = 203225,
							}, -- [5]
							{
								["requiredArtifactLevel"] = 75,
								["canChoose"] = false,
								["tier"] = 3,
								["powerID"] = 105,
								["isChosen"] = false,
								["icon"] = 132351,
								["spellID"] = 188632,
							}, -- [6]
						},
						["relic"] = {
							"狱卒的火把", -- [1]
							135432, -- [2]
							"Fire", -- [3]
							"|cffa335ee|Hitem:141279:::::::::::43:3:3573:1577:3336:::|h[狱卒的火把]|h|r", -- [4]
						},
					}, -- [3]
					["crucibled"] = true,
					["timestamp"] = 2366485.564,
					["level"] = 75,
				},
			},
		},
	},
}
