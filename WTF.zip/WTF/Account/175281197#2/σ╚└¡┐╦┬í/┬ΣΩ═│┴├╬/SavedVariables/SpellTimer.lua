
SpellTimer_Config = {
	["WarningTime"] = 5,
	["SPELLS"] = {
		["致死打击"] = {
		},
		["法术反射"] = {
		},
		["刺耳怒吼"] = {
		},
		["挫志怒吼"] = {
		},
		["破甲攻击"] = {
		},
		["震荡波"] = {
		},
		["巨人打击"] = {
		},
		["雷霆一击"] = {
		},
	},
	["ShowProgressBar"] = 1,
	["Scale"] = 0.8,
	["HideAllWhenLeaveCombat"] = 1,
	["ShowName"] = 1,
	["EnabledTest"] = 1,
	["mergeAoe"] = true,
}
