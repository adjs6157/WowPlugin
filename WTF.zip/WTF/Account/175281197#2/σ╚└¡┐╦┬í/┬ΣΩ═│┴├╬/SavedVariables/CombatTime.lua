
CombatTimeSettings = {
	["locked"] = false,
	["hide"] = false,
	["posY"] = 868.199951171875,
	["posX"] = 1807.99987792969,
}
