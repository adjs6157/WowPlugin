
RecountDB = {
	["profileKeys"] = {
		["乐乐创想 - 金色平原"] = "乐乐创想 - 金色平原",
	},
	["profiles"] = {
		["乐乐创想 - 金色平原"] = {
			["MainWindow"] = {
				["Position"] = {
					["y"] = 398.002014160156,
					["x"] = 577.00244140625,
					["w"] = 252.000045776367,
					["h"] = 139.999847412109,
				},
			},
			["Colors"] = {
				["Bar"] = {
					["Bar Text"] = {
						["a"] = 1,
					},
					["Total Bar"] = {
						["a"] = 1,
					},
				},
			},
			["MainWindowVis"] = false,
			["LastInstanceName"] = "碎银矿脉",
			["CurDataSet"] = "OverallData",
			["MainWindowWidth"] = 251.999893188477,
			["MainWindowHeight"] = 139.999923706055,
		},
	},
}
Recount_SpeedUpUpdatesDB = {
	["TickInterval"] = 0.5,
}
