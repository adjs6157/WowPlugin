
MasterPlanAG = {
	["迦拉克隆"] = {
		["落晖沉梦"] = {
			["faction"] = "Horde",
			["class"] = "WARRIOR",
		},
	},
	["金色平原"] = {
		["Qweradf"] = {
			["faction"] = "Alliance",
			["class"] = "HUNTER",
		},
		["翻墙头"] = {
			["class"] = "WARRIOR",
			["summary"] = {
				["ti1"] = 118529,
				["ti3"] = 128391,
				["tt3"] = true,
				["tt1"] = true,
			},
			["faction"] = "Alliance",
		},
		["乐乐创想"] = {
			["summary"] = {
				["inProgress"] = {
					[88] = 1535892707,
					[89] = 1535894504,
				},
			},
			["faction"] = "Alliance",
			["class"] = "HUNTER",
			["curRes"] = 1504,
			["lastCacheTime"] = 1537602845,
		},
	},
	["IgnoreRewards"] = {
	},
}
SV_GarrisonMissionManager = {
}
IPMDB = {
	["enableGarrisonMissions"] = true,
	["ignores"] = {
	},
	["profiles"] = {
		["乐乐创想-金色平原"] = {
			{
				["description"] = "",
				["cost"] = 20,
				["isZoneSupport"] = false,
				["locPrefix"] = "GarrMissionLocation-HillsbradFoothills",
				["followers"] = {
					"0x00000000057077B3", -- [1]
					"0x00000000057122A1", -- [2]
					"0x0000000005708EF7", -- [3]
				},
				["inProgress"] = true,
				["overmaxRewards"] = {
					{
						["title"] = "货币奖励",
						["quantity"] = 100,
						["icon"] = 2032594,
						["currencyID"] = 1592,
					}, -- [1]
				},
				["hasBonusEffect"] = true,
				["missionEndTime"] = 1538881442,
				["isMaxLevel"] = true,
				["name"] = "亡灵的崛起",
				["canStart"] = false,
				["typeAtlas"] = "BfAMission-Icon-Normal",
				["successChance"] = 200,
				["followerTypeID"] = 22,
				["offeredGarrMissionTextureID"] = 0,
				["durationSeconds"] = 7200,
				["completed"] = false,
				["missionID"] = 1884,
				["duration"] = "2小时",
				["offerTimeRemaining"] = "0秒",
				["charText"] = "|cffaad372乐乐创想|r-金色平原",
				["timeLeft"] = "1小时59分钟",
				["iLevel"] = 800,
				["mapPosY"] = 0,
				["type"] = "",
				["followerInfo"] = {
					["0x00000000057122A1"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 22,
						["iLevel"] = 800,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-Priest-Shadow",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 0.899999976158142,
								["showWeapon"] = true,
								["id"] = 82386,
							}, -- [1]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 120,
						["quality"] = 4,
						["portraitIconID"] = 2026472,
						["isFavorite"] = false,
						["abilities"] = {
							1043, -- [1]
							1096, -- [2]
							1097, -- [3]
							1100, -- [4]
						},
						["xp"] = 0,
						["className"] = "魔导师",
						["classSpec"] = 189,
						["isMaxLevel"] = true,
						["name"] = "魔导师乌布里克",
						["followerID"] = "0x00000000057122A1",
						["height"] = 1.20000004768372,
						["levelXP"] = 0,
						["isCollected"] = true,
						["garrFollowerID"] = 1072,
					},
					["0x0000000005708EF7"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 22,
						["iLevel"] = 800,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-Hunter-Survival",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 33239,
							}, -- [1]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 120,
						["quality"] = 4,
						["portraitIconID"] = 2026470,
						["isFavorite"] = false,
						["abilities"] = {
							1062, -- [1]
							1091, -- [2]
							1090, -- [3]
							1100, -- [4]
						},
						["xp"] = 0,
						["className"] = "独狼",
						["classSpec"] = 188,
						["isMaxLevel"] = true,
						["name"] = "约翰·J·基沙恩",
						["followerID"] = "0x0000000005708EF7",
						["height"] = 1,
						["levelXP"] = 0,
						["isCollected"] = true,
						["garrFollowerID"] = 1069,
					},
					["0x00000000057077B3"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 22,
						["iLevel"] = 800,
						["scale"] = 0.800000011920929,
						["classAtlas"] = "GarrMission_ClassIcon-Technician",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 31159,
							}, -- [1]
						},
						["displayScale"] = 1.20000004768372,
						["status"] = "正在执行任务",
						["level"] = 120,
						["quality"] = 4,
						["portraitIconID"] = 2026468,
						["isFavorite"] = false,
						["abilities"] = {
							1042, -- [1]
							1098, -- [2]
							1100, -- [3]
							1101, -- [4]
						},
						["xp"] = 0,
						["className"] = "秘密部队技师",
						["classSpec"] = 190,
						["isMaxLevel"] = true,
						["name"] = "凯尔希·钢烁",
						["followerID"] = "0x00000000057077B3",
						["height"] = 1.14999997615814,
						["levelXP"] = 0,
						["isCollected"] = true,
						["garrFollowerID"] = 1068,
					},
				},
				["timeLeftSeconds"] = 7198,
				["overmaxSucceeded"] = false,
				["basecost"] = 20,
				["level"] = 120,
				["numFollowers"] = 3,
				["requiredSuccessChance"] = 0,
				["areaID"] = 21,
				["rewards"] = {
					{
						["title"] = "货币奖励",
						["quantity"] = 100,
						["icon"] = 2032594,
						["currencyID"] = 1592,
					}, -- [1]
				},
				["costCurrencyTypesID"] = 1560,
				["location"] = "药渣农场",
				["isRare"] = false,
				["mapPosX"] = 0,
				["requiredChampionCount"] = 1,
			}, -- [1]
			{
				["description"] = "",
				["cost"] = 20,
				["isZoneSupport"] = false,
				["locPrefix"] = "GarrMissionLocation-NorthernBarrens",
				["followers"] = {
					"0x00000000056CFF89", -- [1]
					"0x00000000059E2C66", -- [2]
					"0x00000000059E2C67", -- [3]
				},
				["inProgress"] = true,
				["overmaxRewards"] = {
					{
						["title"] = "货币奖励",
						["quantity"] = 100,
						["icon"] = 2032591,
						["currencyID"] = 1599,
					}, -- [1]
				},
				["hasBonusEffect"] = true,
				["missionEndTime"] = 1538888645,
				["isMaxLevel"] = true,
				["name"] = "剃刀岭补给",
				["canStart"] = false,
				["typeAtlas"] = "BfAMission-Icon-Normal",
				["successChance"] = 150,
				["followerTypeID"] = 22,
				["offeredGarrMissionTextureID"] = 0,
				["durationSeconds"] = 14400,
				["completed"] = false,
				["missionID"] = 1890,
				["duration"] = "4小时",
				["offerTimeRemaining"] = "0秒",
				["charText"] = "|cffaad372乐乐创想|r-金色平原",
				["timeLeft"] = "4小时",
				["iLevel"] = 800,
				["mapPosY"] = 0,
				["type"] = "",
				["followerInfo"] = {
					["0x00000000056CFF89"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 22,
						["iLevel"] = 800,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-Shaman-Enhancement",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1.29999995231628,
								["showWeapon"] = true,
								["id"] = 32681,
							}, -- [1]
							{
								["followerPageScale"] = 0.800000011920929,
								["showWeapon"] = true,
								["id"] = 87495,
							}, -- [2]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 120,
						["quality"] = 4,
						["portraitIconID"] = 2026469,
						["isFavorite"] = false,
						["abilities"] = {
							1062, -- [1]
							1131, -- [2]
							1087, -- [3]
							1100, -- [4]
						},
						["xp"] = 0,
						["className"] = "鹰巢山大领主",
						["classSpec"] = 187,
						["isMaxLevel"] = true,
						["name"] = "弗斯塔德·蛮锤",
						["followerID"] = "0x00000000056CFF89",
						["height"] = 1.10000002384186,
						["levelXP"] = 0,
						["isCollected"] = true,
						["garrFollowerID"] = 1065,
					},
					["0x00000000059E2C66"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 22,
						["iLevel"] = 800,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-Alliance",
						["isTroop"] = true,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1.10000002384186,
								["showWeapon"] = true,
								["id"] = 36771,
							}, -- [1]
							{
								["followerPageScale"] = 1.10000002384186,
								["showWeapon"] = true,
								["id"] = 33551,
							}, -- [2]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 120,
						["quality"] = 2,
						["portraitIconID"] = 1984899,
						["isFavorite"] = false,
						["abilities"] = {
							1084, -- [1]
							1138, -- [2]
						},
						["maxDurability"] = 2,
						["durability"] = 1,
						["xp"] = 0,
						["className"] = "联盟部队",
						["classSpec"] = 193,
						["isMaxLevel"] = true,
						["name"] = "血牙猎手",
						["followerID"] = "0x00000000059E2C66",
						["height"] = 1.25,
						["levelXP"] = 1000,
						["isCollected"] = true,
						["garrFollowerID"] = 1071,
					},
					["0x00000000059E2C67"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 22,
						["iLevel"] = 1,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-Alliance",
						["isTroop"] = true,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 56347,
							}, -- [1]
							{
								["followerPageScale"] = 0.699999988079071,
								["showWeapon"] = true,
								["id"] = 19872,
							}, -- [2]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 120,
						["quality"] = 2,
						["portraitIconID"] = 1984903,
						["isFavorite"] = false,
						["abilities"] = {
							1085, -- [1]
							1138, -- [2]
						},
						["maxDurability"] = 2,
						["durability"] = 1,
						["xp"] = 0,
						["className"] = "联盟部队",
						["classSpec"] = 193,
						["isMaxLevel"] = true,
						["name"] = "埃索达卫士",
						["followerID"] = "0x00000000059E2C67",
						["height"] = 1.20000004768372,
						["levelXP"] = 1000,
						["isCollected"] = true,
						["garrFollowerID"] = 1070,
					},
				},
				["timeLeftSeconds"] = 14401,
				["overmaxSucceeded"] = false,
				["basecost"] = 20,
				["level"] = 120,
				["numFollowers"] = 3,
				["requiredSuccessChance"] = 0,
				["areaID"] = 21,
				["rewards"] = {
					{
						["title"] = "货币奖励",
						["quantity"] = 100,
						["icon"] = 2032591,
						["currencyID"] = 1599,
					}, -- [1]
				},
				["costCurrencyTypesID"] = 1560,
				["location"] = "剃刀岭",
				["isRare"] = false,
				["mapPosX"] = 0,
				["requiredChampionCount"] = 1,
			}, -- [2]
			{
				["description"] = "",
				["cost"] = 100,
				["isZoneSupport"] = false,
				["locPrefix"] = "GarrMissionLocation-Highmountain",
				["followers"] = {
					"0x00000000055C83DF", -- [1]
				},
				["inProgress"] = true,
				["overmaxRewards"] = {
					{
						["itemID"] = 143786,
						["quantity"] = 1,
					}, -- [1]
				},
				["hasBonusEffect"] = false,
				["missionEndTime"] = 1536421155,
				["isMaxLevel"] = false,
				["name"] = "边境增援",
				["canStart"] = false,
				["typeAtlas"] = "ClassHall-CombatIcon-Desaturated",
				["successChance"] = 79,
				["followerTypeID"] = 4,
				["offeredGarrMissionTextureID"] = 0,
				["durationSeconds"] = 7200,
				["completed"] = false,
				["missionID"] = 1052,
				["duration"] = "2小时",
				["offerTimeRemaining"] = "0秒",
				["charText"] = "|cffaad372乐乐创想|r-金色平原",
				["timeLeft"] = "0秒",
				["iLevel"] = 760,
				["mapPosY"] = 0,
				["type"] = "7.0 职业大厅 - 一般任务",
				["followerInfo"] = {
					["0x00000000055C83DF"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 4,
						["iLevel"] = 760,
						["scale"] = 0.600000023841858,
						["classAtlas"] = "GarrMission_ClassIcon-Hunter-Marksmanship",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 69918,
							}, -- [1]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 101,
						["quality"] = 1,
						["portraitIconID"] = 1396695,
						["isFavorite"] = false,
						["abilities"] = {
							365, -- [1]
							449, -- [2]
						},
						["slotSoundKitID"] = 68442,
						["xp"] = 300,
						["className"] = "射击猎人",
						["classSpec"] = 116,
						["isMaxLevel"] = false,
						["name"] = "罗伦·雷蹄",
						["followerID"] = "0x00000000055C83DF",
						["height"] = 1,
						["levelXP"] = 400,
						["isCollected"] = true,
						["garrFollowerID"] = 742,
					},
				},
				["timeLeftSeconds"] = 0,
				["overmaxSucceeded"] = false,
				["basecost"] = 100,
				["level"] = 100,
				["numFollowers"] = 3,
				["requiredSuccessChance"] = 0,
				["areaID"] = 7503,
				["rewards"] = {
					{
						["itemID"] = 140584,
						["quantity"] = 1,
					}, -- [1]
				},
				["costCurrencyTypesID"] = 1220,
				["location"] = "至高岭",
				["isRare"] = false,
				["mapPosX"] = 0,
				["requiredChampionCount"] = 1,
			}, -- [3]
			{
				["description"] = "",
				["cost"] = 0,
				["isZoneSupport"] = false,
				["locPrefix"] = "GarrMissionLocation-ShadowmoonValley",
				["followers"] = {
					"0x00000000053C422E", -- [1]
				},
				["inProgress"] = true,
				["overmaxRewards"] = {
				},
				["hasBonusEffect"] = false,
				["missionEndTime"] = 1535892707,
				["isMaxLevel"] = false,
				["name"] = "天空的威胁",
				["canStart"] = false,
				["typeAtlas"] = "GarrMission_MissionIcon-Combat",
				["successChance"] = 100,
				["followerTypeID"] = 1,
				["offeredGarrMissionTextureID"] = 0,
				["durationSeconds"] = 1800,
				["completed"] = false,
				["missionID"] = 88,
				["duration"] = "30分钟",
				["offerTimeRemaining"] = "0秒",
				["charText"] = "|cffaad372乐乐创想|r-金色平原",
				["timeLeft"] = "0秒",
				["iLevel"] = 0,
				["mapPosY"] = 0,
				["type"] = "战斗",
				["followerInfo"] = {
					["0x00000000053C422E"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 1,
						["iLevel"] = 600,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-DeathKnight",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 59353,
							}, -- [1]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 91,
						["quality"] = 4,
						["portraitIconID"] = 1066337,
						["isFavorite"] = false,
						["abilities"] = {
							231, -- [1]
							115, -- [2]
							118, -- [3]
							45, -- [4]
							37, -- [5]
						},
						["xp"] = 250,
						["className"] = "鲜血死亡骑士",
						["classSpec"] = 2,
						["isMaxLevel"] = false,
						["name"] = "德尔瓦·铁拳",
						["followerID"] = "0x00000000053C422E",
						["height"] = 1.10000002384186,
						["levelXP"] = 800,
						["isCollected"] = true,
						["garrFollowerID"] = 216,
					},
				},
				["timeLeftSeconds"] = 0,
				["overmaxSucceeded"] = false,
				["basecost"] = 0,
				["level"] = 90,
				["numFollowers"] = 1,
				["requiredSuccessChance"] = 0,
				["areaID"] = 0,
				["rewards"] = {
					{
						["title"] = "货币奖励",
						["quantity"] = 20,
						["icon"] = 1005027,
						["currencyID"] = 824,
					}, -- [1]
				},
				["costCurrencyTypesID"] = 824,
				["location"] = "月花谷",
				["isRare"] = false,
				["mapPosX"] = 0,
				["requiredChampionCount"] = 1,
			}, -- [4]
			{
				["description"] = "",
				["cost"] = 10,
				["isZoneSupport"] = false,
				["locPrefix"] = "GarrMissionLocation-ShadowmoonValley",
				["followers"] = {
					"0x00000000053EF834", -- [1]
					"0x00000000054AB8F4", -- [2]
					"0x00000000054C917F", -- [3]
				},
				["inProgress"] = true,
				["overmaxRewards"] = {
				},
				["hasBonusEffect"] = false,
				["missionEndTime"] = 1535894504,
				["isMaxLevel"] = false,
				["name"] = "突袭影月岗哨",
				["canStart"] = false,
				["typeAtlas"] = "GarrMission_MissionIcon-Combat",
				["successChance"] = 100,
				["followerTypeID"] = 1,
				["offeredGarrMissionTextureID"] = 0,
				["durationSeconds"] = 3600,
				["completed"] = false,
				["missionID"] = 89,
				["duration"] = "1小时",
				["offerTimeRemaining"] = "0秒",
				["charText"] = "|cffaad372乐乐创想|r-金色平原",
				["timeLeft"] = "0秒",
				["iLevel"] = 0,
				["mapPosY"] = 0,
				["type"] = "战斗",
				["followerInfo"] = {
					["0x00000000054AB8F4"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 1,
						["iLevel"] = 600,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-Priest",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 34450,
							}, -- [1]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 90,
						["quality"] = 2,
						["portraitIconID"] = 1066059,
						["isFavorite"] = false,
						["abilities"] = {
							53, -- [1]
							11, -- [2]
						},
						["xp"] = 0,
						["className"] = "神圣牧师",
						["classSpec"] = 24,
						["isMaxLevel"] = false,
						["name"] = "菲奥拉",
						["followerID"] = "0x00000000054AB8F4",
						["height"] = 1.25,
						["levelXP"] = 400,
						["isCollected"] = true,
						["garrFollowerID"] = 180,
					},
					["0x00000000054C917F"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 1,
						["iLevel"] = 600,
						["scale"] = 0.699999988079071,
						["classAtlas"] = "GarrMission_ClassIcon-Rogue",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 60121,
							}, -- [1]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 90,
						["quality"] = 2,
						["portraitIconID"] = 1066399,
						["isFavorite"] = false,
						["abilities"] = {
							160, -- [1]
							60, -- [2]
						},
						["xp"] = 0,
						["className"] = "敏锐潜行者",
						["classSpec"] = 28,
						["isMaxLevel"] = false,
						["name"] = "雪莉·汉比",
						["followerID"] = "0x00000000054C917F",
						["height"] = 1,
						["levelXP"] = 400,
						["isCollected"] = true,
						["garrFollowerID"] = 182,
					},
					["0x00000000053EF834"] = {
						["displayHeight"] = 0.5,
						["followerTypeID"] = 1,
						["iLevel"] = 600,
						["scale"] = 0.600000023841858,
						["classAtlas"] = "GarrMission_ClassIcon-Hunter",
						["isTroop"] = false,
						["displayIDs"] = {
							{
								["followerPageScale"] = 1,
								["showWeapon"] = true,
								["id"] = 57053,
							}, -- [1]
						},
						["displayScale"] = 1,
						["status"] = "正在执行任务",
						["level"] = 90,
						["quality"] = 2,
						["portraitIconID"] = 1066129,
						["isFavorite"] = false,
						["abilities"] = {
							101, -- [1]
							44, -- [2]
						},
						["xp"] = 100,
						["className"] = "射击猎人",
						["classSpec"] = 12,
						["isMaxLevel"] = false,
						["name"] = "游侠切尔",
						["followerID"] = "0x00000000053EF834",
						["height"] = 1.20000004768372,
						["levelXP"] = 400,
						["isCollected"] = true,
						["garrFollowerID"] = 185,
					},
				},
				["timeLeftSeconds"] = 0,
				["overmaxSucceeded"] = false,
				["basecost"] = 10,
				["level"] = 90,
				["numFollowers"] = 3,
				["requiredSuccessChance"] = 0,
				["areaID"] = 0,
				["rewards"] = {
					{
						["itemID"] = 114052,
						["quantity"] = 1,
					}, -- [1]
				},
				["costCurrencyTypesID"] = 824,
				["location"] = "沙兹古尔",
				["isRare"] = true,
				["mapPosX"] = 0,
				["requiredChampionCount"] = 3,
			}, -- [5]
		},
	},
}
