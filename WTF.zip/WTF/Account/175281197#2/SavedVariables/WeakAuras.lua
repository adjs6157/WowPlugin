
WeakAurasSaved = {
	["dynamicIconCache"] = {
		["野兽顺劈"] = {
			[268877] = 461121,
		},
		["狂暴"] = {
			[272790] = 2058007,
		},
		["倒刺射击"] = {
			[246853] = 2058007,
			[246852] = 2058007,
			[246851] = 2058007,
			[246152] = 2058007,
		},
	},
	["talent_cache"] = {
		["HUNTER"] = {
		},
		["WARRIOR"] = {
		},
		["SHAMAN"] = {
		},
		["MAGE"] = {
		},
		["PRIEST"] = {
		},
		["DEATHKNIGHT"] = {
		},
		["WARLOCK"] = {
		},
		["DEMONHUNTER"] = {
		},
		["ROGUE"] = {
		},
		["DRUID"] = {
		},
		["MONK"] = {
		},
		["PALADIN"] = {
		},
	},
	["login_squelch_time"] = 10,
	["registered"] = {
	},
	["displays"] = {
		["宠物生命值"] = {
			["sparkWidth"] = 10,
			["stacksSize"] = 12,
			["xOffset"] = -155,
			["stacksFlags"] = "None",
			["yOffset"] = -518.000102996826,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["rotateText"] = "NONE",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				0.211764705882353, -- [2]
				0.23921568627451, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["load"] = {
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["timerColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["stacks"] = false,
			["texture"] = "Blizzard",
			["textFont"] = "Friz Quadrata TT",
			["borderOffset"] = 5,
			["auto"] = true,
			["timerFont"] = "Friz Quadrata TT",
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["textColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["parent"] = "buff",
			["untrigger"] = {
				["unit"] = "pet",
			},
			["activeTriggerMode"] = -10,
			["sparkRotationMode"] = "AUTO",
			["displayTextLeft"] = "%n",
			["internalVersion"] = 6,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["backdropInFront"] = false,
			["text"] = false,
			["stickyDuration"] = false,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["trigger"] = {
				["type"] = "status",
				["unevent"] = "auto",
				["use_absorbMode"] = true,
				["event"] = "Health",
				["names"] = {
				},
				["spellIds"] = {
				},
				["use_unit"] = true,
				["subeventPrefix"] = "SPELL",
				["subeventSuffix"] = "_CAST_START",
				["unit"] = "pet",
				["debuffType"] = "HELPFUL",
			},
			["spark"] = false,
			["timer"] = false,
			["timerFlags"] = "None",
			["init_started"] = 1,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["sparkOffsetX"] = 0,
			["numTriggers"] = 1,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["height"] = 10,
			["anchorFrameType"] = "SCREEN",
			["border"] = false,
			["borderEdge"] = "None",
			["borderInFront"] = true,
			["borderSize"] = 16,
			["sparkRotation"] = 0,
			["icon_side"] = "RIGHT",
			["id"] = "宠物生命值",
			["customTextUpdate"] = "update",
			["sparkHeight"] = 30,
			["timerSize"] = 12,
			["textSize"] = 12,
			["stacksColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayTextRight"] = "%p",
			["borderInset"] = 11,
			["sparkHidden"] = "NEVER",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["frameStrata"] = 1,
			["width"] = 100,
			["icon"] = false,
			["zoom"] = 0,
			["inverse"] = false,
			["textFlags"] = "None",
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["stacksFont"] = "Friz Quadrata TT",
			["uid"] = "1ucEFqEBmIp",
		},
		["buff"] = {
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["controlledChildren"] = {
				"倒刺射击", -- [1]
				"狂暴断档", -- [2]
				"野兽顺劈", -- [3]
				"治疗宠物", -- [4]
				"夺命黑鸦", -- [5]
				"野性守护", -- [6]
				"狂野怒火", -- [7]
				"杀戮命令", -- [8]
				"眼镜蛇射击", -- [9]
				"奇美拉射击", -- [10]
				"倒刺射击 2", -- [11]
				"多重射击", -- [12]
				"弹幕射击", -- [13]
				"自己集中值", -- [14]
				"宠物生命值", -- [15]
				"检测敌人个数", -- [16]
				"敌人血量", -- [17]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["xOffset"] = -580.999420166016,
			["border"] = false,
			["untrigger"] = {
			},
			["regionType"] = "group",
			["borderSize"] = 16,
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["expanded"] = true,
			["yOffset"] = -5.99920654296875,
			["internalVersion"] = 6,
			["selfPoint"] = "BOTTOMLEFT",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["id"] = "buff",
			["borderEdge"] = "None",
			["frameStrata"] = 1,
			["anchorFrameType"] = "SCREEN",
			["borderOffset"] = 5,
			["borderInset"] = 11,
			["numTriggers"] = 1,
			["anchorPoint"] = "CENTER",
			["trigger"] = {
				["names"] = {
				},
				["type"] = "aura",
				["spellIds"] = {
				},
				["subeventSuffix"] = "_CAST_START",
				["unit"] = "player",
				["subeventPrefix"] = "SPELL",
				["event"] = "Health",
				["debuffType"] = "HELPFUL",
			},
			["conditions"] = {
			},
			["load"] = {
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["scale"] = 1,
		},
		["夺命黑鸦"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -350,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "夺命黑鸦",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 131894,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["single"] = 12,
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["use_talent"] = true,
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "夺命黑鸦",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["弹幕射击"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -35,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "弹幕射击",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 120360,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["single"] = 17,
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["use_talent"] = true,
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
			},
			["text2Containment"] = "INSIDE",
			["internalVersion"] = 6,
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "弹幕射击",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["倒刺射击 2"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 20,
			["xOffset"] = -115,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["use_genericShowOn"] = true,
				["genericShowOn"] = "showAlways",
				["subeventPrefix"] = "SPELL",
				["use_showgcd"] = false,
				["debuffType"] = "HELPFUL",
				["charges_operator"] = ">",
				["type"] = "status",
				["subeventSuffix"] = "_CAST_START",
				["charges"] = "0",
				["event"] = "Cooldown Progress (Spell)",
				["use_charges"] = true,
				["realSpellName"] = "倒刺射击",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["unevent"] = "auto",
				["buffShowOn"] = "showOnCooldown",
				["names"] = {
				},
				["spellName"] = 217200,
				["unit"] = "player",
			},
			["text1Containment"] = "INSIDE",
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["parent"] = "buff",
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["stickyDuration"] = false,
			["displayIcon"] = 655715,
			["desaturate"] = false,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["text1FontFlags"] = "OUTLINE",
			["anchorFrameType"] = "SCREEN",
			["text2FontSize"] = 24,
			["alpha"] = 1,
			["text2Font"] = "Friz Quadrata TT",
			["text1"] = "%s",
			["cooldownTextEnabled"] = true,
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = false,
			["text2Enabled"] = false,
			["id"] = "倒刺射击 2",
			["glow"] = false,
			["frameStrata"] = 1,
			["width"] = 32,
			["text1Font"] = "默认",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["numTriggers"] = 1,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["internalVersion"] = 6,
		},
		["倒刺射击"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -355,
			["yOffset"] = -510,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["rem"] = "1.5",
				["use_absorbMode"] = true,
				["subeventPrefix"] = "SPELL",
				["debuffType"] = "HELPFUL",
				["use_specific_unit"] = false,
				["name_operator"] = "==",
				["type"] = "aura",
				["unevent"] = "auto",
				["use_unit"] = true,
				["unit"] = "pet",
				["event"] = "Health",
				["buffShowOn"] = "showOnActive",
				["use_name"] = true,
				["ownOnly"] = true,
				["spellIds"] = {
				},
				["names"] = {
					"狂暴", -- [1]
				},
				["remOperator"] = ">=",
				["autoclone"] = true,
				["subeventSuffix"] = "_CAST_START",
				["useRem"] = true,
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 0,
			["text1Point"] = "TOPLEFT",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["internalVersion"] = 6,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["untrigger"] = {
			},
			["text2Containment"] = "INSIDE",
			["stickyDuration"] = false,
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["inverse"] = false,
			["text1FontFlags"] = "OUTLINE",
			["regionType"] = "icon",
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["text2Font"] = "Friz Quadrata TT",
			["text2FontSize"] = 24,
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["text1"] = "%p",
			["cooldownTextEnabled"] = true,
			["text2"] = "%p",
			["zoom"] = 0,
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "倒刺射击",
			["glow"] = false,
			["frameStrata"] = 1,
			["width"] = 32,
			["text1Font"] = "Friz Quadrata TT",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["numTriggers"] = 1,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["parent"] = "buff",
		},
		["多重射击"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -75,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "多重射击",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 2643,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
				["spellName"] = 2643,
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "多重射击",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["敌人血量"] = {
			["sparkWidth"] = 10,
			["stacksSize"] = 12,
			["xOffset"] = -50,
			["stacksFlags"] = "None",
			["yOffset"] = -518,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["rotateText"] = "NONE",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["barColor"] = {
				0.92156862745098, -- [1]
				0.211764705882353, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["load"] = {
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["timerColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["stacks"] = false,
			["texture"] = "Blizzard",
			["textFont"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["spark"] = false,
			["timerFont"] = "Friz Quadrata TT",
			["alpha"] = 1,
			["borderInset"] = 11,
			["textColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["parent"] = "buff",
			["untrigger"] = {
			},
			["activeTriggerMode"] = -10,
			["sparkRotationMode"] = "AUTO",
			["textSize"] = 12,
			["internalVersion"] = 6,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["backdropInFront"] = false,
			["text"] = false,
			["stickyDuration"] = false,
			["displayTextLeft"] = "%n",
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["timer"] = false,
			["timerFlags"] = "None",
			["borderOffset"] = 5,
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["orientation"] = "HORIZONTAL",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["numTriggers"] = 1,
			["trigger"] = {
				["type"] = "custom",
				["subeventSuffix"] = "_CAST_START",
				["custom_hide"] = "timed",
				["debuffType"] = "HELPFUL",
				["event"] = "Health",
				["subeventPrefix"] = "SPELL",
				["customDuration"] = "function() \n    return 1\nend",
				["unit"] = "player",
				["custom"] = "function() \n    local curhp = 0 \n    local maxhp = 1\n    for i = 1, 40 do \n        local unit = \"nameplate\"..i \n        if UnitCanAttack(\"player\", unit) \n        and WeakAuras.CheckRange(unit, 40, \"<=\") \n        then \n            curhp = curhp + UnitHealth(unit) \n            maxhp = maxhp + UnitHealthMax(unit)\n        end \n    end \n    return  curhp > 800000\nend",
				["names"] = {
				},
				["check"] = "update",
				["spellIds"] = {
				},
				["custom_type"] = "status",
				["buffShowOn"] = "showOnActive",
			},
			["borderSize"] = 16,
			["border"] = false,
			["borderEdge"] = "None",
			["anchorFrameType"] = "SCREEN",
			["borderInFront"] = true,
			["auto"] = true,
			["icon_side"] = "RIGHT",
			["icon"] = false,
			["id"] = "敌人血量",
			["sparkHeight"] = 30,
			["customTextUpdate"] = "update",
			["displayTextRight"] = "%p",
			["stacksColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["timerSize"] = 12,
			["sparkRotation"] = 0,
			["sparkHidden"] = "NEVER",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.5, -- [4]
			},
			["frameStrata"] = 1,
			["width"] = 100,
			["sparkOffsetX"] = 0,
			["textFlags"] = "None",
			["inverse"] = false,
			["height"] = 10,
			["init_started"] = 1,
			["conditions"] = {
			},
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["stacksFont"] = "Friz Quadrata TT",
		},
		["狂野怒火"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -275,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "狂野怒火",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 19574,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "狂野怒火",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["眼镜蛇射击"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -195,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "眼镜蛇射击",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 193455,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
				["spellName"] = 193455,
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "眼镜蛇射击",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["治疗宠物"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -350,
			["yOffset"] = -435,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "治疗宠物",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 136,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["single"] = 6,
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["use_talent"] = true,
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
				["spellName"] = 136,
			},
			["text1Color"] = {
				1, -- [1]
				0.83921568627451, -- [2]
				0.286274509803922, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "治疗宠物",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["杀戮命令"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -235,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["unevent"] = "auto",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["unit"] = "player",
				["realSpellName"] = "杀戮命令",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["subeventPrefix"] = "SPELL",
				["names"] = {
				},
				["subeventSuffix"] = "_CAST_START",
				["spellName"] = 34026,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "杀戮命令",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["狂暴断档"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -275,
			["yOffset"] = -510,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = false,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["type"] = "aura",
				["subeventSuffix"] = "_CAST_START",
				["ownOnly"] = true,
				["event"] = "Health",
				["use_specific_unit"] = false,
				["buffShowOn"] = "showOnActive",
				["subeventPrefix"] = "SPELL",
				["spellIds"] = {
				},
				["rem"] = "0",
				["remOperator"] = "<=",
				["names"] = {
					"狂暴", -- [1]
				},
				["unit"] = "pet",
				["debuffType"] = "HELPFUL",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 0,
			["text1Point"] = "TOPLEFT",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["parent"] = "buff",
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["desaturate"] = false,
			["displayIcon"] = 801007,
			["stickyDuration"] = false,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
			},
			["text1Color"] = {
				1, -- [1]
				0.725490196078431, -- [2]
				0.258823529411765, -- [3]
				1, -- [4]
			},
			["numTriggers"] = 1,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["text1FontFlags"] = "OUTLINE",
			["regionType"] = "icon",
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["width"] = 32,
			["text2FontSize"] = 24,
			["frameStrata"] = 1,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["text2"] = "%p",
			["zoom"] = 0,
			["auto"] = false,
			["text2Enabled"] = false,
			["id"] = "狂暴断档",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["internalVersion"] = 6,
		},
		["自己集中值"] = {
			["sparkWidth"] = 10,
			["stacksSize"] = 12,
			["xOffset"] = -155,
			["stacksFlags"] = "None",
			["yOffset"] = -500.999706268311,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["rotateText"] = "NONE",
			["backgroundColor"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["selfPoint"] = "CENTER",
			["barColor"] = {
				1, -- [1]
				1, -- [2]
				0, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["timerColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["stacks"] = false,
			["texture"] = "Blizzard",
			["textFont"] = "Friz Quadrata TT",
			["borderOffset"] = 5,
			["auto"] = true,
			["timerFont"] = "Friz Quadrata TT",
			["alpha"] = 1,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["textColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["parent"] = "buff",
			["untrigger"] = {
			},
			["activeTriggerMode"] = -10,
			["sparkRotationMode"] = "AUTO",
			["displayTextLeft"] = "%n",
			["internalVersion"] = 6,
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["backdropInFront"] = false,
			["text"] = false,
			["stickyDuration"] = false,
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["trigger"] = {
				["type"] = "status",
				["unevent"] = "auto",
				["event"] = "Power",
				["unit"] = "player",
				["names"] = {
				},
				["powertype"] = 2,
				["spellIds"] = {
				},
				["subeventPrefix"] = "SPELL",
				["subeventSuffix"] = "_CAST_START",
				["use_unit"] = true,
				["use_powertype"] = true,
				["debuffType"] = "HELPFUL",
			},
			["timer"] = false,
			["timerFlags"] = "None",
			["textFlags"] = "None",
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["init_started"] = 1,
			["sparkOffsetX"] = 0,
			["numTriggers"] = 1,
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["height"] = 10,
			["border"] = false,
			["borderEdge"] = "None",
			["anchorFrameType"] = "SCREEN",
			["borderSize"] = 16,
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["icon_side"] = "RIGHT",
			["sparkRotation"] = 0,
			["id"] = "自己集中值",
			["sparkHeight"] = 30,
			["customTextUpdate"] = "update",
			["timerSize"] = 12,
			["stacksColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["displayTextRight"] = "%p",
			["textSize"] = 12,
			["sparkHidden"] = "NEVER",
			["borderInset"] = 11,
			["frameStrata"] = 1,
			["width"] = 100,
			["borderInFront"] = true,
			["icon"] = false,
			["inverse"] = false,
			["zoom"] = 0,
			["orientation"] = "HORIZONTAL",
			["conditions"] = {
			},
			["spark"] = false,
			["stacksFont"] = "Friz Quadrata TT",
		},
		["野性守护"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -315,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "野性守护",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 193530,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "野性守护",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["奇美拉射击"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -155,
			["yOffset"] = -475,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["debuffType"] = "HELPFUL",
				["type"] = "status",
				["genericShowOn"] = "showAlways",
				["subeventSuffix"] = "_CAST_START",
				["use_showgcd"] = true,
				["use_genericShowOn"] = true,
				["event"] = "Cooldown Progress (Spell)",
				["subeventPrefix"] = "SPELL",
				["realSpellName"] = "奇美拉射击",
				["use_spellName"] = true,
				["spellIds"] = {
				},
				["names"] = {
				},
				["unit"] = "player",
				["unevent"] = "auto",
				["spellName"] = 53209,
				["buffShowOn"] = "showOnCooldown",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 1,
			["text1Point"] = "CENTER",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["size"] = {
					["multi"] = {
					},
				},
				["talent"] = {
					["single"] = 6,
					["multi"] = {
					},
				},
				["use_spec"] = true,
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["use_talent"] = true,
			},
			["parent"] = "buff",
			["stickyDuration"] = false,
			["internalVersion"] = 6,
			["text2Containment"] = "INSIDE",
			["untrigger"] = {
				["genericShowOn"] = "showAlways",
			},
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["text1FontFlags"] = "OUTLINE",
			["numTriggers"] = 1,
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["regionType"] = "icon",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["main"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
				["finish"] = {
					["type"] = "none",
					["duration_type"] = "seconds",
				},
			},
			["actions"] = {
				["start"] = {
				},
				["init"] = {
				},
				["finish"] = {
				},
			},
			["text2FontSize"] = 24,
			["width"] = 32,
			["frameStrata"] = 1,
			["text1"] = "%p",
			["text1Font"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["text2"] = "%p",
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "奇美拉射击",
			["glow"] = false,
			["alpha"] = 1,
			["anchorFrameType"] = "SCREEN",
			["cooldownTextEnabled"] = true,
			["text2Font"] = "Friz Quadrata TT",
			["inverse"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["desaturate"] = false,
		},
		["野兽顺劈"] = {
			["text2Point"] = "CENTER",
			["text1FontSize"] = 15,
			["xOffset"] = -315,
			["yOffset"] = -509.999418258667,
			["anchorPoint"] = "CENTER",
			["activeTriggerMode"] = -10,
			["customTextUpdate"] = "update",
			["icon"] = true,
			["text1Enabled"] = true,
			["keepAspectRatio"] = false,
			["selfPoint"] = "CENTER",
			["trigger"] = {
				["type"] = "aura",
				["subeventSuffix"] = "_CAST_START",
				["ownOnly"] = true,
				["event"] = "Health",
				["subeventPrefix"] = "SPELL",
				["debuffType"] = "HELPFUL",
				["rem"] = "1",
				["spellIds"] = {
					268877, -- [1]
				},
				["useRem"] = true,
				["remOperator"] = ">=",
				["unit"] = "player",
				["names"] = {
					"野兽顺劈", -- [1]
				},
				["buffShowOn"] = "showOnActive",
			},
			["text1Containment"] = "INSIDE",
			["progressPrecision"] = 0,
			["text1Point"] = "TOPLEFT",
			["text2FontFlags"] = "OUTLINE",
			["height"] = 32,
			["load"] = {
				["use_class"] = true,
				["use_spec"] = true,
				["spec"] = {
					["single"] = 1,
					["multi"] = {
					},
				},
				["class"] = {
					["single"] = "HUNTER",
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["stickyDuration"] = false,
			["parent"] = "buff",
			["desaturate"] = false,
			["text2Containment"] = "INSIDE",
			["internalVersion"] = 6,
			["text1Color"] = {
				0.929411764705882, -- [1]
				0.709803921568628, -- [2]
				0.223529411764706, -- [3]
				1, -- [4]
			},
			["untrigger"] = {
			},
			["inverse"] = false,
			["text1FontFlags"] = "OUTLINE",
			["regionType"] = "icon",
			["text2Color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["text2Font"] = "Friz Quadrata TT",
			["text2FontSize"] = 24,
			["anchorFrameType"] = "SCREEN",
			["alpha"] = 1,
			["text1"] = "%p",
			["cooldownTextEnabled"] = true,
			["text2"] = "%p",
			["zoom"] = 0,
			["auto"] = true,
			["text2Enabled"] = false,
			["id"] = "野兽顺劈",
			["glow"] = false,
			["frameStrata"] = 1,
			["width"] = 32,
			["text1Font"] = "Friz Quadrata TT",
			["actions"] = {
				["start"] = {
				},
				["finish"] = {
				},
				["init"] = {
				},
			},
			["numTriggers"] = 1,
			["animation"] = {
				["start"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["init_started"] = 1,
			["conditions"] = {
			},
			["cooldown"] = false,
			["color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
		},
		["检测敌人个数"] = {
			["sparkWidth"] = 10,
			["stacksSize"] = 12,
			["xOffset"] = -100,
			["stacksFlags"] = "None",
			["yOffset"] = -501,
			["anchorPoint"] = "CENTER",
			["borderColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["rotateText"] = "NONE",
			["actions"] = {
				["start"] = {
					["do_custom"] = false,
				},
				["finish"] = {
				},
				["init"] = {
					["do_custom"] = false,
				},
			},
			["icon_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["useTooltip"] = false,
			["selfPoint"] = "LEFT",
			["barColor"] = {
				1, -- [1]
				0, -- [2]
				0.596078431372549, -- [3]
				1, -- [4]
			},
			["desaturate"] = false,
			["sparkOffsetY"] = 0,
			["load"] = {
				["spec"] = {
					["multi"] = {
					},
				},
				["class"] = {
					["multi"] = {
					},
				},
				["size"] = {
					["multi"] = {
					},
				},
			},
			["timerColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["smoothProgress"] = false,
			["useAdjustededMin"] = false,
			["regionType"] = "aurabar",
			["stacks"] = false,
			["texture"] = "Flat",
			["textFont"] = "Friz Quadrata TT",
			["zoom"] = 0,
			["spark"] = false,
			["timerFont"] = "Friz Quadrata TT",
			["alpha"] = 1,
			["borderInset"] = 11,
			["textColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["borderBackdrop"] = "Blizzard Tooltip",
			["parent"] = "buff",
			["adjustedMin"] = 0,
			["untrigger"] = {
			},
			["activeTriggerMode"] = 0,
			["sparkRotationMode"] = "AUTO",
			["textSize"] = 12,
			["internalVersion"] = 6,
			["displayTextLeft"] = "%n",
			["animation"] = {
				["start"] = {
					["type"] = "none",
					["preset"] = "grow",
					["duration_type"] = "seconds",
					["use_translate"] = false,
					["translateType"] = "custom",
				},
				["main"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
				["finish"] = {
					["duration_type"] = "seconds",
					["type"] = "none",
				},
			},
			["backdropInFront"] = false,
			["text"] = false,
			["adjustedMax"] = 3,
			["stickyDuration"] = false,
			["borderOffset"] = 5,
			["orientation"] = "HORIZONTAL",
			["trigger"] = {
				["type"] = "custom",
				["debuffType"] = "HELPFUL",
				["custom_type"] = "status",
				["buffShowOn"] = "showOnActive",
				["customOverlay1"] = "\n\n",
				["event"] = "Health",
				["names"] = {
				},
				["customDuration"] = "function() \n    return 1 -- change as needed \nend",
				["spellIds"] = {
				},
				["custom"] = "function() \n    \n    if UnitIsDead(\"target\")\n    then\n        return false\n    end\n    \n    if not UnitCanAttack(\"player\", \"target\") \n    then\n        return false\n    end\n    \n    local count = 0 \n    for i = 1, 40 do \n        local unit = \"nameplate\"..i \n        if UnitCanAttack(\"player\", unit) \n        and WeakAuras.CheckRange(unit, 40, \"<=\")   \n        then \n            return true\n        end \n    end\n    return false\nend\n\n\n\n\n\n",
				["unit"] = "player",
				["check"] = "update",
				["subeventPrefix"] = "SPELL",
				["subeventSuffix"] = "_CAST_START",
				["custom_hide"] = "timed",
			},
			["numTriggers"] = 3,
			["timer"] = false,
			["timerFlags"] = "None",
			["backdropColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["sparkBlendMode"] = "ADD",
			["useAdjustededMax"] = false,
			["height"] = 10,
			["anchorFrameType"] = "SCREEN",
			["icon"] = false,
			["customTextUpdate"] = "update",
			["id"] = "检测敌人个数",
			["border"] = false,
			["borderEdge"] = "None",
			["borderSize"] = 16,
			["borderInFront"] = true,
			["displayTextRight"] = "%p",
			["icon_side"] = "RIGHT",
			["auto"] = false,
			["sparkRotation"] = 0,
			["sparkHeight"] = 30,
			["backgroundColor"] = {
				1, -- [1]
				0, -- [2]
				0.619607843137255, -- [3]
				1, -- [4]
			},
			["sparkHidden"] = "NEVER",
			["stacksColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["timerSize"] = 12,
			["sparkOffsetX"] = 0,
			["additional_triggers"] = {
				{
					["trigger"] = {
						["type"] = "custom",
						["custom"] = "function() \n    if UnitIsDead(\"target\")\n    then\n        return false\n    end\n    \n    if not UnitCanAttack(\"player\", \"target\") \n    then\n        return false\n    end\n    \n    local count = 0 \n    for i = 1, 40 do \n        local unit = \"nameplate\"..i \n        if UnitCanAttack(\"player\", unit) \n        and WeakAuras.CheckRange(unit, 40, \"<=\")   \n        then \n            count = count + 1 \n        end \n        if count >= 2\n        then\n            return true\n        end\n    end \n    return count >= 2 -- change as needed \nend",
						["subeventSuffix"] = "_CAST_START",
						["check"] = "update",
						["custom_type"] = "status",
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
					},
					["untrigger"] = {
					},
				}, -- [1]
				{
					["trigger"] = {
						["type"] = "custom",
						["unevent"] = "auto",
						["use_absorbMode"] = true,
						["event"] = "Health",
						["subeventPrefix"] = "SPELL",
						["custom"] = "function() \n    \n    if UnitIsDead(\"target\")\n    then\n        return false\n    end\n    \n    if not UnitCanAttack(\"player\", \"target\") \n    then\n        return false\n    end\n    \n    local count = 0 \n    for i = 1, 40 do \n        local unit = \"nameplate\"..i \n        if UnitCanAttack(\"player\", unit) \n        and WeakAuras.CheckRange(unit, 40, \"<=\") \n        then \n            count = count + 1 \n        end \n        if count >= 3\n        then\n            return true\n        end\n    end \n    return count >= 3 -- change as needed \nend",
						["subeventSuffix"] = "_CAST_START",
						["check"] = "update",
						["use_unit"] = true,
						["unit"] = "player",
						["custom_type"] = "status",
					},
					["untrigger"] = {
					},
				}, -- [2]
			},
			["textFlags"] = "None",
			["frameStrata"] = 1,
			["width"] = 20,
			["sparkColor"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["sparkTexture"] = "Interface\\CastingBar\\UI-CastingBar-Spark",
			["inverse"] = false,
			["stacksFont"] = "Friz Quadrata TT",
			["init_started"] = 1,
			["conditions"] = {
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = 50,
							["property"] = "width",
						}, -- [1]
					},
				}, -- [1]
				{
					["check"] = {
						["trigger"] = 2,
						["variable"] = "show",
						["value"] = 1,
					},
					["changes"] = {
						{
							["value"] = 100,
							["property"] = "width",
						}, -- [1]
					},
				}, -- [2]
				{
					["check"] = {
						["trigger"] = 1,
						["variable"] = "show",
						["value"] = 0,
					},
					["changes"] = {
						{
							["value"] = 20,
							["property"] = "width",
						}, -- [1]
					},
				}, -- [3]
			},
			["disjunctive"] = "any",
			["customTriggerLogic"] = "function() \n    local count = 0 \n    for i = 1, 40 do \n        local unit = \"nameplate\"..i \n        if UnitCanAttack(\"player\", unit) \n        and WeakAuras.CheckRange(unit, 40, \"<=\")   \n        then \n            count = count + 1 \n        end \n    end \n    return 5\nend",
		},
	},
	["frame"] = {
		["xOffset"] = -1101.99975585938,
		["yOffset"] = -344.998474121094,
		["height"] = 476.000122070313,
		["width"] = 622.000183105469,
	},
	["editor_theme"] = "Monokai",
}
