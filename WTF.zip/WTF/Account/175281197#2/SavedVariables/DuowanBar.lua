
DuowanBarDB = {
	["金色平原_乐乐创想"] = {
		["hideTab"] = true,
		["DuowanActionBar1"] = {
			["minimized"] = false,
			["scale"] = 1,
			["count"] = 10,
			["region"] = {
				"TOPLEFT", -- [1]
				"BOTTOMLEFT", -- [2]
				1714.54541015625, -- [3]
				251.161819458008, -- [4]
			},
			["locked"] = true,
			["_buttons"] = {
			},
			["arrange"] = 3,
			["close"] = false,
		},
		["DuowanActionBar2"] = {
			["close"] = true,
		},
	},
	["迦拉克隆_落晖沉梦"] = {
		["hideTab"] = true,
		["DuowanActionBar1"] = {
			["close"] = true,
		},
	},
	["金色平原_翻墙头"] = {
		["hideTab"] = true,
	},
	["金色平原_Qweradf"] = {
		["hideTab"] = true,
	},
}
