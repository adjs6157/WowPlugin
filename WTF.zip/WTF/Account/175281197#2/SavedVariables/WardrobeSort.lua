
WardrobeSortDB = {
	["sortDropdown"] = 1,
	["reverse"] = false,
	["db_version"] = 2,
}
