
IskarAssistDB = {
	["profileKeys"] = {
		["落晖沉梦 - 迦拉克隆"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
