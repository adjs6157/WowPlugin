
LearningAid_Saved = {
	["enabled"] = false,
	["dataVersion"] = 1,
	["totem"] = true,
	["debugFlags"] = {
	},
	["shapeshift"] = false,
	["ignore"] = {
		["HUNTER"] = {
		},
		["WARRIOR"] = {
		},
		["WARLOCK"] = {
			[712] = true,
			[30146] = true,
			[688] = true,
			[697] = true,
			[18540] = true,
			[1122] = true,
			[691] = true,
			[61610] = true,
		},
		["profession"] = {
			[83968] = true,
			[83958] = true,
			[72423] = true,
			[83967] = true,
			[72429] = true,
		},
		["race"] = {
		},
		["guild"] = {
		},
	},
	["version"] = "1.13a1",
	["locked"] = false,
	["macros"] = false,
	["autoAttack"] = false,
	["tracking"] = false,
	["restoreActions"] = false,
}
