
EA_Config = {
	["SCD_NocombatStillKeep"] = true,
	["ShowTimer"] = true,
	["DoAlertSound"] = true,
	["ChangeTimer"] = true,
	["SpecPowerCheck"] = {
		["DarkForce"] = false,
		["Mana"] = false,
		["BurningEmbers"] = false,
		["LifeBloom"] = false,
		["Focus"] = false,
		["RunicPower"] = false,
		["Runes"] = false,
		["LunarPower"] = false,
		["LightForce"] = false,
		["Fury"] = false,
		["SoulShards"] = false,
		["ComboPoint"] = false,
		["DemonicFury"] = false,
		["Energy"] = false,
		["Maelstrom"] = false,
		["Insanity"] = false,
		["Rage"] = false,
		["HolyPower"] = false,
		["ArcaneCharges"] = false,
		["Pain"] = false,
	},
	["ICON_APPEND_SPELL_TIP"] = true,
	["ShareSettings"] = true,
	["IconSize"] = 45,
	["ShowAuraValueWhenOver"] = 1000,
	["AllowESC"] = false,
	["ShowFlash"] = false,
	["SNameFontSize"] = 13.5,
	["ShowFrame"] = true,
	["LockFrame"] = false,
	["TimerFontSize"] = 18,
	["HUNTER_GlowPetFocus"] = 50,
	["Target_MyDebuff"] = true,
	["AllowAltAlerts"] = false,
	["AlertSoundValue"] = 1,
	["StackFontSize"] = 13.5,
	["ShowName"] = true,
	["Version"] = "7.0.3.20160822",
	["UseFloatSec"] = 1,
	["AlertSound"] = "Sound\\Spells\\ShaysBell.ogg",
	["OPTION_ICON"] = true,
	["SCD_RemoveWhenCooldown"] = true,
	["SCD_GlowWhenUsable"] = true,
}
EA_Position = {
	["Execution"] = 0,
	["GreenDebuff"] = 0.5,
	["xOffset"] = -40,
	["TarAnchor"] = "CENTER",
	["yOffset"] = 0,
	["PlayerLv2BOSS"] = true,
	["relativePoint"] = "CENTER",
	["Anchor"] = "CENTER",
	["yLoc"] = -140,
	["SCD_UseCooldown"] = false,
	["Tar_yOffset"] = -220,
	["RedDebuff"] = 0.5,
	["Tar_xOffset"] = 0,
	["Scd_yOffset"] = 80,
	["TarrelativePoint"] = "CENTER",
	["Scd_xOffset"] = 0,
	["ScdAnchor"] = "CENTER",
	["Tar_NewLine"] = true,
	["xLoc"] = 0,
}
EA_Items = {
	["HUNTER"] = {
		[95712] = {
			["enable"] = false,
		},
		[34477] = {
			["enable"] = false,
		},
		[246851] = {
			["self"] = true,
			["orderwtd"] = 3,
			["name"] = "倒刺射击",
			["enable"] = true,
		},
		[118455] = {
			["enable"] = false,
		},
		[193530] = {
			["enable"] = false,
		},
		[35079] = {
			["enable"] = false,
		},
		[70728] = {
			["enable"] = false,
		},
		[186265] = {
			["enable"] = false,
		},
		[61684] = {
			["enable"] = false,
		},
		[186254] = {
			["enable"] = false,
		},
		[185791] = {
			["enable"] = false,
		},
		[268877] = {
			["self"] = true,
			["orderwtd"] = 1,
			["name"] = "野兽顺劈",
			["enable"] = true,
		},
		[186257] = {
			["enable"] = false,
		},
		[246152] = {
			["self"] = true,
			["orderwtd"] = 3,
			["name"] = "倒刺射击",
			["enable"] = true,
		},
	},
	["WARRIOR"] = {
		[215572] = {
			["enable"] = true,
			["self"] = true,
		},
		[85288] = {
			["self"] = true,
			["overgrow"] = 2,
			["name"] = "怒击",
			["enable"] = true,
		},
		[46924] = {
			["enable"] = true,
			["self"] = true,
		},
		[60503] = {
			["enable"] = true,
		},
		[2565] = {
			["enable"] = true,
		},
		[207982] = {
			["enable"] = true,
			["overgrow"] = 3,
			["self"] = true,
		},
		[184364] = {
			["enable"] = true,
			["self"] = true,
		},
		[871] = {
			["enable"] = true,
			["self"] = true,
		},
		[107574] = {
			["enable"] = true,
			["self"] = true,
		},
		[12975] = {
			["enable"] = true,
		},
		[23920] = {
			["enable"] = true,
			["self"] = true,
		},
		[280776] = {
			["self"] = true,
			["overgrow"] = 1,
			["name"] = "猝死",
			["enable"] = true,
		},
		[206333] = {
			["enable"] = true,
			["overgrow"] = 6,
			["self"] = true,
		},
		[23881] = {
			["self"] = true,
			["overgrow"] = 1,
			["name"] = "嗜血",
			["enable"] = true,
		},
		[184362] = {
			["enable"] = true,
			["self"] = true,
		},
		[188923] = {
			["enable"] = true,
			["overgrow"] = 2,
			["self"] = true,
		},
		[32216] = {
			["enable"] = true,
		},
		[202164] = {
			["enable"] = true,
			["self"] = true,
		},
		[85739] = {
			["enable"] = true,
			["self"] = true,
		},
		[118038] = {
			["enable"] = true,
			["self"] = true,
		},
		[202539] = {
			["enable"] = true,
			["overgrow"] = 3,
			["self"] = true,
		},
	},
	["OTHER"] = {
		[47788] = {
			["enable"] = true,
			["name"] = "守護聖靈",
			["self"] = false,
		},
		[64901] = {
			["enable"] = true,
			["name"] = "希望象徵",
		},
		[228600] = {
			["enable"] = true,
			["self"] = false,
		},
		[29166] = {
			["enable"] = true,
		},
		[5211] = {
			["enable"] = true,
			["self"] = false,
		},
		[102342] = {
			["enable"] = true,
			["name"] = "鐵樹皮術",
		},
		[1022] = {
			["enable"] = true,
			["name"] = "保護祝福",
			["self"] = false,
		},
		[127797] = {
			["enable"] = true,
			["self"] = false,
		},
		[53563] = {
			["enable"] = true,
			["name"] = "聖光信標",
		},
		[33786] = {
			["enable"] = true,
			["self"] = false,
		},
		[28271] = {
			["enable"] = true,
			["self"] = false,
		},
		[2825] = {
			["enable"] = true,
			["name"] = "嗜血",
		},
		[10060] = {
			["enable"] = true,
		},
		[64844] = {
			["enable"] = true,
			["name"] = "神聖禮頌",
		},
		[81782] = {
			["enable"] = true,
		},
		[163505] = {
			["enable"] = true,
			["self"] = false,
		},
		[33206] = {
			["enable"] = true,
		},
		[48707] = {
			["enable"] = true,
			["self"] = false,
		},
		[32182] = {
			["enable"] = true,
		},
		[82691] = {
			["enable"] = true,
			["self"] = false,
		},
		[98007] = {
			["enable"] = true,
		},
		[159234] = {
			["enable"] = true,
			["self"] = true,
		},
		[146555] = {
			["enable"] = true,
			["name"] = "憤怒之鼓",
			["self"] = false,
		},
		[90355] = {
			["enable"] = true,
		},
		[80353] = {
			["enable"] = true,
		},
		[186265] = {
			["enable"] = true,
			["self"] = false,
		},
		[45438] = {
			["enable"] = true,
			["self"] = false,
		},
		[1850] = {
			["enable"] = true,
			["name"] = "突進",
			["self"] = false,
		},
		[6940] = {
			["enable"] = true,
			["name"] = "犧牲祝福",
			["self"] = false,
		},
	},
}
EA_AltItems = {
	["HUNTER"] = {
	},
	["WARRIOR"] = {
	},
}
EA_TarItems = {
	["HUNTER"] = {
		[5116] = {
			["enable"] = true,
			["self"] = true,
		},
		[126958] = {
			["enable"] = true,
			["self"] = false,
		},
		[123059] = {
			["enable"] = true,
			["self"] = false,
		},
		[117405] = {
			["enable"] = true,
			["self"] = false,
		},
		[132951] = {
			["enable"] = true,
			["self"] = false,
		},
		[117737] = {
			["enable"] = true,
			["self"] = false,
		},
		[132726] = {
			["enable"] = true,
			["self"] = false,
		},
		[136431] = {
			["enable"] = true,
			["self"] = false,
		},
		[63468] = {
			["enable"] = true,
			["self"] = true,
		},
		[123471] = {
			["enable"] = true,
			["self"] = false,
		},
		[127372] = {
			["enable"] = true,
			["self"] = false,
		},
		[131894] = {
			["enable"] = true,
			["self"] = false,
		},
		[54680] = {
			["enable"] = true,
			["self"] = true,
		},
		[131996] = {
			["enable"] = true,
			["self"] = false,
		},
		[117756] = {
			["enable"] = true,
			["self"] = false,
		},
		[1130] = {
			["enable"] = true,
			["self"] = true,
		},
	},
	["WARRIOR"] = {
		[131996] = {
			["enable"] = true,
			["self"] = false,
		},
		[772] = {
			["enable"] = true,
			["self"] = true,
		},
		[46924] = {
			["enable"] = true,
			["self"] = false,
		},
		[5246] = {
			["enable"] = true,
			["self"] = false,
		},
		[126958] = {
			["enable"] = true,
			["self"] = false,
		},
		[115804] = {
			["enable"] = true,
			["self"] = true,
		},
		[118038] = {
			["enable"] = true,
			["self"] = false,
		},
		[132168] = {
			["enable"] = true,
			["self"] = false,
		},
		[12323] = {
			["enable"] = true,
			["self"] = true,
		},
		[136431] = {
			["enable"] = true,
			["self"] = false,
		},
		[208086] = {
			["enable"] = true,
			["self"] = true,
		},
		[12975] = {
			["enable"] = true,
			["self"] = false,
		},
		[113344] = {
			["enable"] = true,
			["self"] = true,
		},
		[23920] = {
			["enable"] = true,
			["self"] = false,
		},
		[215537] = {
			["enable"] = true,
			["self"] = true,
		},
		[147833] = {
			["enable"] = true,
			["self"] = true,
		},
		[132726] = {
			["enable"] = true,
			["self"] = false,
		},
		[117756] = {
			["enable"] = true,
			["self"] = false,
		},
		[123059] = {
			["enable"] = true,
			["self"] = false,
		},
		[132169] = {
			["enable"] = true,
			["self"] = false,
		},
		[127372] = {
			["enable"] = true,
			["self"] = false,
		},
		[1715] = {
			["enable"] = true,
			["self"] = true,
		},
		[123471] = {
			["enable"] = true,
			["self"] = false,
		},
		[117737] = {
			["enable"] = true,
			["self"] = false,
		},
		[871] = {
			["enable"] = true,
			["self"] = false,
		},
	},
}
EA_ScdItems = {
	["HUNTER"] = {
		[16827] = {
			["enable"] = false,
		},
		[217200] = {
			["enable"] = false,
		},
		[54644] = {
			["enable"] = false,
		},
		[19574] = {
			["enable"] = false,
		},
		[54680] = {
			["enable"] = false,
		},
		[90361] = {
			["enable"] = false,
		},
		[109304] = {
			["enable"] = false,
		},
		[92380] = {
			["enable"] = false,
		},
		[55709] = {
			["enable"] = false,
		},
		[109248] = {
			["enable"] = false,
		},
		[160065] = {
			["enable"] = false,
		},
		[781] = {
			["enable"] = false,
		},
		[131894] = {
			["enable"] = false,
		},
		[193530] = {
			["enable"] = false,
		},
		[186257] = {
			["enable"] = false,
		},
		[147362] = {
			["enable"] = false,
		},
		[61684] = {
			["enable"] = false,
		},
		[17253] = {
			["enable"] = false,
		},
	},
	["WARRIOR"] = {
		[12294] = {
			["enable"] = false,
		},
		[34428] = {
			["enable"] = false,
		},
		[1719] = {
			["enable"] = false,
		},
		[1160] = {
			["enable"] = false,
		},
		[6544] = {
			["enable"] = false,
		},
		[118000] = {
			["enable"] = false,
			["name"] = "巨龙怒吼",
		},
		[228920] = {
			["enable"] = false,
		},
		[46924] = {
			["enable"] = false,
		},
		[107570] = {
			["enable"] = false,
		},
		[107574] = {
			["enable"] = false,
		},
		[2565] = {
			["enable"] = false,
		},
		[85288] = {
			["enable"] = false,
		},
		[207982] = {
			["enable"] = false,
		},
		[18499] = {
			["enable"] = false,
		},
		[198304] = {
			["enable"] = false,
		},
		[23920] = {
			["enable"] = false,
		},
		[23922] = {
			["enable"] = false,
		},
		[46968] = {
			["enable"] = false,
		},
		[100] = {
			["enable"] = false,
		},
		[167105] = {
			["enable"] = false,
		},
		[845] = {
			["enable"] = false,
		},
		[152277] = {
			["enable"] = false,
		},
		[118038] = {
			["enable"] = false,
		},
		[23881] = {
			["enable"] = false,
		},
		[184367] = {
			["enable"] = false,
		},
		[871] = {
			["enable"] = false,
		},
		[5308] = {
			["enable"] = false,
		},
		[163201] = {
			["enable"] = false,
		},
		[6572] = {
			["enable"] = false,
		},
		[12292] = {
			["enable"] = false,
		},
		[6552] = {
			["enable"] = false,
		},
		[202168] = {
			["enable"] = false,
		},
		[6343] = {
			["enable"] = false,
		},
		[12975] = {
			["enable"] = false,
		},
	},
}
EA_GrpItems = {
	["HUNTER"] = {
	},
	["WARRIOR"] = {
	},
}
EA_Pos = {
	["DEATHKNIGHT"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["WARRIOR"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["PALADIN"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["MAGE"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["PRIEST"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["SHAMAN"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["WARLOCK"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["DEMONHUNTER"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["HUNTER"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["DRUID"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["MONK"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
	["ROGUE"] = {
		["Execution"] = 0,
		["GreenDebuff"] = 0.5,
		["xOffset"] = -40,
		["TarAnchor"] = "CENTER",
		["yOffset"] = 0,
		["PlayerLv2BOSS"] = true,
		["relativePoint"] = "CENTER",
		["Anchor"] = "CENTER",
		["yLoc"] = -140,
		["SCD_UseCooldown"] = false,
		["Tar_yOffset"] = -220,
		["RedDebuff"] = 0.5,
		["Tar_xOffset"] = 0,
		["Scd_yOffset"] = 80,
		["TarrelativePoint"] = "CENTER",
		["Scd_xOffset"] = 0,
		["ScdAnchor"] = "CENTER",
		["Tar_NewLine"] = true,
		["xLoc"] = 0,
	},
}
