
HandyNotes_BattleForAzerothTreasuresDB = {
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Qweradf - 金色平原",
		["落晖沉梦 - 迦拉克隆"] = "落晖沉梦 - 迦拉克隆",
		["乐乐创想 - 金色平原"] = "乐乐创想 - 金色平原",
		["翻墙头 - 金色平原"] = "翻墙头 - 金色平原",
	},
	["profiles"] = {
		["Qweradf - 金色平原"] = {
		},
		["落晖沉梦 - 迦拉克隆"] = {
		},
		["乐乐创想 - 金色平原"] = {
		},
		["翻墙头 - 金色平原"] = {
		},
	},
}
