
_NPCScanOptions = {
	["NPCs"] = {
		[64004] = "幽灵熊猫人渔夫",
		[50410] = "神秘的骆驼雕像",
		[50409] = "神秘的骆驼雕像",
		[64191] = "幽灵熊猫人木匠",
	},
	["Version"] = 3,
	["NPCWorldIDs"] = {
		[64004] = "潘达利亚",
		[50410] = "卡利姆多",
		[50409] = "卡利姆多",
		[64191] = "潘达利亚",
	},
	["IgnoreList"] = {
		["NPCs"] = {
		},
		["MapName"] = {
		},
		["WorldID"] = {
		},
	},
	["ChangeAlertShown"] = true,
}
_NPCScanProfiles = {
	["profileKeys"] = {
		["落晖沉梦 - 迦拉克隆"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["EnableScan"] = true,
		},
	},
}
