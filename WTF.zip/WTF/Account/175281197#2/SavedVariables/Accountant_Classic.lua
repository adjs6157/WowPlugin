
Accountant_SaveData = nil
Accountant_ClassicSaveData = {
	["金色平原"] = {
		["Qweradf"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "07/10/18",
				["class"] = "HUNTER",
				["month"] = "10",
				["lastsessiondate"] = "16/09/18",
				["prvmonth"] = "09",
				["dateweek"] = "Sun Oct ",
				["version"] = "v2.11.02",
				["faction"] = "Alliance",
				["totalcash"] = 100000,
				["curryear"] = "2018",
				["prvdateweek"] = "Sun Sep ",
				["prvday"] = "06/10/18",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GUILD"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["BARBER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LFG"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRANSMO"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 100000,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 100000,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GARRISON"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["VOID"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
		["翻墙头"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "07/10/18",
				["class"] = "WARRIOR",
				["month"] = "10",
				["lastsessiondate"] = "27/08/18",
				["prvmonth"] = "09",
				["dateweek"] = "Sun Oct ",
				["version"] = "v2.11.02",
				["faction"] = "Alliance",
				["totalcash"] = 794814028,
				["curryear"] = "2018",
				["prvdateweek"] = "Sun Sep ",
				["prvday"] = "06/10/18",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GUILD"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["BARBER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LFG"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["VOID"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRANSMO"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GARRISON"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 794814028,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 794814028,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 794814028,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
		["乐乐创想"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "07/10/18",
				["class"] = "HUNTER",
				["month"] = "10",
				["curryear"] = "2018",
				["prvmonth"] = "09",
				["dateweek"] = "Sun Oct ",
				["version"] = "v2.11.02",
				["faction"] = "Alliance",
				["totalcash"] = 661342456,
				["lastsessiondate"] = "07/10/18",
				["prvdateweek"] = "Sun Sep ",
				["prvday"] = "06/10/18",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 55832635,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 55832635,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 55832635,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 55832635,
					},
				},
				["BARBER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 2639150,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 179200,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 2729850,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 35700,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 35700,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 767200,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 1940650,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 35700,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 2729850,
					},
				},
				["GUILD"] = {
					["PrvWeek"] = {
						["In"] = 18468958,
						["Out"] = 27331650,
					},
					["PrvDay"] = {
						["In"] = 390177,
						["Out"] = 72100,
					},
					["Year"] = {
						["In"] = 18787489,
						["Out"] = 27331650,
					},
					["Week"] = {
						["In"] = 318531,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 318531,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 2696466,
						["Out"] = 2118124,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 16091023,
						["Out"] = 25213526,
					},
					["Session"] = {
						["In"] = 318531,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 18787489,
						["Out"] = 27331650,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 25661283,
						["Out"] = 199579,
					},
					["PrvDay"] = {
						["In"] = 655884,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 33994703,
						["Out"] = 199579,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 1825421,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 25341840,
						["Out"] = 199579,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 33994703,
						["Out"] = 199579,
					},
				},
				["LFG"] = {
					["PrvWeek"] = {
						["In"] = 19972000,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 3880000,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 20602000,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 4816000,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 15664000,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 20602000,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 314761450,
						["Out"] = 12655142,
					},
					["PrvDay"] = {
						["In"] = 2224513,
						["Out"] = 1080074,
					},
					["Year"] = {
						["In"] = 314761450,
						["Out"] = 12655142,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 303299900,
						["Out"] = 1254392,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 11461550,
						["Out"] = 11400750,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 314761450,
						["Out"] = 12655142,
					},
				},
				["VOID"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 19204062,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 18681362,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 19204062,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 18681362,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 522700,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 19204062,
						["Out"] = 0,
					},
				},
				["GARRISON"] = {
					["PrvWeek"] = {
						["In"] = 15280233,
						["Out"] = 3050000,
					},
					["PrvDay"] = {
						["In"] = 613757,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 17916719,
						["Out"] = 6050000,
					},
					["Week"] = {
						["In"] = 1700000,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 1700000,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 4668296,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 13248423,
						["Out"] = 4550000,
					},
					["Session"] = {
						["In"] = 1700000,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 17916719,
						["Out"] = 6050000,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 52518050,
						["Out"] = 60156,
					},
					["PrvDay"] = {
						["In"] = 4576056,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 56656663,
						["Out"] = 60156,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 9526644,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 45324920,
						["Out"] = 60156,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 56656663,
						["Out"] = 60156,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 54892132,
						["Out"] = 1868610,
					},
					["PrvDay"] = {
						["In"] = 2059006,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 58299141,
						["Out"] = 1868610,
					},
					["Week"] = {
						["In"] = 218566,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 218566,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 7682809,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 48107031,
						["Out"] = 1868610,
					},
					["Session"] = {
						["In"] = 218566,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 58299141,
						["Out"] = 1868610,
					},
				},
				["TRANSMO"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 4895325,
						["Out"] = 2131172,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 1715231,
					},
					["Year"] = {
						["In"] = 5084591,
						["Out"] = 2252856,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 1715231,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 4895325,
						["Out"] = 443114,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 5084591,
						["Out"] = 2252856,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 215548793,
						["Out"] = 17977,
					},
					["PrvDay"] = {
						["In"] = 2361600,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 225034093,
						["Out"] = 17977,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 20248700,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 198510693,
						["Out"] = 17977,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 225034093,
						["Out"] = 17977,
					},
				},
			},
		},
	},
	["迦拉克隆"] = {
		["落晖沉梦"] = {
			["options"] = {
				["weekdate"] = "",
				["weekstart"] = 1,
				["date"] = "07/10/18",
				["class"] = "WARRIOR",
				["faction"] = "Horde",
				["totalcash"] = 2740753809,
				["prvmonth"] = "09",
				["dateweek"] = "Sun Oct ",
				["version"] = "v2.11.02",
				["month"] = "10",
				["lastsessiondate"] = "19/08/18",
				["curryear"] = "2018",
				["prvdateweek"] = "Sun Sep ",
				["prvday"] = "06/10/18",
			},
			["data"] = {
				["TRAIN"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GUILD"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 2027258,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 2027258,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TAXI"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 119700,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 119700,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 53200,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["BARBER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["REPAIRS"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 3556171,
						["Out"] = 2647096,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 3556171,
						["Out"] = 2647096,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 2023931,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LFG"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 9700000,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 9700000,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRANSMO"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MERCH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 19253556,
						["Out"] = 2000,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 19253556,
						["Out"] = 2000,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 2361877,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["TRADE"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["OTHER"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 2589428836,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 2589428836,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["GARRISON"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 31281600,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 31281600,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["LOOT"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 23011114,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 23011114,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 1287171,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["MAIL"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["VOID"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["AH"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
				["QUEST"] = {
					["PrvWeek"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvDay"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Total"] = {
						["In"] = 65264070,
						["Out"] = 0,
					},
					["Week"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Year"] = {
						["In"] = 65264070,
						["Out"] = 0,
					},
					["Month"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvYear"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["PrvMonth"] = {
						["In"] = 0,
						["Out"] = 0,
					},
					["Session"] = {
						["In"] = 9197600,
						["Out"] = 0,
					},
					["Day"] = {
						["In"] = 0,
						["Out"] = 0,
					},
				},
			},
		},
	},
}
Accountant_ClassicDB = {
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Default",
		["落晖沉梦 - 迦拉克隆"] = "Default",
		["乐乐创想 - 金色平原"] = "Default",
		["翻墙头 - 金色平原"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["oprofileCopied"] = true,
		},
	},
}
Accountant_Classic_NewDB = nil
