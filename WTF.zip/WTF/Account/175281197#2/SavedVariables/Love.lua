
CrucibleWeightDB = {
	["chars"] = {
		["落晖沉梦 - 迦拉克隆"] = {
			[128289] = {
			},
			["artifactWeight"] = {
			},
		},
	},
	["artifacts"] = {
		[128289] = {
			[1621] = 238077,
			[96] = 216272,
			[100] = 203225,
			[101] = 203227,
			[105] = 188632,
			[98] = 188683,
			[102] = 188639,
			[106] = 188644,
			[95] = 188635,
			[99] = 203230,
		},
	},
}
EasyObliterate_Data = {
	["addonVersion"] = 18,
	["ashStats"] = {
	},
}
LoveDB = {
	["金色平原_Alliance_乐乐创想"] = {
		["FriendsLogDB"] = {
		},
	},
	["金色平原_Alliance_翻墙头"] = {
		["FriendsLogDB"] = {
			"Ïðïïð", -- [1]
			"伊拉丽丝", -- [2]
			"小眯西", -- [3]
		},
	},
	["金色平原_Alliance_Qweradf"] = {
		["FriendsLogDB"] = {
		},
	},
	["迦拉克隆_Horde_落晖沉梦"] = {
		["FriendsLogDB"] = {
			"凝眸秋水", -- [1]
		},
		["RaidMark"] = {
			["locked"] = false,
		},
	},
}
ezIconsDB = {
	["profileKeys"] = {
		["落晖沉梦 - 迦拉克隆"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
FlashTaskbarDB = {
	["ready_check"] = true,
	["arena_queue"] = true,
	["bg_queue"] = true,
}
ACHIEVEMENTSEARCH_DB = nil
TalentSetManager_Options = nil
ArtifactPowerUserDB = {
	["ignoredItems"] = {
		[147717] = true,
	},
	["lock"] = false,
	["position"] = {
		["y"] = -150,
		["x"] = 0,
		["point"] = "CENTER",
		["relativePoint"] = "CENTER",
	},
	["size"] = 40,
}
