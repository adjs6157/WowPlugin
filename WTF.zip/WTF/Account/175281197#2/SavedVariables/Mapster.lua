
MapsterDB = {
	["namespaces"] = {
		["GroupIcons"] = {
		},
		["Coords"] = {
		},
		["FogClear"] = {
		},
		["BattleMap"] = {
		},
	},
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Default",
		["落晖沉梦 - 迦拉克隆"] = "Default",
		["乐乐创想 - 金色平原"] = "Default",
		["翻墙头 - 金色平原"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
