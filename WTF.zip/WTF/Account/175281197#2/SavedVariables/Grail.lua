
GrailDatabase = {
	["learned"] = {
		["QUEST"] = {
			[45058] = "K110262144 L110",
			[45134] = "K110262144 L110",
			[46263] = "K110262144 L110",
			[46146] = "K110262144 L110",
			[46169] = "K110262144 L110",
			[46170] = "K110262144 L110",
		},
	},
	["delayEventsHandled"] = true,
	["delayEvents"] = true,
}
