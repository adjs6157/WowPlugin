
Broker_GarrisonDB = {
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Default",
		["落晖沉梦 - 迦拉克隆"] = "Default",
		["乐乐创想 - 金色平原"] = "Default",
		["翻墙头 - 金色平原"] = "Default",
	},
	["global"] = {
		["data"] = {
			["金色平原"] = {
				["Qweradf"] = {
					["categories"] = {
					},
					["talents"] = {
						[113] = 113,
					},
					["configVersion"] = 3,
					["missions"] = {
					},
					["tooltipEnabled"] = true,
					["currencySealOfTemperedFateAmount"] = 0,
					["invasion"] = {
					},
					["buildingsExpanded"] = true,
					["missionsExpanded"] = true,
					["lootedToday"] = {
					},
					["shipments"] = {
					},
					["trackWeekly"] = {
					},
					["currencyOrderResourcesAmount"] = 0,
					["lootedNextReset"] = 1538953199,
					["weeklyNextReset"] = 1539212399,
					["looseShipments"] = {
					},
					["cacheSize"] = 500,
					["followerShipments"] = {
					},
					["currencyApexisAmount"] = 0,
					["currencyAncientManaAmount"] = 100,
					["currencyOil"] = 0,
					["currencySealOfInevitableFateAmount"] = 0,
					["orderhallExpanded"] = true,
					["order"] = 5,
					["info"] = {
						["playerName"] = "Qweradf",
						["playerFaction"] = "Alliance",
						["realmName"] = "金色平原",
						["playerClass"] = "HUNTER",
					},
					["trackDaily"] = {
					},
					["notificationEnabled"] = true,
					["ldbEnabled"] = true,
					["currencyAmount"] = 0,
					["buildings"] = {
					},
				},
				["翻墙头"] = {
					["categories"] = {
					},
					["talents"] = {
						[122] = 122,
					},
					["configVersion"] = 3,
					["missions"] = {
						[1713] = {
							["type"] = "7.0 职业大厅 - 一般任务",
							["duration"] = 23040,
							["missionState"] = 0,
							["id"] = 1713,
							["rewards"] = {
								{
									["title"] = "货币奖励",
									["quantity"] = 355,
									["icon"] = 1397630,
									["currencyID"] = 1220,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "菲娜·伯恩多提尔",
									["id"] = "0x000000000122A5D5",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Protection",
									["abilities"] = {
										{
											["id"] = 345,
											["name"] = "防护",
											["icon"] = 132341,
										}, -- [1]
										{
											["id"] = 452,
											["name"] = "拳击",
											["icon"] = 132938,
										}, -- [2]
										{
											["id"] = 771,
											["name"] = "盾牌冲锋",
											["icon"] = 464338,
										}, -- [3]
										{
											["id"] = 994,
											["name"] = "山岭猎手叉矛",
											["icon"] = 454041,
										}, -- [4]
										{
											["id"] = 414,
											["name"] = "空装备栏",
										}, -- [5]
									},
									["iconId"] = 1396682,
								}, -- [1]
								{
									["name"] = "海姆达尔",
									["id"] = "0x000000000153905F",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Fury",
									["abilities"] = {
										{
											["id"] = 343,
											["name"] = "狂怒",
											["icon"] = 132347,
										}, -- [1]
										{
											["id"] = 451,
											["name"] = "英勇飞跃",
											["icon"] = 236171,
										}, -- [2]
										{
											["id"] = 507,
											["name"] = "守门人",
											["icon"] = 515033,
										}, -- [3]
										{
											["id"] = 960,
											["name"] = "黏稠的恶魔之血",
											["icon"] = 463561,
										}, -- [4]
									},
									["iconId"] = 1396679,
								}, -- [2]
								{
									["name"] = "德夫伦·铁符",
									["id"] = "0x00000000044F03E8",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Fury",
									["abilities"] = {
										{
											["id"] = 343,
											["name"] = "狂怒",
											["icon"] = 132347,
										}, -- [1]
										{
											["id"] = 452,
											["name"] = "拳击",
											["icon"] = 132938,
										}, -- [2]
									},
									["iconId"] = 1396651,
								}, -- [3]
							},
							["timeLeftCalc"] = 0,
							["statusComplete"] = true,
							["notification"] = 1,
							["name"] = "邪恶阴谋",
							["followerTypeID"] = 4,
							["start"] = 1535358258,
							["level"] = 110,
							["timeLeft"] = "0秒",
							["typeAtlas"] = "ClassHall-CombatIcon-Desaturated",
						},
						[1709] = {
							["type"] = "7.0 职业大厅 - 宝藏任务 - 团队副本",
							["duration"] = 46080,
							["missionState"] = 0,
							["id"] = 1709,
							["rewards"] = {
								{
									["itemID"] = 152321,
									["quantity"] = 1,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "瑟维甘·风篷",
									["id"] = "0x00000000015390E0",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Protection",
									["abilities"] = {
										{
											["id"] = 345,
											["name"] = "防护",
											["icon"] = 132341,
										}, -- [1]
										{
											["id"] = 450,
											["name"] = "旋风斩",
											["icon"] = 132369,
										}, -- [2]
										{
											["id"] = 505,
											["name"] = "皇室血统",
											["icon"] = 132346,
										}, -- [3]
										{
											["id"] = 961,
											["name"] = "克罗库战锤",
											["icon"] = 454057,
										}, -- [4]
									},
									["iconId"] = 1396683,
								}, -- [1]
								{
									["name"] = "女武神",
									["id"] = "0x00000000047E89A5",
									["classIcon"] = "GarrMission_ClassIcon-Warrior",
									["abilities"] = {
										{
											["id"] = 600,
											["name"] = "致死劈砍",
											["icon"] = 659264,
										}, -- [1]
									},
									["iconId"] = 1489384,
								}, -- [2]
								{
									["name"] = "女武神",
									["id"] = "0x000000000480F113",
									["classIcon"] = "GarrMission_ClassIcon-Warrior",
									["abilities"] = {
										{
											["id"] = 600,
											["name"] = "致死劈砍",
											["icon"] = 659264,
										}, -- [1]
									},
									["iconId"] = 1489345,
								}, -- [3]
							},
							["timeLeftCalc"] = 0,
							["statusComplete"] = true,
							["notification"] = 1,
							["name"] = "安托鲁斯，燃烧王座",
							["followerTypeID"] = 4,
							["start"] = 0,
							["level"] = 110,
							["timeLeft"] = "0秒",
							["typeAtlas"] = "ClassHall-TreasureIcon-Desaturated",
						},
						[1724] = {
							["type"] = "7.0 职业大厅 - 一般任务",
							["duration"] = 34560,
							["missionState"] = 0,
							["id"] = 1724,
							["rewards"] = {
								{
									["title"] = "货币奖励",
									["quantity"] = 395,
									["icon"] = 1397630,
									["currencyID"] = 1220,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "拉格瓦尔德·龙脉",
									["id"] = "0x000000000122A5CD",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Arms",
									["abilities"] = {
										{
											["id"] = 344,
											["name"] = "武器",
											["icon"] = 132355,
										}, -- [1]
										{
											["id"] = 450,
											["name"] = "旋风斩",
											["icon"] = 132369,
										}, -- [2]
										{
											["id"] = 503,
											["name"] = "命令怒吼",
											["icon"] = 132351,
										}, -- [3]
										{
											["id"] = 960,
											["name"] = "黏稠的恶魔之血",
											["icon"] = 463561,
										}, -- [4]
									},
									["iconId"] = 1452591,
								}, -- [1]
								{
									["name"] = "托里姆",
									["id"] = "0x00000000044F03E7",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Arms",
									["abilities"] = {
										{
											["id"] = 344,
											["name"] = "武器",
											["icon"] = 132355,
										}, -- [1]
										{
											["id"] = 451,
											["name"] = "英勇飞跃",
											["icon"] = 236171,
										}, -- [2]
										{
											["id"] = 502,
											["name"] = "泰坦之怒",
											["icon"] = 237046,
										}, -- [3]
										{
											["id"] = 759,
											["name"] = "一瓶永恒之息",
											["icon"] = 132377,
										}, -- [4]
									},
									["iconId"] = 1416428,
								}, -- [2]
							},
							["timeLeftCalc"] = 0,
							["statusComplete"] = true,
							["notification"] = 1,
							["name"] = "登山岩羊",
							["followerTypeID"] = 4,
							["start"] = 1535346738,
							["level"] = 110,
							["timeLeft"] = "0秒",
							["typeAtlas"] = "ClassHall-CombatIcon-Desaturated",
						},
					},
					["tooltipEnabled"] = true,
					["currencySealOfTemperedFateAmount"] = 0,
					["invasion"] = {
					},
					["buildingsExpanded"] = true,
					["missionsExpanded"] = true,
					["lootedToday"] = {
					},
					["shipments"] = {
					},
					["trackWeekly"] = {
					},
					["currencyOrderResourcesAmount"] = 17725,
					["lootedNextReset"] = 1538953199,
					["weeklyNextReset"] = 1539212399,
					["looseShipments"] = {
						{
							["shipmentsTotal"] = 24,
							["name"] = "精瘦腿肉食谱",
							["shipmentCapacity"] = 24,
							["duration"] = 0,
							["creationTime"] = 0,
							["shipmentsReady"] = 24,
							["texture"] = 134939,
						}, -- [1]
					},
					["cacheSize"] = 750,
					["followerShipments"] = {
						{
							["shipmentCapacity"] = 1,
							["shipmentsTotal"] = 1,
							["name"] = "女武神",
							["followerID"] = 687,
							["duration"] = 0,
							["creationTime"] = 0,
							["shipmentsReady"] = 1,
							["texture"] = 1401854,
						}, -- [1]
					},
					["currencyApexisAmount"] = 4610,
					["currencyAncientManaAmount"] = 179,
					["currencyOil"] = 470,
					["currencySealOfInevitableFateAmount"] = 0,
					["orderhallExpanded"] = true,
					["order"] = 5,
					["info"] = {
						["playerName"] = "翻墙头",
						["playerFaction"] = "Alliance",
						["realmName"] = "金色平原",
						["playerClass"] = "WARRIOR",
					},
					["trackDaily"] = {
					},
					["notificationEnabled"] = true,
					["ldbEnabled"] = true,
					["currencyAmount"] = 3071,
					["buildings"] = {
						[24] = {
							["shipment"] = {
								["shipmentsAvailable"] = 9,
								["itemName"] = "锻造好的武器和护甲",
								["itemQuality"] = 1,
								["shipmentCapacity"] = 29,
								["notificationValue"] = 20,
								["duration"] = 0,
								["shipmentsReadyEstimate"] = 20,
								["shipmentsInProgress"] = 0,
								["itemID"] = 120204,
								["notification"] = 1,
								["name"] = "矮人地堡",
								["shipmentsTotal"] = 20,
								["notificationDismissed"] = false,
								["creationTime"] = 0,
								["shipmentsReady"] = 20,
								["texture"] = 975736,
							},
							["id"] = 9,
							["plotID"] = 24,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "矮人地堡",
							["timeStart"] = 1420643579,
							["texPrefix"] = "GarrBuilding_Armory_2_A",
							["isBuilding"] = false,
							["icon"] = 975736,
							["rank"] = 2,
						},
						[63] = {
							["shipment"] = {
								["shipmentCapacity"] = 29,
								["name"] = "药圃",
								["texture"] = 134221,
							},
							["id"] = 136,
							["plotID"] = 63,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "药圃",
							["timeStart"] = 1471534023,
							["texPrefix"] = "GarrBuilding_Farm_1_A",
							["isBuilding"] = false,
							["icon"] = 134221,
							["rank"] = 2,
						},
						[67] = {
							["shipment"] = {
							},
							["id"] = 134,
							["plotID"] = 67,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "渔夫小屋",
							["timeStart"] = 1471534030,
							["texPrefix"] = "GarrBuilding_Fishing_2_A",
							["isBuilding"] = false,
							["icon"] = 136245,
							["rank"] = 2,
						},
						[25] = {
							["shipment"] = {
								["shipmentCapacity"] = 29,
								["name"] = "货栈",
								["texture"] = 975746,
							},
							["id"] = 144,
							["plotID"] = 25,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "货栈",
							["timeStart"] = 1471793304,
							["texPrefix"] = "GarrBuilding_TradingPost_2_A",
							["isBuilding"] = false,
							["icon"] = 975746,
							["rank"] = 2,
						},
						[18] = {
							["shipment"] = {
								["shipmentCapacity"] = 36,
								["name"] = "工坊",
								["texture"] = 136243,
							},
							["id"] = 124,
							["plotID"] = 18,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "工坊",
							["timeStart"] = 1471530691,
							["texPrefix"] = "GarrBuilding_Engineering_3_A",
							["isBuilding"] = false,
							["icon"] = 136243,
							["rank"] = 3,
						},
						[98] = {
							["shipment"] = {
								["shipmentCapacity"] = 1,
								["name"] = "坠月船坞",
								["texture"] = 1126431,
							},
							["id"] = 206,
							["plotID"] = 98,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 0,
							["name"] = "坠月船坞",
							["timeStart"] = 1471792731,
							["texPrefix"] = "GarrBuilding_Armory_1_A",
							["isBuilding"] = false,
							["icon"] = 1126431,
							["rank"] = 2,
						},
						[20] = {
							["shipment"] = {
							},
							["id"] = 141,
							["plotID"] = 20,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "废品站",
							["timeStart"] = 1471750431,
							["texPrefix"] = "GarrBuilding_SalvageYard_1_A",
							["isBuilding"] = false,
							["icon"] = 975742,
							["rank"] = 3,
						},
						[23] = {
							["shipment"] = {
							},
							["id"] = 28,
							["plotID"] = 23,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "兵营",
							["timeStart"] = 1441432631,
							["texPrefix"] = "GarrBuilding_Barracks_3_A",
							["isBuilding"] = false,
							["icon"] = 975738,
							["rank"] = 3,
						},
						[22] = {
							["shipment"] = {
							},
							["id"] = 36,
							["plotID"] = 22,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "坠月旅店",
							["timeStart"] = 1420870656,
							["texPrefix"] = "GarrBuilding_Inn_3_A",
							["isBuilding"] = false,
							["icon"] = 134414,
							["rank"] = 3,
						},
						[59] = {
							["shipment"] = {
								["shipmentsAvailable"] = 29,
								["itemName"] = "矿镐",
								["itemQuality"] = 1,
								["shipmentCapacity"] = 36,
								["notificationValue"] = 7,
								["duration"] = 0,
								["shipmentsReadyEstimate"] = 7,
								["shipmentsInProgress"] = 0,
								["itemID"] = 116055,
								["notification"] = 1,
								["name"] = "坠月挖掘场",
								["shipmentsTotal"] = 7,
								["notificationDismissed"] = false,
								["creationTime"] = 0,
								["shipmentsReady"] = 7,
								["texture"] = 136248,
							},
							["id"] = 63,
							["plotID"] = 59,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "坠月挖掘场",
							["timeStart"] = 1471534028,
							["texPrefix"] = "GarrBuilding_Mine_1_A",
							["isBuilding"] = false,
							["icon"] = 136248,
							["rank"] = 3,
						},
						[19] = {
							["shipment"] = {
							},
							["id"] = 143,
							["plotID"] = 19,
							["buildingState"] = 0,
							["canActivate"] = false,
							["buildTime"] = 3600,
							["name"] = "仓库",
							["timeStart"] = 1471534025,
							["texPrefix"] = "GarrBuilding_Storehouse_1_A",
							["isBuilding"] = false,
							["icon"] = 975745,
							["rank"] = 3,
						},
					},
				},
				["乐乐创想"] = {
					["categories"] = {
					},
					["talents"] = {
						[113] = 113,
					},
					["configVersion"] = 3,
					["missions"] = {
						[88] = {
							["type"] = "战斗",
							["duration"] = 1800,
							["missionState"] = 0,
							["id"] = 88,
							["rewards"] = {
								{
									["title"] = "货币奖励",
									["quantity"] = 20,
									["icon"] = 1005027,
									["currencyID"] = 824,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "德尔瓦·铁拳",
									["id"] = "0x00000000053C422E",
									["classIcon"] = "GarrMission_ClassIcon-DeathKnight",
									["abilities"] = {
										{
											["id"] = 231,
											["name"] = "看家护院",
											["icon"] = 1037260,
										}, -- [1]
										{
											["id"] = 115,
											["name"] = "白骨之盾",
											["icon"] = 458717,
										}, -- [2]
										{
											["id"] = 118,
											["name"] = "符文武器增效",
											["icon"] = 135372,
										}, -- [3]
										{
											["id"] = 45,
											["name"] = "穴居人",
											["icon"] = 409595,
										}, -- [4]
										{
											["id"] = 37,
											["name"] = "野兽克星",
											["icon"] = 298659,
										}, -- [5]
									},
									["iconId"] = 1066337,
								}, -- [1]
							},
							["timeLeftCalc"] = 0,
							["statusComplete"] = true,
							["notification"] = 1,
							["name"] = "天空的威胁",
							["followerTypeID"] = 1,
							["start"] = 0,
							["level"] = 90,
							["typeAtlas"] = "GarrMission_MissionIcon-Combat",
							["timeLeft"] = "30分钟",
						},
						[89] = {
							["type"] = "战斗",
							["duration"] = 3600,
							["missionState"] = 0,
							["id"] = 89,
							["rewards"] = {
								{
									["itemID"] = 114052,
									["quantity"] = 1,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "雪莉·汉比",
									["id"] = "0x00000000054C917F",
									["classIcon"] = "GarrMission_ClassIcon-Rogue",
									["abilities"] = {
										{
											["id"] = 160,
											["name"] = "疾跑",
											["icon"] = 132307,
										}, -- [1]
										{
											["id"] = 60,
											["name"] = "制皮",
											["icon"] = 136247,
										}, -- [2]
									},
									["iconId"] = 1066399,
								}, -- [1]
								{
									["name"] = "菲奥拉",
									["id"] = "0x00000000054AB8F4",
									["classIcon"] = "GarrMission_ClassIcon-Priest",
									["abilities"] = {
										{
											["id"] = 53,
											["name"] = "草药学",
											["icon"] = 136246,
										}, -- [1]
										{
											["id"] = 11,
											["name"] = "治疗祷言",
											["icon"] = 135943,
										}, -- [2]
									},
									["iconId"] = 1066059,
								}, -- [2]
								{
									["name"] = "游侠切尔",
									["id"] = "0x00000000053EF834",
									["classIcon"] = "GarrMission_ClassIcon-Hunter",
									["abilities"] = {
										{
											["id"] = 101,
											["name"] = "多重射击",
											["icon"] = 132330,
										}, -- [1]
										{
											["id"] = 44,
											["name"] = "自然学家",
											["icon"] = 236830,
										}, -- [2]
									},
									["iconId"] = 1066129,
								}, -- [3]
							},
							["statusComplete"] = true,
							["timeLeftCalc"] = 0,
							["notification"] = 1,
							["name"] = "突袭影月岗哨",
							["followerTypeID"] = 1,
							["start"] = 1535890767,
							["level"] = 90,
							["typeAtlas"] = "GarrMission_MissionIcon-Combat",
							["timeLeft"] = "1小时",
						},
						[1052] = {
							["type"] = "7.0 职业大厅 - 一般任务",
							["rewards"] = {
								{
									["itemID"] = 140584,
									["quantity"] = 1,
								}, -- [1]
							},
							["missionState"] = 0,
							["id"] = 1052,
							["duration"] = 7200,
							["followers"] = {
								{
									["name"] = "罗伦·雷蹄",
									["id"] = "0x00000000055C83DF",
									["classIcon"] = "GarrMission_ClassIcon-Hunter-Marksmanship",
									["abilities"] = {
										{
											["id"] = 365,
											["name"] = "射击",
											["icon"] = 236179,
										}, -- [1]
										{
											["id"] = 449,
											["name"] = "反制射击",
											["icon"] = 249170,
										}, -- [2]
									},
									["iconId"] = 1396695,
								}, -- [1]
							},
							["statusComplete"] = true,
							["timeLeftCalc"] = 0,
							["notification"] = 1,
							["name"] = "边境增援",
							["followerTypeID"] = 4,
							["start"] = 0,
							["level"] = 100,
							["timeLeft"] = "2小时",
							["typeAtlas"] = "ClassHall-CombatIcon-Desaturated",
						},
					},
					["tooltipEnabled"] = true,
					["currencySealOfTemperedFateAmount"] = 0,
					["invasion"] = {
						["available"] = false,
					},
					["buildingsExpanded"] = true,
					["garrisonCacheLastLooted"] = 1537602694,
					["missionsExpanded"] = true,
					["buildings"] = {
						[59] = {
							["shipment"] = {
								["name"] = "坠月挖掘场",
								["shipmentCapacity"] = 12,
								["texture"] = 136248,
							},
							["buildingState"] = 0,
							["id"] = 61,
							["plotID"] = 59,
							["plotSize"] = 2,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["name"] = "坠月挖掘场",
							["timeStart"] = 1535807348,
							["texPrefix"] = "GarrBuilding_Mine_1_A",
							["isBuilding"] = false,
							["icon"] = 136248,
							["rank"] = 1,
						},
						[22] = {
							["shipment"] = {
								["name"] = "货栈",
								["shipmentCapacity"] = 12,
								["texture"] = 975746,
							},
							["buildingState"] = 0,
							["id"] = 111,
							["plotID"] = 22,
							["plotSize"] = 2,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["notification"] = 1,
							["name"] = "货栈",
							["timeStart"] = 1535875407,
							["texPrefix"] = "GarrBuilding_TradingPost_1_A",
							["isBuilding"] = false,
							["icon"] = 975746,
							["rank"] = 1,
						},
						[19] = {
							["shipment"] = {
							},
							["buildingState"] = 0,
							["id"] = 51,
							["plotID"] = 19,
							["plotSize"] = 1,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["notification"] = 1,
							["name"] = "仓库",
							["timeStart"] = 1535807018,
							["texPrefix"] = "GarrBuilding_Storehouse_1_A",
							["isBuilding"] = false,
							["icon"] = 975745,
							["rank"] = 1,
						},
						[23] = {
							["shipment"] = {
							},
							["buildingState"] = 0,
							["id"] = 26,
							["plotID"] = 23,
							["plotSize"] = 3,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["notification"] = 1,
							["name"] = "兵营",
							["timeStart"] = 1535275748,
							["texPrefix"] = "GarrBuilding_Barracks_1_A",
							["isBuilding"] = false,
							["icon"] = 975738,
							["rank"] = 1,
						},
						[63] = {
							["shipment"] = {
								["name"] = "药圃",
								["shipmentCapacity"] = 12,
								["texture"] = 134221,
							},
							["buildingState"] = 0,
							["id"] = 29,
							["plotID"] = 63,
							["plotSize"] = 2,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["name"] = "药圃",
							["timeStart"] = 1535883840,
							["texPrefix"] = "GarrBuilding_Farm_1_A",
							["isBuilding"] = false,
							["icon"] = 134221,
							["rank"] = 1,
						},
					},
					["shipments"] = {
					},
					["ldbEnabled"] = true,
					["currencyOrderResourcesAmount"] = 5549,
					["lootedNextReset"] = 1538953199,
					["trackWeekly"] = {
						["BONUS_ROLL_QUESTS"] = 0,
						["WARMILL_SOTF"] = false,
					},
					["looseShipments"] = {
					},
					["notificationEnabled"] = true,
					["followerShipments"] = {
					},
					["currencyApexisAmount"] = 0,
					["currencyAncientManaAmount"] = 0,
					["currencyOil"] = 0,
					["order"] = 5,
					["orderhallExpanded"] = true,
					["currencySealOfInevitableFateAmount"] = 0,
					["info"] = {
						["bonusEnabled"] = true,
						["playerClass"] = "HUNTER",
						["realmName"] = "金色平原",
						["playerName"] = "乐乐创想",
						["playerFaction"] = "Alliance",
					},
					["trackDaily"] = {
						["WARMILL_IRONSCRAPS"] = false,
					},
					["cacheSize"] = 500,
					["weeklyNextReset"] = 1539212399,
					["currencyAmount"] = 1504,
					["lootedToday"] = {
					},
				},
			},
			["迦拉克隆"] = {
				["落晖沉梦"] = {
					["categories"] = {
					},
					["talents"] = {
						[122] = 122,
					},
					["configVersion"] = 3,
					["missions"] = {
						[1723] = {
							["type"] = "7.0 职业大厅 - 一般任务",
							["duration"] = 62208,
							["missionState"] = 0,
							["id"] = 1723,
							["rewards"] = {
								{
									["title"] = "金钱奖励",
									["quantity"] = 10008100,
									["icon"] = "Interface\\Icons\\inv_misc_coin_01",
									["currencyID"] = 0,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "肉弹",
									["id"] = "0x0000000007F1D419",
									["classIcon"] = "GarrMission_ClassIcon-Karazhan",
									["abilities"] = {
										{
											["id"] = 805,
											["name"] = "肉弹狂乱！",
											["icon"] = 136224,
										}, -- [1]
										{
											["id"] = 806,
											["name"] = "巨大噪声！",
											["icon"] = 136147,
										}, -- [2]
										{
											["id"] = 807,
											["name"] = "嗝儿！",
											["icon"] = 135739,
										}, -- [3]
										{
											["id"] = 681,
											["name"] = "棍子上的胡萝卜",
											["icon"] = 134010,
										}, -- [4]
									},
									["iconId"] = 1551346,
								}, -- [1]
								{
									["name"] = "海姆达尔",
									["id"] = "0x0000000003B07340",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Fury",
									["abilities"] = {
										{
											["id"] = 343,
											["name"] = "狂怒",
											["icon"] = 132347,
										}, -- [1]
										{
											["id"] = 451,
											["name"] = "英勇飞跃",
											["icon"] = 236171,
										}, -- [2]
										{
											["id"] = 507,
											["name"] = "守门人",
											["icon"] = 515033,
										}, -- [3]
										{
											["id"] = 759,
											["name"] = "一瓶永恒之息",
											["icon"] = 132377,
										}, -- [4]
										{
											["id"] = 962,
											["name"] = "深渊领主獠牙",
											["icon"] = 135705,
										}, -- [5]
										{
											["id"] = 808,
											["name"] = "奇怪的能量球",
											["icon"] = 1033906,
										}, -- [6]
									},
									["iconId"] = 1396679,
								}, -- [2]
							},
							["timeLeftCalc"] = 0,
							["statusComplete"] = true,
							["notification"] = 1,
							["name"] = "步入深渊",
							["followerTypeID"] = 4,
							["start"] = 1531576969,
							["level"] = 110,
							["typeAtlas"] = "ClassHall-CombatIcon-Desaturated",
							["timeLeft"] = "17小时16分钟",
						},
						[1714] = {
							["type"] = "7.0 职业大厅 - 一般任务",
							["duration"] = 12441,
							["missionState"] = 0,
							["id"] = 1714,
							["rewards"] = {
								{
									["title"] = "金钱奖励",
									["quantity"] = 10543100,
									["icon"] = "Interface\\Icons\\inv_misc_coin_01",
									["currencyID"] = 0,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "菲娜·伯恩多提尔",
									["id"] = "0x000000000372EA8D",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Protection",
									["abilities"] = {
										{
											["id"] = 345,
											["name"] = "防护",
											["icon"] = 132341,
										}, -- [1]
										{
											["id"] = 452,
											["name"] = "拳击",
											["icon"] = 132938,
										}, -- [2]
										{
											["id"] = 771,
											["name"] = "盾牌冲锋",
											["icon"] = 464338,
										}, -- [3]
										{
											["id"] = 759,
											["name"] = "一瓶永恒之息",
											["icon"] = 132377,
										}, -- [4]
										{
											["id"] = 993,
											["name"] = "上古先知之石",
											["icon"] = 1379232,
										}, -- [5]
										{
											["id"] = 909,
											["name"] = "隐蔽斗篷",
											["icon"] = 336785,
										}, -- [6]
										{
											["id"] = 808,
											["name"] = "奇怪的能量球",
											["icon"] = 1033906,
										}, -- [7]
									},
									["iconId"] = 1396682,
								}, -- [1]
								{
									["name"] = "伊崔格",
									["id"] = "0x000000000571C4CE",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Fury",
									["abilities"] = {
										{
											["id"] = 343,
											["name"] = "狂怒",
											["icon"] = 132347,
										}, -- [1]
										{
											["id"] = 451,
											["name"] = "英勇飞跃",
											["icon"] = 236171,
										}, -- [2]
										{
											["id"] = 812,
											["name"] = "鲜血与荣耀",
											["icon"] = 132352,
										}, -- [3]
										{
											["id"] = 758,
											["name"] = "无尽合剂",
											["icon"] = 135446,
										}, -- [4]
										{
											["id"] = 684,
											["name"] = "幸运装饰品",
											["icon"] = 1509625,
										}, -- [5]
										{
											["id"] = 681,
											["name"] = "棍子上的胡萝卜",
											["icon"] = 134010,
										}, -- [6]
									},
									["iconId"] = 1341807,
								}, -- [2]
								{
									["name"] = "拉格瓦尔德·龙脉",
									["id"] = "0x000000000372EA91",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Arms",
									["abilities"] = {
										{
											["id"] = 344,
											["name"] = "武器",
											["icon"] = 132355,
										}, -- [1]
										{
											["id"] = 450,
											["name"] = "旋风斩",
											["icon"] = 132369,
										}, -- [2]
										{
											["id"] = 503,
											["name"] = "命令怒吼",
											["icon"] = 132351,
										}, -- [3]
										{
											["id"] = 758,
											["name"] = "无尽合剂",
											["icon"] = 135446,
										}, -- [4]
										{
											["id"] = 992,
											["name"] = "邪犬脊椎骨鞭",
											["icon"] = 646679,
										}, -- [5]
									},
									["iconId"] = 1452591,
								}, -- [3]
							},
							["timeLeftCalc"] = 0,
							["statusComplete"] = true,
							["notification"] = 1,
							["name"] = "正义降临",
							["followerTypeID"] = 4,
							["start"] = 0,
							["level"] = 110,
							["typeAtlas"] = "ClassHall-CombatIcon-Desaturated",
							["timeLeft"] = "3小时27分钟",
						},
						[1726] = {
							["type"] = "7.0 职业大厅 - 一般任务",
							["duration"] = 69120,
							["missionState"] = 0,
							["id"] = 1726,
							["rewards"] = {
								{
									["itemID"] = 152957,
									["quantity"] = 1,
								}, -- [1]
							},
							["followers"] = {
								{
									["name"] = "德夫伦·铁符",
									["id"] = "0x0000000003DAF820",
									["classIcon"] = "GarrMission_ClassIcon-Warrior-Fury",
									["abilities"] = {
										{
											["id"] = 343,
											["name"] = "狂怒",
											["icon"] = 132347,
										}, -- [1]
										{
											["id"] = 452,
											["name"] = "拳击",
											["icon"] = 132938,
										}, -- [2]
										{
											["id"] = 506,
											["name"] = "激怒",
											["icon"] = 132345,
										}, -- [3]
										{
											["id"] = 994,
											["name"] = "山岭猎手叉矛",
											["icon"] = 454041,
										}, -- [4]
										{
											["id"] = 961,
											["name"] = "克罗库战锤",
											["icon"] = 454057,
										}, -- [5]
										{
											["id"] = 719,
											["name"] = "战旗",
											["icon"] = 136005,
										}, -- [6]
									},
									["iconId"] = 1396651,
								}, -- [1]
								{
									["name"] = "被虚空净化的克罗库",
									["id"] = "0x0000000008757905",
									["classIcon"] = "GarrMission_ClassIcon-Voidscarred",
									["abilities"] = {
										{
											["id"] = 953,
											["name"] = "虚空之触",
											["icon"] = 1386547,
										}, -- [1]
										{
											["id"] = 978,
											["name"] = "阿古斯老兵",
											["icon"] = 1113433,
										}, -- [2]
									},
									["iconId"] = 1712228,
								}, -- [2]
							},
							["timeLeftCalc"] = 0,
							["statusComplete"] = true,
							["notification"] = 1,
							["name"] = "绝不撤退",
							["followerTypeID"] = 4,
							["start"] = 1531577050,
							["level"] = 110,
							["typeAtlas"] = "ClassHall-CombatIcon-Desaturated",
							["timeLeft"] = "19小时12分钟",
						},
					},
					["tooltipEnabled"] = true,
					["currencySealOfTemperedFateAmount"] = 0,
					["invasion"] = {
					},
					["buildingsExpanded"] = true,
					["missionsExpanded"] = true,
					["lootedToday"] = {
					},
					["shipments"] = {
					},
					["trackWeekly"] = {
					},
					["currencyOrderResourcesAmount"] = 35518,
					["lootedNextReset"] = 1538953199,
					["weeklyNextReset"] = 1539212399,
					["looseShipments"] = {
						{
							["shipmentsTotal"] = 24,
							["name"] = "精瘦腿肉食谱",
							["texture"] = 134939,
							["creationTime"] = 0,
							["duration"] = 0,
							["shipmentsReady"] = 24,
							["shipmentCapacity"] = 24,
						}, -- [1]
					},
					["cacheSize"] = 500,
					["followerShipments"] = {
					},
					["currencyApexisAmount"] = 120,
					["currencyAncientManaAmount"] = 1078,
					["currencyOil"] = 0,
					["currencySealOfInevitableFateAmount"] = 0,
					["orderhallExpanded"] = true,
					["order"] = 5,
					["info"] = {
						["playerFaction"] = "Horde",
						["playerClass"] = "WARRIOR",
						["bonusEnabled"] = true,
						["playerName"] = "落晖沉梦",
						["realmName"] = "迦拉克隆",
					},
					["trackDaily"] = {
					},
					["notificationEnabled"] = true,
					["ldbEnabled"] = true,
					["currencyAmount"] = 4062,
					["buildings"] = {
						[59] = {
							["shipment"] = {
								["shipmentsTotal"] = 3,
								["notificationValue"] = 0,
								["duration"] = 0,
								["texture"] = 136248,
								["itemName"] = "矿镐",
								["notificationDismissed"] = false,
								["itemID"] = 116055,
								["name"] = "霜壁矿井",
								["shipmentCapacity"] = 19,
								["creationTime"] = 0,
								["shipmentsReady"] = 3,
								["itemQuality"] = 1,
							},
							["id"] = 62,
							["plotID"] = 59,
							["rank"] = 2,
							["canActivate"] = true,
							["buildTime"] = 3600,
							["notification"] = 1,
							["name"] = "霜壁矿井",
							["isBuilding"] = false,
							["texPrefix"] = "GarrBuilding_Mine_1_H",
							["timeStart"] = 1486867758,
							["icon"] = 136248,
							["buildingState"] = 1,
						},
						[18] = {
							["shipment"] = {
							},
							["id"] = 51,
							["plotID"] = 18,
							["rank"] = 1,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["name"] = "仓库",
							["isBuilding"] = false,
							["texPrefix"] = "GarrBuilding_Storehouse_1_H",
							["timeStart"] = 1471097427,
							["icon"] = 975745,
							["buildingState"] = 0,
						},
						[22] = {
							["shipment"] = {
							},
							["id"] = 34,
							["plotID"] = 22,
							["rank"] = 1,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["name"] = "霜壁旅社",
							["isBuilding"] = false,
							["texPrefix"] = "GarrBuilding_Inn_1_H",
							["timeStart"] = 1471097409,
							["icon"] = 134414,
							["buildingState"] = 0,
						},
						[67] = {
							["shipment"] = {
							},
							["id"] = 64,
							["plotID"] = 67,
							["rank"] = 1,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["name"] = "渔夫小屋",
							["isBuilding"] = false,
							["texPrefix"] = "GarrBuilding_Fishing_1_H",
							["timeStart"] = 1471167362,
							["icon"] = 136245,
							["buildingState"] = 0,
						},
						[23] = {
							["shipment"] = {
							},
							["id"] = 26,
							["plotID"] = 23,
							["rank"] = 1,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["name"] = "兵营",
							["isBuilding"] = false,
							["texPrefix"] = "GarrBuilding_Barracks_1_H",
							["timeStart"] = 1471052016,
							["icon"] = 975738,
							["buildingState"] = 0,
						},
						[63] = {
							["shipment"] = {
								["texture"] = 134221,
								["name"] = "药圃",
								["shipmentCapacity"] = 12,
							},
							["id"] = 29,
							["plotID"] = 63,
							["rank"] = 1,
							["buildTime"] = 3600,
							["canActivate"] = false,
							["name"] = "药圃",
							["isBuilding"] = false,
							["texPrefix"] = "GarrBuilding_Farm_1_H",
							["timeStart"] = 1477141889,
							["icon"] = 134221,
							["buildingState"] = 0,
						},
					},
				},
			},
		},
	},
	["profiles"] = {
		["Default"] = {
		},
	},
}
