
RangeDisplayDB3 = {
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
		},
	},
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Default",
		["落晖沉梦 - 迦拉克隆"] = "Default",
		["乐乐创想 - 金色平原"] = "Default",
		["翻墙头 - 金色平原"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["locked"] = true,
			["units"] = {
				["pet"] = {
				},
				["arena2"] = {
				},
				["focus"] = {
				},
				["arena5"] = {
				},
				["arena4"] = {
				},
			},
		},
	},
}
