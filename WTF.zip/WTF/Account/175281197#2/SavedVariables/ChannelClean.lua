
DuowanAddon_ChannelCleanDB = {
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Default",
		["落晖沉梦 - 迦拉克隆"] = "Default",
		["乐乐创想 - 金色平原"] = "Default",
		["翻墙头 - 金色平原"] = "Default",
	},
	["profiles"] = {
		["Default"] = {
			["firstTime"] = false,
			["filter"] = {
				["trigger"] = {
					"★", -- [1]
					"☆", -- [2]
					"●", -- [3]
					"◆", -- [4]
					"■", -- [5]
					"▲", -- [6]
					"〓", -- [7]
					"※", -- [8]
					"▆", -- [9]
				},
			},
		},
	},
}
