
HPetSaves = {
	["AbScale"] = 0.75,
}
