
DuowanAddon_DCTSA_CONFIG = {
	["DCTSA_SAVE"] = {
		["DCTSA_FILTER_CASTSUCCESS_SORT"] = {
			["filt"] = {
			},
			["buffer"] = {
				"锯齿之喉", -- [1]
				"噬血箭", -- [2]
			},
		},
		["DCTSA_FILTER_CASTSUCCESS"] = {
			["filt"] = {
			},
			["buffer"] = {
				["噬血箭"] = 0,
				["锯齿之喉"] = 0,
			},
		},
		["DCTSA_SAVEDATA_VER"] = 2001,
		["DCTSA_FILTER_BUFF_SORT"] = {
			["filt"] = {
			},
			["buffer"] = {
				"召唤野兽", -- [1]
				"血腥之怒", -- [2]
				"阿玛尼战甲", -- [3]
			},
		},
		["DCTSA_FILTER_CASTSTART"] = {
			["filt"] = {
			},
			["buffer"] = {
				["噬血箭"] = 0,
				["召唤野兽"] = 0,
				["召唤鸟群"] = 0,
				["闪电箭"] = 0,
				["掷斧"] = 0,
				["治疗术"] = 0,
				["锯齿之喉"] = 0,
				["沙尘爆裂"] = 0,
				["召唤闪电"] = 0,
				["巫毒图腾"] = 0,
			},
		},
		["DCTSA_FILTER_DISPELLED"] = {
			["filt"] = {
			},
			["buffer"] = {
			},
		},
		["DCTSA_FILTER_CASTSTART_SORT"] = {
			["filt"] = {
			},
			["buffer"] = {
				"巫毒图腾", -- [1]
				"召唤闪电", -- [2]
				"召唤鸟群", -- [3]
				"闪电箭", -- [4]
				"召唤野兽", -- [5]
				"锯齿之喉", -- [6]
				"噬血箭", -- [7]
				"掷斧", -- [8]
				"治疗术", -- [9]
				"沙尘爆裂", -- [10]
			},
		},
		["DCTSA_FILTER_BUFF"] = {
			["filt"] = {
			},
			["buffer"] = {
				["阿玛尼战甲"] = 0,
				["召唤野兽"] = 0,
				["血腥之怒"] = 0,
			},
		},
		["DCTSA_FILTER_DISPELLED_SORT"] = {
			["filt"] = {
			},
			["buffer"] = {
			},
		},
		["PROFILE"] = {
		},
	},
}
