
HandyNotesDB = {
	["profileKeys"] = {
		["落晖沉梦 - 迦拉克隆"] = "落晖沉梦 - 迦拉克隆",
	},
	["profiles"] = {
		["落晖沉梦 - 迦拉克隆"] = {
		},
	},
}
HandyNotes_HandyNotesDB = {
	["profileKeys"] = {
		["落晖沉梦 - 迦拉克隆"] = "落晖沉梦 - 迦拉克隆",
	},
	["profiles"] = {
		["落晖沉梦 - 迦拉克隆"] = {
		},
	},
}
