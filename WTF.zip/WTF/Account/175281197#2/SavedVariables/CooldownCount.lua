
CooldownCountDB = {
	["profileKeys"] = {
		["Qweradf - 金色平原"] = "Qweradf - 金色平原",
		["乐乐创想 - 金色平原"] = "Default",
	},
	["profiles"] = {
		["Qweradf - 金色平原"] = {
			["font"] = "聊天",
			["hideAnimation"] = true,
		},
		["Default"] = {
			["minimumDuration"] = 13,
			["size1"] = 25,
			["hideAnimation"] = true,
			["font"] = "伤害数字",
			["UseBlizCounter"] = true,
		},
	},
}
