
BlizzMoveDB = {
	["TradeSkillFrame"] = {
	},
	["ClassTrainerFrame"] = {
	},
	["VideoOptionsFrame"] = {
	},
	["CharacterFrame"] = {
	},
	["MailFrame"] = {
	},
	["MacroFrame"] = {
		["default"] = {
			["relativeTo"] = "UIParent",
			["point"] = "TOPLEFT",
			["relativePoint"] = "TOPLEFT",
			["yOfs"] = -116.000007629395,
			["xOfs"] = 16,
		},
		["relativePoint"] = "LEFT",
		["yOfs"] = 148.999908447266,
		["xOfs"] = 47.0000076293945,
		["point"] = "LEFT",
	},
	["CollectionsJournal"] = {
		["save"] = true,
	},
	["AchievementFrame"] = {
		["save"] = true,
	},
	["ArchaeologyFrame"] = {
	},
	["GarrisonLandingPage"] = {
	},
	["GarrisonCapacitiveDisplayFrame"] = {
	},
	["PlayerTalentFrame"] = {
		["default"] = {
			["relativeTo"] = "UIParent",
			["point"] = "TOPLEFT",
			["relativePoint"] = "TOPLEFT",
			["yOfs"] = -116.000007629395,
			["xOfs"] = 16,
		},
		["relativePoint"] = "LEFT",
		["yOfs"] = 70.9999694824219,
		["xOfs"] = 24.9999713897705,
		["point"] = "LEFT",
	},
	["GuildBankFrame"] = {
		["save"] = true,
	},
	["SpellBookFrame"] = {
		["default"] = {
			["relativeTo"] = "UIParent",
			["point"] = "TOPLEFT",
			["relativePoint"] = "TOPLEFT",
			["yOfs"] = -116.000007629395,
			["xOfs"] = 16,
		},
		["relativePoint"] = "TOPLEFT",
		["yOfs"] = -137.000228881836,
		["xOfs"] = 61.0000076293945,
		["point"] = "TOPLEFT",
	},
	["TradeFrame"] = {
	},
	["CalendarFrame"] = {
		["save"] = true,
	},
	["InterfaceOptionsFrame"] = {
		["default"] = {
			["relativeTo"] = "UIParent",
			["point"] = "CENTER",
			["relativePoint"] = "CENTER",
			["yOfs"] = 0,
			["xOfs"] = 0,
		},
		["relativePoint"] = "CENTER",
		["yOfs"] = 3.0001208782196,
		["xOfs"] = 55.0004768371582,
		["point"] = "CENTER",
	},
	["InspectFrame"] = {
	},
	["AuctionFrame"] = {
		["default"] = {
			["relativeTo"] = "UIParent",
			["point"] = "TOPLEFT",
			["relativePoint"] = "TOPLEFT",
			["yOfs"] = -104.000007629395,
			["xOfs"] = 0,
		},
		["relativePoint"] = "TOPLEFT",
		["yOfs"] = -101.999954223633,
		["xOfs"] = 6.99997520446777,
		["point"] = "TOPLEFT",
		["save"] = true,
	},
	["BankFrame"] = {
	},
	["RaidBrowserFrame"] = {
	},
	["FriendsFrame"] = {
	},
	["GossipFrame"] = {
	},
	["ObjectiveTrackerFrame"] = {
	},
	["MerchantFrame"] = {
	},
	["DressUpFrame"] = {
	},
	["WorldMapFrame"] = {
	},
	["KeyBindingFrame"] = {
		["default"] = {
			["relativeTo"] = "UIParent",
			["point"] = "CENTER",
			["relativePoint"] = "CENTER",
			["yOfs"] = 0,
			["xOfs"] = 0,
		},
		["relativePoint"] = "CENTER",
		["yOfs"] = 26.0000324249268,
		["xOfs"] = -65.9999084472656,
		["point"] = "CENTER",
	},
	["LootFrame"] = {
		["scale"] = 0.9,
	},
	["QuestLogPopupDetailFrame"] = {
	},
	["GarrisonMissionFrame"] = {
	},
	["PVEFrame"] = {
	},
	["ColorPickerFrame"] = {
	},
	["GameMenuFrame"] = {
	},
	["EncounterJournal"] = {
	},
	["GuildFrame"] = {
	},
	["HelpFrame"] = {
	},
}
