
WhisperPopDB = {
	["help"] = 1,
	["time"] = 1,
	["2.0"] = 1,
	["sound"] = 1,
	["Minimap Button"] = {
		["angle"] = 170,
	},
}
