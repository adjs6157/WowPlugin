
MerchatAssistDB = {
	["金色平原_乐乐创想"] = {
		["autobuy"] = {
		},
		["autosell"] = {
		},
	},
	["迦拉克隆_落晖沉梦"] = {
		["autobuy"] = {
		},
		["autosell"] = {
		},
	},
	["金色平原_翻墙头"] = {
		["autobuy"] = {
		},
		["autosell"] = {
		},
	},
	["金色平原_Qweradf"] = {
		["autobuy"] = {
		},
		["autosell"] = {
		},
	},
}
MerchatAssistAutoBuy = nil
