
DBMPvP_AllSavedVars = {
	["乐乐创想-金色平原"] = {
		["z726"] = {
			{
				["TimerFlag"] = true,
				["Timer46392next"] = true,
				["Enabled"] = true,
				["ShowFlagCarrier"] = true,
				["TimerFlagTColor"] = 0,
				["ShowFlagCarrierErrorNote"] = false,
				["Timer46392nextTColor"] = 0,
			}, -- [1]
		},
		["z628"] = {
			{
				["WarnSiegeEngine"] = true,
				["TimerPOITColor"] = 0,
				["TimerSiegeEngineTColor"] = 0,
				["WarnSiegeEngineSoon"] = true,
				["Enabled"] = true,
				["ShowGatesHealth"] = true,
				["TimerSiegeEngine"] = true,
				["TimerPOI"] = true,
			}, -- [1]
		},
		["Battlegrounds"] = {
			{
				["Enabled"] = true,
				["ColorByClass"] = true,
				["HideBossEmoteFrame"] = false,
				["AutoSpirit"] = false,
			}, -- [1]
		},
		["talent1"] = "野兽控制",
		["Arenas"] = {
			{
				["Enabled"] = true,
				["Countdown91344"] = true,
				["timer_combat"] = true,
				["timer_combatTColor"] = 0,
				["TimerShadow"] = true,
				["Timer110310cast"] = true,
				["TimerShadowTColor"] = 0,
				["Timer110310castTColor"] = 0,
			}, -- [1]
		},
		["z489"] = {
			{
				["TimerFlag"] = true,
				["Timer46392next"] = true,
				["Enabled"] = true,
				["ShowFlagCarrier"] = true,
				["TimerFlagTColor"] = 0,
				["ShowFlagCarrierErrorNote"] = false,
				["Timer46392nextTColor"] = 0,
			}, -- [1]
		},
		["z30"] = {
			{
				["Enabled"] = true,
				["AutoTurnIn"] = true,
			}, -- [1]
		},
	},
}
