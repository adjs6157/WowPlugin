
Gladius2DB = {
	["profileKeys"] = {
		["乐乐创想 - 金色平原"] = "乐乐创想 - 金色平原",
	},
	["profiles"] = {
		["乐乐创想 - 金色平原"] = {
			["auraVersion"] = 1,
			["tagsVersion"] = 4,
			["y"] = {
				["arena1"] = 124.444436607096,
			},
			["x"] = {
				["arena1"] = 1068.80080713036,
			},
		},
	},
}
